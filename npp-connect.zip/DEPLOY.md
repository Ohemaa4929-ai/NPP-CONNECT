# NPP CONNECT: auth setup and deployment notes

Status: auth screens are written. Nothing here has been run against a live project. Test on DEV first.

## 1. Supabase projects
Create three projects: `npp-connect-dev`, `-staging`, `-prod`. Never reuse keys between them.
Apply `supabase/migrations/*.sql` in order with the Supabase CLI (`supabase db push`). Do dev first, then staging, then prod.

## 2. Phone OTP
Dashboard > Authentication > Providers > Phone: enable, choose an SMS provider that delivers to Ghana numbers
(Twilio, MessageBird, Vonage or Textlocal are the built-in options). Check Ghana delivery and price with the provider.
Set OTP expiry to 300 seconds or less, and keep the default rate limits. Provider credentials stay in the dashboard.
Test numbers can be listed in the dashboard for dev so no SMS is sent.

## 3. Admin 2FA
Enable TOTP MFA (Authentication > Multi-factor). Admin dashboard (step to come) must require an AAL2 session,
and RLS for admin writes should check `auth.jwt()->>'aal' = 'aal2'`. Add that check before launch.

## 4. First super admin
Sign up with your number in the app, then in the SQL editor, as a one-time manual step:
    update profiles set status='active', verified_at=now() where phone='+233XXXXXXXXX';
    insert into user_roles values ((select id from profiles where phone='+233XXXXXXXXX'),'super_admin');
Create the org units and broadcast grants from the admin dashboard afterward.

## 5. Mobile builds
Set EXPO_PUBLIC_* values per environment in EAS (`eas secret` / EAS environment variables). Set EXPO_PUBLIC_DEMO_MODE=false for staging and production.
Change bundle ID and package name. Run `eas build` for iOS and Android, then submit to App Store Connect and Google Play.
Store listings need a hosted privacy policy URL and an account deletion path.

## 6. Launch gates
- Legal review of Terms and Privacy Policy under Ghana data protection law, including political-opinion data handling.
- RLS test with two non-admin accounts (cannot read each other's profile, cannot change status or verified_at).
- Load test broadcasts after Phase 3. Backup restore test. Security review.
- No end-to-end encryption claim anywhere in the UI or store listing.

## 7. First admin for the dashboard (email login)
Dashboard sign-in uses email and password. In Supabase Authentication > Users, add the admin by email with a strong password.
Then in the SQL editor:
    update profiles set status='active', verified_at=now() where id=(select id from auth.users where email='admin@yourdomain');
    delete from user_roles where user_id=(select id from auth.users where email='admin@yourdomain');
    insert into user_roles values ((select id from auth.users where email='admin@yourdomain'),'super_admin');
First dashboard login enrolls an authenticator app. Admin actions only work on a verified 2FA session.

## 8. Broadcast delivery worker
    supabase functions deploy broadcast-fanout
    supabase secrets set EXPO_ACCESS_TOKEN=...      # optional, raises Expo push limits
Schedule a call every minute with the service-role key (pg_cron + pg_net, or an external scheduler) and call it once after each publish for speed.
Check `broadcast_jobs` for rows stuck in `failed` or `running`.

## 9. Push notifications
Run `eas init` to get a projectId and add it under `expo.extra.eas.projectId` in app.json. Run `eas credentials` to add the Android FCM key and iOS APNs key.
Push needs a physical phone and a development or production build, not Expo Go.

## 10. Environments
Three Supabase projects (dev, staging, production), three EAS build profiles (already in eas.json), three admin deployments with their own env vars.
Never run seed.sql or set `app.require_admin_mfa = 'off'` outside dev.
