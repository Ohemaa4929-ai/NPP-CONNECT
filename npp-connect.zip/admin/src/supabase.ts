'use client';
import { createClient } from '@supabase/supabase-js';
export const sb = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);
// Session expiry: sign out after 30 minutes without activity.
export function useIdleLogout(minutes = 30) {
  if (typeof window === 'undefined') return;
  let t: ReturnType<typeof setTimeout>;
  const reset = () => { clearTimeout(t); t = setTimeout(async () => { await sb.auth.signOut(); location.href = '/login'; }, minutes * 60_000); };
  ['click', 'keydown', 'mousemove'].forEach((e) => window.addEventListener(e, reset)); reset();
}
