'use client';
import { ReactNode, useEffect, useState } from 'react';
import Link from 'next/link';
import { sb, useIdleLogout } from './supabase';

export const C = { blue: '#16307a', red: '#e10e17', line: '#dde2f0', bg: '#f2f4fa' };
const NAV = [['/', 'Dashboard'], ['/users', 'Users'], ['/org', 'Organization'], ['/broadcasts', 'Broadcasts'], ['/reports', 'Moderation'], ['/audit', 'Audit logs'], ['/roles', 'Roles and security']];

// Wraps every admin page: requires a session at AAL2 (2FA verified), otherwise redirects to /login.
export function Shell({ title, children }: { title: string; children: ReactNode }) {
  const [ok, setOk] = useState(false);
  useEffect(() => {
    useIdleLogout();
    sb.auth.mfa.getAuthenticatorAssuranceLevel().then(({ data }) => { if (data?.currentLevel === 'aal2') setOk(true); else location.href = '/login'; });
  }, []);
  if (!ok) return <p style={{ padding: 24 }}>Checking your session…</p>;
  return <div style={{ display: 'flex', minHeight: '100vh', fontFamily: 'system-ui, sans-serif' }}>
    <nav style={{ width: 210, background: C.blue, color: '#fff', padding: 16 }}>
      <b style={{ fontSize: 18 }}>NPP CONNECT</b><div style={{ opacity: .8, fontSize: 12, marginBottom: 16 }}>Admin</div>
      {NAV.map(([h, l]) => <Link key={h} href={h} style={{ display: 'block', color: '#fff', padding: '8px 0', textDecoration: 'none' }}>{l}</Link>)}
      <button onClick={async () => { await sb.auth.signOut(); location.href = '/login'; }} style={{ marginTop: 24, ...btn(C.red) }}>Log out</button>
    </nav>
    <main style={{ flex: 1, padding: 24, background: C.bg }}><h1 style={{ marginTop: 0 }}>{title}</h1>{children}</main></div>;
}
export const btn = (bg: string) => ({ background: bg, color: '#fff', border: 0, borderRadius: 8, padding: '8px 12px', cursor: 'pointer' } as const);
export function Table({ cols, rows }: { cols: string[]; rows: ReactNode[][] }) {
  return <div style={{ overflowX: 'auto' }}><table style={{ width: '100%', borderCollapse: 'collapse', background: '#fff' }}>
    <thead><tr>{cols.map((c) => <th key={c} style={{ textAlign: 'left', padding: 10, borderBottom: `2px solid ${C.line}` }}>{c}</th>)}</tr></thead>
    <tbody>{rows.length ? rows.map((r, i) => <tr key={i}>{r.map((c, j) => <td key={j} style={{ padding: 10, borderBottom: `1px solid ${C.line}` }}>{c}</td>)}</tr>)
      : <tr><td colSpan={cols.length} style={{ padding: 24, textAlign: 'center', color: '#5a6585' }}>Nothing here yet.</td></tr>}</tbody></table></div>;
}
// Destructive actions always ask first.
export const confirmThen = (msg: string, fn: () => PromiseLike<unknown>) => async () => { if (confirm(msg)) { const r = await fn() as { error?: { message: string } } | undefined; if (r?.error) alert(r.error.message); location.reload(); } };
