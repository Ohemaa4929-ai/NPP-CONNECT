'use client';
import { useEffect, useState } from 'react';
import { sb } from '@/supabase';
import { Shell } from '@/ui';

type Stats = Record<string, number | Record<string, number>>;
const fmt = (b: number) => (b > 1e9 ? (b / 1e9).toFixed(1) + ' GB' : (b / 1e6).toFixed(1) + ' MB');
export default function Dashboard() {
  const [s, setS] = useState<Stats | null>(null); const [err, setErr] = useState('');
  useEffect(() => { sb.rpc('admin_stats').then(({ data, error }) => error ? setErr(error.message) : setS(data)); }, []);
  const cards: [string, string][] = s ? [['Total users', String(s.users)], ['Active (7 days)', String(s.active_7d)], ['Verified', String(s.verified)], ['Pending approval', String(s.pending)],
    ['Suspended', String(s.suspended)], ['Groups', String(s.groups)], ['Broadcasts', String(s.broadcasts)], ['Messages', String(s.messages)],
    ['Videos', String(s.videos)], ['Storage', fmt(s.storage_bytes as number)], ['Open reports', String(s.open_reports)]] : [];
  return <Shell title="Dashboard">{err && <p role="alert">{err}</p>}
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(180px,1fr))', gap: 12 }}>
      {cards.map(([l, v]) => <div key={l} style={{ background: '#fff', borderRadius: 12, padding: 16 }}><div style={{ color: '#5a6585' }}>{l}</div><div style={{ fontSize: 28, fontWeight: 800 }}>{v}</div></div>)}</div>
    {s && <p>Users by role: {Object.entries(s.by_role as Record<string, number>).map(([r, n]) => `${r} ${n}`).join(' · ')}</p>}</Shell>;
}
