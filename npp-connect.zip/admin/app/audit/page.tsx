'use client';
import { useEffect, useState } from 'react';
import { sb } from '@/supabase';
import { Shell, Table } from '@/ui';

type L = { id: number; actor_id: string | null; action: string; target_type: string | null; target_id: string | null; detail: unknown; created_at: string };
export default function Audit() {
  const [rows, setRows] = useState<L[]>([]); const [before, setBefore] = useState<number | null>(null);
  useEffect(() => { let q = sb.from('audit_logs').select('*').order('id', { ascending: false }).limit(50); if (before) q = q.lt('id', before); q.then(({ data }) => setRows((data as L[]) ?? [])); }, [before]);
  return <Shell title="Audit logs"><Table cols={['Time', 'Actor', 'Action', 'Target', 'Detail']} rows={rows.map((l) => [new Date(l.created_at).toLocaleString(), l.actor_id?.slice(0, 8) ?? 'system', l.action, `${l.target_type ?? ''} ${l.target_id ?? ''}`, <code key="d" style={{ fontSize: 11 }}>{JSON.stringify(l.detail).slice(0, 120)}</code>])} />
    <p><button onClick={() => setBefore(null)}>Newest</button> <button onClick={() => rows.length && setBefore(rows[rows.length - 1].id)}>Older →</button></p></Shell>;
}
