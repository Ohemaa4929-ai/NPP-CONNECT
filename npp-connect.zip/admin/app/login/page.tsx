'use client';
import { useState } from 'react';
import { sb } from '@/supabase';
import { btn, C } from '@/ui';

// Email + password, then a TOTP code. Admin pages require the AAL2 session this creates.
export default function Login() {
  const [email, setEmail] = useState(''); const [pw, setPw] = useState(''); const [code, setCode] = useState('');
  const [factor, setFactor] = useState<string | null>(null); const [qr, setQr] = useState<string | null>(null); const [err, setErr] = useState('');
  const first = async () => {
    const { error } = await sb.auth.signInWithPassword({ email, password: pw }); if (error) return setErr('Wrong email or password.');
    const { data } = await sb.auth.mfa.listFactors(); const f = data?.totp.find((x) => x.status === 'verified');
    if (f) return setFactor(f.id);
    const en = await sb.auth.mfa.enroll({ factorType: 'totp' });           // first login: enroll an authenticator app
    if (en.error) return setErr(en.error.message); setFactor(en.data.id); setQr(en.data.totp.qr_code);
  };
  const second = async () => {
    const ch = await sb.auth.mfa.challenge({ factorId: factor! }); if (ch.error) return setErr(ch.error.message);
    const v = await sb.auth.mfa.verify({ factorId: factor!, challengeId: ch.data.id, code });
    if (v.error) return setErr('That code is wrong or expired.'); location.href = '/';
  };
  const box = { padding: 12, border: `1px solid ${C.line}`, borderRadius: 8, width: '100%', boxSizing: 'border-box' } as const;
  return <div style={{ maxWidth: 360, margin: '10vh auto', display: 'grid', gap: 12, fontFamily: 'system-ui' }}>
    <h1 style={{ color: C.blue }}>NPP CONNECT Admin</h1>
    {!factor ? <>
      <input style={box} placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="username" />
      <input style={box} placeholder="Password" type="password" value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="current-password" />
      <button style={btn(C.red)} onClick={first}>Continue</button></>
    : <>{qr && <><p>Scan with an authenticator app, then enter the code.</p><img src={qr} alt="2FA QR code" width={180} /></>}
      <input style={box} placeholder="6-digit code" inputMode="numeric" maxLength={6} value={code} onChange={(e) => setCode(e.target.value)} />
      <button style={btn(C.red)} onClick={second}>Verify</button></>}
    {err && <p role="alert" style={{ color: C.red }}>{err}</p>}</div>;
}
