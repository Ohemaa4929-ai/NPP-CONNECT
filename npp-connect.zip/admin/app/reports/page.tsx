'use client';
import { useEffect, useState } from 'react';
import { sb } from '@/supabase';
import { Shell, Table, btn, C, confirmThen } from '@/ui';

type R = { id: string; target_type: string; target_id: string; reason: string; detail: string | null; status: string; created_at: string };
export default function Reports() {
  const [rows, setRows] = useState<R[]>([]);
  useEffect(() => { sb.from('reports').select('*').order('created_at', { ascending: false }).limit(100).then(({ data }) => setRows((data as R[]) ?? [])); }, []);
  const act = (r: R, a: string, label: string) => <button key={a} style={btn(a === 'dismissed' ? C.blue : C.red)} onClick={confirmThen(`${label}?`, () => Promise.resolve(sb.rpc('resolve_report', { r: r.id, act: a, note: null })))}>{label}</button>;
  return <Shell title="Moderation"><Table cols={['Reported', 'Type', 'Reason', 'Detail', 'Status', 'Actions']} rows={rows.map((r) => [new Date(r.created_at).toLocaleString(), r.target_type, r.reason, r.detail ?? '', r.status,
    r.status === 'open' ? <span key="x" style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>{act(r, 'dismissed', 'Dismiss')}{act(r, 'warned', 'Warn')}{act(r, 'content_removed', 'Remove content')}{r.target_type === 'user' && act(r, 'suspended', 'Suspend account')}</span> : ''])} /></Shell>;
}
