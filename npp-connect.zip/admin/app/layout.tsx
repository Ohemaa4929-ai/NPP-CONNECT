export const metadata = { title: 'NPP CONNECT Admin' };
export default function Root({ children }: { children: React.ReactNode }) { return <html lang="en"><body style={{ margin: 0 }}>{children}</body></html>; }
