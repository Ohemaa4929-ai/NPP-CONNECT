'use client';
import { useEffect, useState } from 'react';
import { sb } from '@/supabase';
import { Shell, C } from '@/ui';

const ROLES = ['super_admin', 'national_leader', 'regional_leader', 'constituency_executive', 'electoral_area_coordinator', 'polling_station_executive', 'member'];
export default function Roles() {
  const [perms, setPerms] = useState<{ key: string; description: string }[]>([]); const [rp, setRp] = useState<Set<string>>(new Set());
  const load = async () => { setPerms(((await sb.from('permissions').select('*')).data as typeof perms) ?? []); setRp(new Set(((await sb.from('role_permissions').select('*')).data ?? []).map((r: { role: string; permission: string }) => r.role + '|' + r.permission))); };
  useEffect(() => { load(); }, []);
  const toggle = async (role: string, p: string) => { const on = rp.has(role + '|' + p); const r = on ? await sb.from('role_permissions').delete().eq('role', role).eq('permission', p) : await sb.from('role_permissions').insert({ role, permission: p }); if (r.error) alert(r.error.message); else load(); };
  return <Shell title="Roles and security">
    <p>Permissions per role. Changes are written to the audit log. Admin actions require a verified 2FA session.</p>
    <table style={{ background: '#fff', borderCollapse: 'collapse' }}><thead><tr><th style={{ padding: 8 }} />{ROLES.map((r) => <th key={r} style={{ padding: 8, fontSize: 11 }}>{r}</th>)}</tr></thead>
      <tbody>{perms.map((p) => <tr key={p.key}><td style={{ padding: 8 }} title={p.description}>{p.key}</td>{ROLES.map((r) => <td key={r} style={{ textAlign: 'center' }}>
        <input type="checkbox" aria-label={`${r} ${p.key}`} checked={rp.has(r + '|' + p.key)} onChange={() => toggle(r, p.key)} /></td>)}</tr>)}</tbody></table>
    <p style={{ color: C.blue }}>Session timeout: 30 minutes idle. Device and session reset: Users page, "Reset access".</p></Shell>;
}
