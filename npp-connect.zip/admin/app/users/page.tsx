'use client';
import { useEffect, useState } from 'react';
import { sb } from '@/supabase';
import { Shell, Table, btn, C, confirmThen } from '@/ui';

type P = { id: string; full_name: string; phone: string | null; status: string; verified_at: string | null; user_roles: { role: string }[] };
const ROLES = ['super_admin', 'national_leader', 'regional_leader', 'constituency_executive', 'electoral_area_coordinator', 'polling_station_executive', 'member'];
export default function Users() {
  const [q, setQ] = useState(''); const [rows, setRows] = useState<P[]>([]);
  const load = async () => { let r = sb.from('profiles').select('id,full_name,phone,status,verified_at,user_roles(role)').order('created_at', { ascending: false }).limit(50);
    const s = q.replace(/[%,]/g, '').trim(); if (s) r = r.or(`full_name.ilike.%${s}%,phone.ilike.%${s}%`); const { data } = await r; setRows((data as unknown as P[]) ?? []); };
  useEffect(() => { load(); }, []);   // eslint-disable-line
  const setRole = async (id: string, role: string) => { await sb.from('user_roles').delete().eq('user_id', id); const { error } = await sb.from('user_roles').insert({ user_id: id, role }); if (error) alert(error.message); else load(); };
  const assign = async (id: string) => { const unit = prompt('Organization unit ID to assign (see Organization page):'); if (unit) { const { error } = await sb.from('user_org_units').insert({ user_id: id, org_unit_id: unit }); alert(error ? error.message : 'Assigned.'); } };
  const grant = async (id: string) => { const unit = prompt('Unit ID this person may broadcast to (includes all units below it):'); if (unit) { const me = (await sb.auth.getUser()).data.user!.id; const { error } = await sb.from('broadcast_grants').insert({ user_id: id, org_unit_id: unit, granted_by: me }); alert(error ? error.message : 'Granted.'); } };
  return <Shell title="Users">
    <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name or phone" style={{ padding: 10, flex: 1 }} /><button style={btn(C.blue)} onClick={load}>Search</button></div>
    <Table cols={['Name', 'Phone', 'Status', 'Role', 'Actions']} rows={rows.map((u) => [
      <>{u.full_name || '(no name)'} {u.verified_at && <b style={{ color: C.blue }}>✓ Verified</b>}</>, u.phone ?? '', u.status,
      <select value={u.user_roles[0]?.role ?? 'member'} onChange={(e) => setRole(u.id, e.target.value)}>{ROLES.map((r) => <option key={r}>{r}</option>)}</select>,
      <span style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
        <button style={btn(C.blue)} onClick={confirmThen(u.verified_at ? 'Remove verified badge?' : 'Verify this account?', () => Promise.resolve(sb.rpc('verify_user', { u: u.id, v: !u.verified_at })))}>{u.verified_at ? 'Unverify' : 'Verify'}</button>
        <button style={btn(C.blue)} onClick={() => assign(u.id)}>Assign unit</button>
        <button style={btn(C.blue)} onClick={() => grant(u.id)}>Broadcast right</button>
        {u.status === 'suspended' ? <button style={btn(C.blue)} onClick={confirmThen('Reactivate this account?', () => Promise.resolve(sb.rpc('reactivate_user', { u: u.id })))}>Reactivate</button>
          : <button style={btn(C.red)} onClick={confirmThen('Suspend this account? They are signed out of every device.', () => Promise.resolve(sb.rpc('suspend_user', { u: u.id, reason: 'admin action' })))}>Suspend</button>}
        <button style={btn('#444')} onClick={confirmThen('Revoke all sessions for this user?', () => Promise.resolve(sb.rpc('revoke_all_sessions', { u: u.id })))}>Reset access</button>
        <button style={btn('#000')} onClick={confirmThen('REMOVE this account? Personal details are erased. This cannot be undone.', () => Promise.resolve(sb.rpc('remove_user', { u: u.id, reason: 'admin action' })))}>Remove</button></span>])} /></Shell>;
}
