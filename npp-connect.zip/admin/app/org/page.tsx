'use client';
import { useEffect, useState } from 'react';
import { sb } from '@/supabase';
import { Shell, Table, btn, C, confirmThen } from '@/ui';

type U = { id: string; parent_id: string | null; level_rank: number; name: string; code: string | null; path: string };
export default function Org() {
  const [units, setUnits] = useState<U[]>([]); const [lv, setLv] = useState<{ rank: number; label: string }[]>([]);
  const [name, setName] = useState(''); const [parent, setParent] = useState(''); const [code, setCode] = useState('');
  const load = async () => { setUnits(((await sb.from('org_units').select('*').order('path')).data as U[]) ?? []); setLv(((await sb.from('org_levels').select('*').order('rank')).data as typeof lv) ?? []); };
  useEffect(() => { load(); }, []);
  const rank = (parent ? (units.find((u) => u.id === parent)?.level_rank ?? 0) + 1 : 1);
  const add = async () => { const { error } = await sb.from('org_units').insert({ name, parent_id: parent || null, level_rank: rank, code: code || null }); if (error) alert(error.message); else { setName(''); setCode(''); load(); } };
  return <Shell title="Organization">
    <div style={{ display: 'flex', gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
      <select value={parent} onChange={(e) => setParent(e.target.value)}><option value="">Top level</option>{units.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}</select>
      <input placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} /><input placeholder="Code (optional)" value={code} onChange={(e) => setCode(e.target.value)} />
      <button style={btn(C.red)} onClick={add} disabled={name.length < 2 || rank > lv.length}>Add as {lv.find((l) => l.rank === rank)?.label ?? 'unavailable'}</button></div>
    <Table cols={['Level', 'Name', 'Code', 'ID', '']} rows={units.map((u) => [lv.find((l) => l.rank === u.level_rank)?.label ?? u.level_rank, '— '.repeat(u.level_rank - 1) + u.name, u.code ?? '', <code key="i">{u.id}</code>,
      <button key="d" style={btn(C.red)} onClick={confirmThen(`Delete ${u.name}? It must have no child units.`, async () => sb.from('org_units').delete().eq('id', u.id))}>Delete</button>])} /></Shell>;
}
