'use client';
import { useEffect, useState } from 'react';
import { sb } from '@/supabase';
import { Shell, Table, btn, C, confirmThen } from '@/ui';

type B = { id: string; title: string; status: string; priority: string; scheduled_at: string | null; view_count: number; created_at: string };
export default function Broadcasts() {
  const [rows, setRows] = useState<B[]>([]);
  useEffect(() => { sb.from('broadcasts').select('id,title,status,priority,scheduled_at,view_count,created_at').order('created_at', { ascending: false }).limit(100).then(({ data }) => setRows((data as B[]) ?? [])); }, []);
  const reschedule = async (id: string) => { const t = prompt('New time (YYYY-MM-DD HH:MM, local):'); if (t) { const { error } = await sb.from('broadcasts').update({ scheduled_at: new Date(t).toISOString() }).eq('id', id); alert(error ? error.message : 'Updated. For a broadcast already queued, cancel and republish to change the send time.'); } };
  return <Shell title="Broadcasts"><Table cols={['Title', 'Status', 'Priority', 'Scheduled', 'Views', 'Actions']} rows={rows.map((b) => [b.title, b.status, b.priority, b.scheduled_at ? new Date(b.scheduled_at).toLocaleString() : '', b.view_count,
    ['draft', 'scheduled'].includes(b.status) ? <span key="a" style={{ display: 'flex', gap: 6 }}><button style={btn(C.blue)} onClick={() => reschedule(b.id)}>Edit time</button>
      <button style={btn(C.red)} onClick={confirmThen('Cancel this broadcast?', () => Promise.resolve(sb.rpc('cancel_broadcast', { b: b.id })))}>Cancel</button></span> : ''])} /></Shell>;
}
