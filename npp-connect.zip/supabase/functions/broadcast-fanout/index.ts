// Supabase Edge Function: drains the broadcast queue in batches and sends push notifications.
// Trigger it every minute (pg_cron + pg_net, or Supabase scheduled functions) and after publish.
// Secrets (set in the Supabase dashboard, never in the app): SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, EXPO_ACCESS_TOKEN (optional).
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const sb = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
const BATCH = 2000, PUSH_CHUNK = 100, MAX_MS = 45_000;

async function push(tokens: string[], title: string, body: string, data: Record<string, unknown>) {
  for (let i = 0; i < tokens.length; i += PUSH_CHUNK) {
    const chunk = tokens.slice(i, i + PUSH_CHUNK).map((to) => ({ to, title, body, data, sound: 'default' }));
    for (let attempt = 0; attempt < 3; attempt++) {                     // retry with backoff
      const r = await fetch('https://exp.host/--/api/v2/push/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...(Deno.env.get('EXPO_ACCESS_TOKEN') ? { Authorization: `Bearer ${Deno.env.get('EXPO_ACCESS_TOKEN')}` } : {}) },
        body: JSON.stringify(chunk),
      });
      if (r.ok) break;
      await new Promise((res) => setTimeout(res, 500 * 2 ** attempt));
    }
  }
}

Deno.serve(async (req) => {
  // Only the scheduler (holding the service key) may call this.
  if (req.headers.get('Authorization') !== `Bearer ${Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')}`) return new Response('forbidden', { status: 403 });
  const started = Date.now(); let batches = 0;
  while (Date.now() - started < MAX_MS) {
    const { data: job } = await sb.rpc('claim_broadcast_job');
    if (!job || !job.id) break;
    try {
      const { data: ids, error } = await sb.rpc('fanout_batch', { job: job.id, batch: BATCH });
      if (error) throw error;
      const users = (ids ?? []).map((r: { user_id: string }) => r.user_id);
      if (users.length) {
        const { data: b } = await sb.from('broadcasts').select('id,title,body,priority').eq('id', job.broadcast_id).single();
        const { data: toks } = await sb.rpc('push_tokens', { b: job.broadcast_id, ids: users });
        await push((toks ?? []).map((t: { token: string }) => t.token), b?.title ?? 'New broadcast', (b?.body ?? '').slice(0, 140), { type: 'broadcast', id: job.broadcast_id });
      }
      batches++;
    } catch (e) {
      await sb.from('broadcast_jobs').update({ status: job.attempts >= 5 ? 'failed' : 'queued', locked_at: null, error: String(e) }).eq('id', job.id);
    }
  }
  return new Response(JSON.stringify({ batches }), { headers: { 'Content-Type': 'application/json' } });
});
