-- NPP CONNECT, migration 0005: read functions the mobile app calls (names and privacy-aware joins)

create or replace function my_chats() returns table (id uuid, kind conv_kind, title text, group_id uuid, last_body text, last_at timestamptz,
  unread bigint, restrict_forwarding boolean, disappear_secs int)
language sql stable security definer set search_path = public as $$
  select c.id, c.kind,
    case when c.kind = 'direct' then (select p.full_name from conversation_members m2 join profiles p on p.id = m2.user_id
                                      where m2.conversation_id = c.id and m2.user_id <> auth.uid() limit 1) else c.title end,
    (select g.id from groups g where g.conversation_id = c.id),
    (select left(m.body, 80) from messages m where m.conversation_id = c.id and m.deleted_at is null order by m.created_at desc limit 1),
    c.last_message_at,
    (select count(*) from messages m where m.conversation_id = c.id and m.sender_id <> auth.uid() and m.deleted_at is null
       and (cm.last_read_at is null or m.created_at > cm.last_read_at)),
    c.restrict_forwarding, extract(epoch from c.disappear_after)::int
  from conversations c join conversation_members cm on cm.conversation_id = c.id and cm.user_id = auth.uid() and cm.status = 'active'
  where is_member(c.id) order by c.last_message_at desc nulls last limit 100 $$;

create or replace function get_messages(conv uuid, before_at timestamptz default null, before_id uuid default null, lim int default 30)
returns table (id uuid, sender_id uuid, sender_name text, sender_verified boolean, kind msg_kind, body text, reply_to uuid, forwarded boolean,
  pinned boolean, created_at timestamptz, attachments jsonb, reactions jsonb)
language sql stable security definer set search_path = public as $$
  select m.id, m.sender_id, p.full_name, p.verified_at is not null, m.kind, m.body, m.reply_to, m.forwarded_from is not null, m.pinned, m.created_at,
    coalesce((select jsonb_agg(jsonb_build_object('id', f.id, 'name', f.name, 'mime', f.mime, 'size', f.size_bytes, 'bucket', f.bucket,
       'path', f.path, 'duration', f.duration_s, 'thumb', f.thumb_path, 'kind', f.kind))
       from message_attachments a join files f on f.id = a.file_id where a.message_id = m.id), '[]'::jsonb),
    coalesce((select jsonb_agg(jsonb_build_object('emoji', r.emoji, 'user', r.user_id)) from message_reactions r where r.message_id = m.id), '[]'::jsonb)
  from messages m join profiles p on p.id = m.sender_id
  where m.conversation_id = conv and is_member(conv) and m.deleted_at is null and (m.expires_at is null or m.expires_at > now())
    and (before_at is null or (m.created_at, m.id) < (before_at, before_id))
  order by m.created_at desc, m.id desc limit least(lim, 100) $$;

create or replace function chat_receipts(conv uuid) returns table (user_id uuid, last_read_at timestamptz)
language sql stable security definer set search_path = public as $$
  select cm.user_id, cm.last_read_at from conversation_members cm
  join privacy_settings ps on ps.user_id = cm.user_id
  where cm.conversation_id = conv and is_member(conv) and cm.user_id <> auth.uid() and cm.status = 'active' and ps.read_receipts $$;

create or replace function group_members(conv uuid) returns table (user_id uuid, full_name text, verified boolean, role text, status text)
language sql stable security definer set search_path = public as $$
  select cm.user_id, p.full_name, p.verified_at is not null, cm.role, cm.status
  from conversation_members cm join profiles p on p.id = cm.user_id
  where cm.conversation_id = conv and is_member(conv) and cm.status <> 'removed'
    and (cm.status = 'active' or is_conv_admin(conv)) order by cm.role, p.full_name $$;

create or replace function broadcast_feed(lim int default 30, before_at timestamptz default null)
returns table (id uuid, title text, body text, priority text, author_name text, author_verified boolean, published_at timestamptz,
  view_count bigint, allow_comments boolean, allow_forwarding boolean, confidential boolean, read_at timestamptz, delivered_at timestamptz, files jsonb)
language sql stable security definer set search_path = public as $$
  select b.id, b.title, b.body, b.priority, p.full_name, p.verified_at is not null, b.published_at, b.view_count,
    b.allow_comments, b.allow_forwarding, b.confidential, r.read_at, r.delivered_at,
    coalesce((select jsonb_agg(jsonb_build_object('id', f.id, 'name', f.name, 'mime', f.mime, 'size', f.size_bytes, 'bucket', f.bucket, 'path', f.path, 'kind', f.kind))
       from broadcast_files bf join files f on f.id = bf.file_id where bf.broadcast_id = b.id), '[]'::jsonb)
  from broadcast_recipients r join broadcasts b on b.id = r.broadcast_id join profiles p on p.id = b.author_id
  where r.user_id = auth.uid() and b.status in ('sending', 'sent') and (before_at is null or r.delivered_at < before_at)
  order by r.delivered_at desc limit least(lim, 100) $$;

create or replace function broadcast_comment_list(b uuid) returns table (id uuid, user_name text, body text, created_at timestamptz)
language sql stable security definer set search_path = public as $$
  select c.id, p.full_name, c.body, c.created_at from broadcast_comments c join profiles p on p.id = c.user_id
  where c.broadcast_id = b and can_see_broadcast(b) order by c.created_at limit 200 $$;

create or replace function list_events() returns table (id uuid, title text, description text, starts_at timestamptz, ends_at timestamptz, location text,
  organizer_name text, registration_required boolean, going bigint, my_status text, reminder_at timestamptz)
language sql stable security definer set search_path = public as $$
  select e.id, e.title, e.description, e.starts_at, e.ends_at, e.location, p.full_name, e.registration_required,
    (select count(*) from event_attendees a where a.event_id = e.id and a.status = 'going'), me.status, me.reminder_at
  from events e join profiles p on p.id = e.organizer_id left join event_attendees me on me.event_id = e.id and me.user_id = auth.uid()
  where e.cancelled_at is null and e.starts_at > now() - interval '1 day' and (in_scope(e.org_unit_id) or e.organizer_id = auth.uid())
  order by e.starts_at limit 100 $$;

create or replace function list_videos(cat text default null) returns table (id uuid, title text, description text, category text, author_name text,
  author_verified boolean, published_at timestamptz, duration_s int, view_count bigint, bucket text, path text, thumb_path text, saved boolean, my_reaction text)
language sql stable security definer set search_path = public as $$
  select v.id, v.title, v.description, v.category, p.full_name, p.verified_at is not null, v.published_at, v.duration_s, v.view_count,
    f.bucket, f.path, t.path, exists (select 1 from video_saves s where s.video_id = v.id and s.user_id = auth.uid()),
    (select emoji from video_reactions r where r.video_id = v.id and r.user_id = auth.uid())
  from videos v join profiles p on p.id = v.author_id join files f on f.id = v.file_id left join files t on t.id = v.thumb_file_id
  where v.removed_at is null and in_scope(v.org_unit_id) and (cat is null or v.category = cat) order by v.published_at desc limit 50 $$;

create or replace function list_documents() returns table (id uuid, name text, mime text, size_bytes bigint, bucket text, path text, owner_name text, created_at timestamptz)
language sql stable security definer set search_path = public as $$
  select f.id, f.name, f.mime, f.size_bytes, f.bucket, f.path, p.full_name, f.created_at from files f join profiles p on p.id = f.owner_id
  where f.kind = 'document' and can_read_file(f.bucket, f.path) order by f.created_at desc limit 100 $$;

create or replace function find_people(q text) returns table (id uuid, full_name text, is_verified boolean)
language sql stable security definer set search_path = public as $$
  select d.id, d.full_name, d.is_verified from directory d where length(trim(q)) >= 2 and d.full_name ilike '%' || replace(replace(q, '%', ''), '_', '') || '%'
    and d.id <> auth.uid() limit 20 $$;

create or replace function touch_presence() returns void language sql security definer set search_path = public as $$
  update profiles set last_seen_at = now() where id = auth.uid() $$;
grant execute on all functions in schema public to authenticated;
revoke execute on function claim_broadcast_job(), fanout_batch(uuid, int), push_tokens(uuid, uuid[]), purge_expired() from authenticated, anon, public;
