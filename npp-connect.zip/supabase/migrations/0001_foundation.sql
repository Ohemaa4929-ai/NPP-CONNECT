-- NPP CONNECT, migration 0001: foundation (Phase 1)
-- Profiles, roles, configurable org hierarchy, privacy, devices, audit logs.
-- Run in a DEV project first. Never run against production without review.

create extension if not exists ltree;
create extension if not exists pg_trgm;

-- ───────── Types ─────────
create type app_role as enum (
  'super_admin','national_leader','regional_leader','constituency_executive',
  'electoral_area_coordinator','polling_station_executive','member');
create type account_status as enum ('pending','active','suspended','removed');
-- Hierarchy levels are data, not code: admins can rename or reorder them.
create table org_levels (
  rank smallint primary key,            -- 1 = top
  key  text unique not null,            -- 'national','region',...
  label text not null);
insert into org_levels values
  (1,'national','National'),(2,'region','Region'),(3,'constituency','Constituency'),
  (4,'electoral_area','Electoral Area'),(5,'polling_station','Polling Station');

-- ───────── Org hierarchy (one adjacency table, ltree path for subtree queries) ─────────
create table org_units (
  id uuid primary key default gen_random_uuid(),
  parent_id uuid references org_units(id) on delete restrict,
  level_rank smallint not null references org_levels(rank),
  name text not null check (length(name) between 2 and 120),
  code text unique,                      -- e.g. polling station code from the electoral body
  path ltree not null default ''::ltree,
  created_at timestamptz not null default now(),
  unique (parent_id, name));
create index org_units_path_gist on org_units using gist (path);
create index org_units_parent on org_units (parent_id);

create or replace function org_units_set_path() returns trigger language plpgsql as $$
declare p ltree;
begin
  if new.parent_id is null then p := ''::ltree;
  else select path into p from org_units where id = new.parent_id; end if;
  new.path := p || replace(new.id::text,'-','_')::ltree;
  return new;
end $$;
create trigger trg_org_path before insert or update of parent_id on org_units
  for each row execute function org_units_set_path();

-- ───────── Profiles ─────────
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '' check (length(full_name) <= 120),
  phone text unique check (phone is null or phone ~ '^\+[1-9][0-9]{7,14}$'),  -- E.164, e.g. +233...
  bio text check (length(bio) <= 280),
  avatar_path text,                      -- private storage path, never a public URL
  status account_status not null default 'pending',
  verified_at timestamptz,               -- non-null = Verified Leader badge
  verified_by uuid references profiles(id),
  last_seen_at timestamptz,
  created_at timestamptz not null default now());
create index profiles_name_trgm on profiles using gin (full_name gin_trgm_ops);

create table user_roles (
  user_id uuid not null references profiles(id) on delete cascade,
  role app_role not null,
  primary key (user_id, role));

create table user_org_units (          -- a user can sit in several units
  user_id uuid not null references profiles(id) on delete cascade,
  org_unit_id uuid not null references org_units(id) on delete cascade,
  is_primary boolean not null default false,
  primary key (user_id, org_unit_id));
create index user_org_units_unit on user_org_units (org_unit_id);

-- Admin-configurable permissions
create table permissions (key text primary key, description text not null);
create table role_permissions (
  role app_role not null, permission text not null references permissions(key),
  primary key (role, permission));
-- Broadcast rights are granted per user and per unit; scope is that unit's subtree.
create table broadcast_grants (
  user_id uuid not null references profiles(id) on delete cascade,
  org_unit_id uuid not null references org_units(id) on delete cascade,
  granted_by uuid not null references profiles(id),
  granted_at timestamptz not null default now(),
  primary key (user_id, org_unit_id));

insert into permissions values
  ('users.manage','Verify, assign, suspend and remove users'),
  ('org.manage','Edit the organizational hierarchy'),
  ('broadcast.create','Create broadcasts (scope set by broadcast_grants)'),
  ('groups.create','Create groups'),
  ('events.create','Create events'),
  ('polls.create','Create polls'),
  ('audit.read','Read audit logs'),
  ('moderation.review','Review reports');
insert into role_permissions values
  ('super_admin','users.manage'),('super_admin','org.manage'),('super_admin','broadcast.create'),
  ('super_admin','groups.create'),('super_admin','events.create'),('super_admin','polls.create'),
  ('super_admin','audit.read'),('super_admin','moderation.review'),
  ('national_leader','broadcast.create'),('national_leader','groups.create'),
  ('national_leader','events.create'),('national_leader','polls.create'),
  ('regional_leader','broadcast.create'),('regional_leader','groups.create'),('regional_leader','events.create'),
  ('constituency_executive','broadcast.create'),('constituency_executive','groups.create'),
  ('electoral_area_coordinator','broadcast.create'),
  ('polling_station_executive','broadcast.create'),
  ('member','groups.create');

-- ───────── Privacy, notifications, devices, audit ─────────
create table privacy_settings (
  user_id uuid primary key references profiles(id) on delete cascade,
  profile_visibility text not null default 'org' check (profile_visibility in ('everyone','org','leaders','nobody')),
  phone_visibility   text not null default 'leaders' check (phone_visibility in ('everyone','org','leaders','nobody')),
  last_seen          text not null default 'org' check (last_seen in ('everyone','org','nobody')),
  online_status      boolean not null default true,
  read_receipts      boolean not null default true,
  group_invites      text not null default 'org' check (group_invites in ('everyone','org','nobody')));
create table notification_settings (
  user_id uuid primary key references profiles(id) on delete cascade,
  mode text not null default 'all' check (mode in ('all','important','groups','direct','silent')));
create table devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  label text, push_token text, last_active_at timestamptz not null default now(),
  revoked_at timestamptz);
create index devices_user on devices (user_id);

create table audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references profiles(id),
  action text not null, target_type text, target_id text,
  detail jsonb not null default '{}', created_at timestamptz not null default now());
create index audit_logs_created on audit_logs (created_at desc);

-- ───────── Helper functions (SECURITY DEFINER, fixed search_path) ─────────
create or replace function has_role(r app_role) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from user_roles where user_id = auth.uid() and role = r) $$;

create or replace function has_permission(p text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from user_roles ur join role_permissions rp on rp.role = ur.role
    where ur.user_id = auth.uid() and rp.permission = p)
  and exists (select 1 from profiles where id = auth.uid() and status = 'active') $$;

-- True when the caller may broadcast to `unit`: a grant on that unit or any ancestor.
create or replace function can_broadcast_to(unit uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select has_permission('broadcast.create') and exists (
    select 1 from broadcast_grants g
    join org_units gu on gu.id = g.org_unit_id
    join org_units tu on tu.id = unit
    where g.user_id = auth.uid() and tu.path <@ gu.path) $$;

create or replace function write_audit(a text, t text, tid text, d jsonb default '{}')
returns void language sql security definer set search_path = public as $$
  insert into audit_logs(actor_id, action, target_type, target_id, detail)
  values (auth.uid(), a, t, tid, coalesce(d,'{}')) $$;

-- New auth user: profile + member role + default settings. No unneeded personal data.
create or replace function handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles(id, phone) values (new.id, case when coalesce(new.phone,'') = '' then null when new.phone like '+%' then new.phone else '+' || new.phone end);   -- Supabase stores phones without '+'
  insert into user_roles values (new.id,'member');
  insert into privacy_settings(user_id) values (new.id);
  insert into notification_settings(user_id) values (new.id);
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

-- Users cannot change their own status, verification or phone; only admins can.
create or replace function guard_profile_update() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if not has_permission('users.manage') then
    if new.status is distinct from old.status or new.verified_at is distinct from old.verified_at
       or new.verified_by is distinct from old.verified_by or new.phone is distinct from old.phone then
      raise exception 'Not allowed to change protected profile fields';
    end if;
  else
    if new.status is distinct from old.status then
      perform write_audit('profile.status_changed','profile',new.id::text,
        jsonb_build_object('from',old.status,'to',new.status));
    end if;
    if new.verified_at is distinct from old.verified_at then
      perform write_audit('profile.verification_changed','profile',new.id::text,'{}');
    end if;
  end if;
  return new;
end $$;
create trigger trg_guard_profile before update on profiles
  for each row execute function guard_profile_update();

-- ───────── Row-level security ─────────
alter table org_levels enable row level security;
alter table org_units enable row level security;
alter table profiles enable row level security;
alter table user_roles enable row level security;
alter table user_org_units enable row level security;
alter table permissions enable row level security;
alter table role_permissions enable row level security;
alter table broadcast_grants enable row level security;
alter table privacy_settings enable row level security;
alter table notification_settings enable row level security;
alter table devices enable row level security;
alter table audit_logs enable row level security;

-- Hierarchy and permission catalog: readable by signed-in users, editable by org admins.
create policy levels_read on org_levels for select to authenticated using (true);
create policy levels_write on org_levels for all to authenticated
  using (has_permission('org.manage')) with check (has_permission('org.manage'));
create policy units_read on org_units for select to authenticated using (true);
create policy units_write on org_units for all to authenticated
  using (has_permission('org.manage')) with check (has_permission('org.manage'));
create policy perms_read on permissions for select to authenticated using (true);
create policy roleperms_read on role_permissions for select to authenticated using (true);
create policy roleperms_write on role_permissions for all to authenticated
  using (has_role('super_admin')) with check (has_role('super_admin'));

-- Profiles: own row, or admins. Other members are read through the directory view below.
create policy profiles_self on profiles for select to authenticated using (id = auth.uid());
create policy profiles_admin on profiles for select to authenticated using (has_permission('users.manage'));
create policy profiles_update_self on profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());
create policy profiles_update_admin on profiles for update to authenticated
  using (has_permission('users.manage')) with check (has_permission('users.manage'));

create policy roles_self on user_roles for select to authenticated using (user_id = auth.uid());
create policy roles_admin on user_roles for all to authenticated
  using (has_permission('users.manage')) with check (has_permission('users.manage'));
create policy uou_self on user_org_units for select to authenticated using (user_id = auth.uid());
create policy uou_admin on user_org_units for all to authenticated
  using (has_permission('users.manage')) with check (has_permission('users.manage'));
create policy grants_self on broadcast_grants for select to authenticated using (user_id = auth.uid());
create policy grants_admin on broadcast_grants for all to authenticated
  using (has_permission('users.manage')) with check (has_permission('users.manage'));

create policy privacy_own on privacy_settings for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy notif_own on notification_settings for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy devices_own on devices for select to authenticated using (user_id = auth.uid());
create policy devices_revoke on devices for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Audit logs: admins read; nobody updates or deletes; writes go through write_audit().
create policy audit_read on audit_logs for select to authenticated using (has_permission('audit.read'));

-- Member directory: respects each person's privacy settings. Phone shown only when allowed.
create or replace view directory with (security_invoker = false) as
select p.id, p.full_name, p.avatar_path, p.bio,
       (p.verified_at is not null) as is_verified,
       case when ps.phone_visibility = 'everyone'
              or (ps.phone_visibility = 'leaders' and (has_role('super_admin') or has_role('national_leader')
                  or has_role('regional_leader') or has_role('constituency_executive')))
            then p.phone end as phone
from profiles p join privacy_settings ps on ps.user_id = p.id
where p.status = 'active' and ps.profile_visibility <> 'nobody'
  and exists (select 1 from profiles me where me.id = auth.uid() and me.status = 'active');
revoke all on directory from anon;
grant select on directory to authenticated;

-- Default-deny for anonymous access.
revoke all on all tables in schema public from anon;
