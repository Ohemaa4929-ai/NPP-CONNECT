-- NPP CONNECT, migration 0003: broadcasts, videos, events, polls, reports, notifications, storage, search

create or replace function in_scope(unit uuid) returns boolean   -- true when one of my units is `unit` or below it
language sql stable security definer set search_path = public as $$
  select unit is null or exists (
    select 1 from user_org_units uou join org_units u on u.id = uou.org_unit_id
    join org_units t on t.id = unit where uou.user_id = auth.uid() and u.path <@ t.path) $$;

-- ───────── Broadcasts ─────────
create table broadcasts (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null default auth.uid() references profiles(id),
  org_unit_id uuid references org_units(id),          -- audience root; null = selected groups/users only
  title text not null check (length(title) between 2 and 140), body text not null check (length(body) <= 5000),
  priority text not null default 'normal' check (priority in ('normal','important','urgent')),
  status text not null default 'draft' check (status in ('draft','scheduled','sending','sent','cancelled')),
  scheduled_at timestamptz, published_at timestamptz,
  allow_comments boolean not null default false, allow_forwarding boolean not null default true,
  confidential boolean not null default false, view_count bigint not null default 0,
  created_at timestamptz not null default now());
create index broadcasts_status on broadcasts (status, scheduled_at);
create table broadcast_targets (
  broadcast_id uuid not null references broadcasts(id) on delete cascade,
  target_type text not null check (target_type in ('group','user')), target_id uuid not null,
  primary key (broadcast_id, target_type, target_id));
create table broadcast_files (
  broadcast_id uuid not null references broadcasts(id) on delete cascade,
  file_id uuid not null references files(id) on delete restrict, primary key (broadcast_id, file_id));
create table broadcast_recipients (
  broadcast_id uuid not null references broadcasts(id) on delete cascade,
  user_id uuid not null references profiles(id) on delete cascade,
  delivered_at timestamptz not null default now(), read_at timestamptz,
  primary key (broadcast_id, user_id));
create index br_user on broadcast_recipients (user_id, delivered_at desc);
create table broadcast_comments (
  id uuid primary key default gen_random_uuid(), broadcast_id uuid not null references broadcasts(id) on delete cascade,
  user_id uuid not null default auth.uid() references profiles(id), body text not null check (length(body) between 1 and 1000),
  created_at timestamptz not null default now());
create table broadcast_reactions (
  broadcast_id uuid not null references broadcasts(id) on delete cascade, user_id uuid not null default auth.uid() references profiles(id),
  emoji text not null check (length(emoji) <= 8), primary key (broadcast_id, user_id));

create table broadcast_jobs (
  id uuid primary key default gen_random_uuid(), broadcast_id uuid unique not null references broadcasts(id) on delete cascade,
  status text not null default 'queued' check (status in ('queued','running','done','failed')),
  cursor uuid, total_inserted bigint not null default 0, attempts int not null default 0,
  run_at timestamptz not null default now(), locked_at timestamptz, error text);
create index bj_queue on broadcast_jobs (status, run_at);

create or replace function can_see_broadcast(b uuid) returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from broadcasts where id = b and author_id = auth.uid())
      or exists (select 1 from broadcast_recipients where broadcast_id = b and user_id = auth.uid())
      or has_permission('moderation.review') $$;

alter table broadcasts enable row level security;
alter table broadcast_targets enable row level security;
alter table broadcast_files enable row level security;
alter table broadcast_recipients enable row level security;
alter table broadcast_comments enable row level security;
alter table broadcast_reactions enable row level security;
alter table broadcast_jobs enable row level security;   -- internal; no policies

create policy bc_read on broadcasts for select to authenticated using (can_see_broadcast(id));
create policy bc_insert on broadcasts for insert to authenticated with check (
  author_id = auth.uid() and status = 'draft' and has_permission('broadcast.create')
  and ((org_unit_id is not null and can_broadcast_to(org_unit_id)) or org_unit_id is null));
create policy bc_update on broadcasts for update to authenticated
  using ((author_id = auth.uid() or has_permission('users.manage')) and status in ('draft','scheduled'))
  with check (status in ('draft','scheduled') and (org_unit_id is null or can_broadcast_to(org_unit_id) or has_permission('users.manage')));
revoke update on broadcasts from authenticated;
grant update (title, body, priority, scheduled_at, allow_comments, allow_forwarding, confidential, org_unit_id) on broadcasts to authenticated;
create policy bct_rw on broadcast_targets for all to authenticated
  using (exists (select 1 from broadcasts b where b.id = broadcast_id and b.author_id = auth.uid() and b.status = 'draft'))
  with check (exists (select 1 from broadcasts b where b.id = broadcast_id and b.author_id = auth.uid() and b.status = 'draft'));
create policy bcf_read on broadcast_files for select to authenticated using (can_see_broadcast(broadcast_id));
create policy bcf_write on broadcast_files for insert to authenticated
  with check (exists (select 1 from broadcasts b where b.id = broadcast_id and b.author_id = auth.uid() and b.status = 'draft'));
create policy br_own on broadcast_recipients for select to authenticated
  using (user_id = auth.uid() or exists (select 1 from broadcasts b where b.id = broadcast_id and b.author_id = auth.uid()));
create policy bcm_read on broadcast_comments for select to authenticated using (can_see_broadcast(broadcast_id));
create policy bcm_write on broadcast_comments for insert to authenticated with check (
  user_id = auth.uid() and can_see_broadcast(broadcast_id) and exists (select 1 from broadcasts where id = broadcast_id and allow_comments));
create policy bcx_read on broadcast_reactions for select to authenticated using (can_see_broadcast(broadcast_id));
create policy bcx_write on broadcast_reactions for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid() and can_see_broadcast(broadcast_id));

create or replace function publish_broadcast(b uuid) returns text language plpgsql security definer set search_path = public as $$
declare br broadcasts;
begin
  select * into br from broadcasts where id = b and author_id = auth.uid() and status = 'draft';
  if br.id is null then raise exception 'Broadcast not found or already published.'; end if;
  if not has_permission('broadcast.create') then raise exception 'You do not have permission to broadcast.'; end if;
  if br.org_unit_id is not null and not can_broadcast_to(br.org_unit_id) then raise exception 'You cannot broadcast to that audience.'; end if;
  if br.org_unit_id is null and not exists (select 1 from broadcast_targets where broadcast_id = b) then raise exception 'Choose an audience.'; end if;
  if br.scheduled_at is not null and br.scheduled_at < now() then raise exception 'Scheduled time is in the past.'; end if;
  if not has_role('super_admin') then perform check_rate('broadcast_publish', 10, interval '1 day'); end if;   -- compromised-account brake
  update broadcasts set status = case when scheduled_at is null then 'sending' else 'scheduled' end,
    published_at = case when scheduled_at is null then now() end where id = b;
  insert into broadcast_jobs(broadcast_id, run_at) values (b, coalesce(br.scheduled_at, now()));
  perform write_audit('broadcast.published', 'broadcast', b::text, jsonb_build_object('scheduled', br.scheduled_at is not null));
  return case when br.scheduled_at is null then 'sending' else 'scheduled' end;
end $$;

create or replace function cancel_broadcast(b uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  update broadcasts set status = 'cancelled' where id = b and status in ('draft','scheduled')
    and (author_id = auth.uid() or has_permission('users.manage'));
  delete from broadcast_jobs where broadcast_id = b and status = 'queued';
  perform write_audit('broadcast.cancelled', 'broadcast', b::text, '{}');
end $$;

create or replace function mark_broadcast_read(b uuid) returns void language plpgsql security definer set search_path = public as $$
declare n int;
begin
  update broadcast_recipients set read_at = now() where broadcast_id = b and user_id = auth.uid() and read_at is null;
  get diagnostics n = row_count;
  if n > 0 then update broadcasts set view_count = view_count + 1 where id = b; end if;
end $$;

-- Worker functions: service role only (the Edge Function calls these).
create or replace function claim_broadcast_job() returns broadcast_jobs language sql security definer set search_path = public as $$
  update broadcast_jobs set status = 'running', locked_at = now(), attempts = attempts + 1
  where id = (select id from broadcast_jobs
              where (status = 'queued' and run_at <= now()) or (status = 'running' and locked_at < now() - interval '5 minutes')
              order by run_at for update skip locked limit 1)
  returning * $$;

create or replace function fanout_batch(job uuid, batch int default 2000) returns table (user_id uuid)
language plpgsql security definer set search_path = public as $$
declare j broadcast_jobs; b broadcasts; ids uuid[];
begin
  select * into j from broadcast_jobs where id = job;
  select * into b from broadcasts where id = j.broadcast_id;
  if b.status = 'cancelled' then update broadcast_jobs set status = 'done' where id = job; return; end if;
  update broadcasts set status = 'sending', published_at = coalesce(published_at, now()) where id = b.id and status = 'scheduled';
  select array_agg(x.id order by x.id) into ids from (
    select p.id from profiles p where p.status = 'active' and (j.cursor is null or p.id > j.cursor) and (
      (b.org_unit_id is not null and exists (select 1 from user_org_units uou join org_units u on u.id = uou.org_unit_id
         join org_units t on t.id = b.org_unit_id where uou.user_id = p.id and u.path <@ t.path))
      or exists (select 1 from broadcast_targets bt where bt.broadcast_id = b.id and (
         (bt.target_type = 'user' and bt.target_id = p.id)
         or (bt.target_type = 'group' and exists (select 1 from groups g join conversation_members cm on cm.conversation_id = g.conversation_id
              where g.id = bt.target_id and cm.user_id = p.id and cm.status = 'active')))))
    order by p.id limit batch) x;
  if ids is null then
    update broadcast_jobs set status = 'done' where id = job;
    update broadcasts set status = 'sent' where id = b.id;
    return;
  end if;
  insert into broadcast_recipients(broadcast_id, user_id) select b.id, unnest(ids) on conflict do nothing;
  update broadcast_jobs set cursor = ids[array_length(ids, 1)], total_inserted = total_inserted + array_length(ids, 1),
    status = 'queued', locked_at = null where id = job;   -- requeue: next call continues from the cursor
  return query select unnest(ids);
end $$;

create or replace function push_tokens(b uuid, ids uuid[]) returns table (token text)
language sql security definer set search_path = public as $$
  select d.push_token from devices d
  join notification_settings ns on ns.user_id = d.user_id
  join broadcasts br on br.id = b
  where d.user_id = any (ids) and d.revoked_at is null and d.push_token is not null
    and (ns.mode = 'all' or (ns.mode = 'important' and br.priority <> 'normal')) $$;
revoke all on function claim_broadcast_job(), fanout_batch(uuid, int), push_tokens(uuid, uuid[]) from public, anon, authenticated;

-- ───────── Videos ─────────
create table videos (
  id uuid primary key default gen_random_uuid(), author_id uuid not null default auth.uid() references profiles(id),
  org_unit_id uuid references org_units(id), broadcast_id uuid references broadcasts(id) on delete set null,
  title text not null check (length(title) between 2 and 140), description text check (length(description) <= 1000),
  category text not null default 'other' check (category in ('national_address','regional_address','constituency_address','announcement','training','event','other')),
  file_id uuid not null references files(id), thumb_file_id uuid references files(id), duration_s int,
  view_count bigint not null default 0, published_at timestamptz not null default now(), removed_at timestamptz);
create index videos_pub on videos (published_at desc);
create table video_saves (user_id uuid not null default auth.uid() references profiles(id) on delete cascade,
  video_id uuid not null references videos(id) on delete cascade, primary key (user_id, video_id));
create table video_reactions (user_id uuid not null default auth.uid() references profiles(id) on delete cascade,
  video_id uuid not null references videos(id) on delete cascade, emoji text not null check (length(emoji) <= 8), primary key (user_id, video_id));
alter table videos enable row level security; alter table video_saves enable row level security; alter table video_reactions enable row level security;
create policy vid_read on videos for select to authenticated using (removed_at is null and (in_scope(org_unit_id) or author_id = auth.uid()));
create policy vid_insert on videos for insert to authenticated with check (
  author_id = auth.uid() and has_permission('broadcast.create') and (org_unit_id is null and has_role('super_admin') or can_broadcast_to(org_unit_id)));
create policy vs_own on video_saves for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy vr_own on video_reactions for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create or replace function record_video_view(v uuid) returns void language sql security definer set search_path = public as $$
  update videos set view_count = view_count + 1 where id = v and removed_at is null and in_scope(org_unit_id) $$;

-- ───────── Events ─────────
create table events (
  id uuid primary key default gen_random_uuid(), organizer_id uuid not null default auth.uid() references profiles(id),
  org_unit_id uuid references org_units(id), title text not null check (length(title) between 2 and 140),
  description text check (length(description) <= 3000), starts_at timestamptz not null, ends_at timestamptz,
  location text, image_file_id uuid references files(id), registration_required boolean not null default false, capacity int,
  cancelled_at timestamptz, created_at timestamptz not null default now());
create index events_start on events (starts_at);
create table event_attendees (
  event_id uuid not null references events(id) on delete cascade, user_id uuid not null default auth.uid() references profiles(id) on delete cascade,
  status text not null default 'going' check (status in ('going','maybe','declined')), reminder_at timestamptz,
  created_at timestamptz not null default now(), primary key (event_id, user_id));
alter table events enable row level security; alter table event_attendees enable row level security;
create policy ev_read on events for select to authenticated using (cancelled_at is null and (in_scope(org_unit_id) or organizer_id = auth.uid()));
create policy ev_insert on events for insert to authenticated with check (
  organizer_id = auth.uid() and has_permission('events.create') and (org_unit_id is null and has_role('super_admin') or can_broadcast_to(org_unit_id)));
create policy ev_update on events for update to authenticated using (organizer_id = auth.uid()) with check (organizer_id = auth.uid());
create policy eva_read on event_attendees for select to authenticated using (user_id = auth.uid()
  or exists (select 1 from events e where e.id = event_id and e.organizer_id = auth.uid()));
create policy eva_own on event_attendees for insert to authenticated with check (user_id = auth.uid()
  and exists (select 1 from events e where e.id = event_id and in_scope(e.org_unit_id) and (e.capacity is null or (select count(*) from event_attendees a where a.event_id = e.id and a.status = 'going') < e.capacity)));
create policy eva_upd on event_attendees for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy eva_del on event_attendees for delete to authenticated using (user_id = auth.uid());

-- ───────── Polls ─────────
create table polls (
  id uuid primary key default gen_random_uuid(), created_by uuid not null default auth.uid() references profiles(id),
  conversation_id uuid references conversations(id) on delete cascade, broadcast_id uuid references broadcasts(id) on delete cascade,
  question text not null check (length(question) between 2 and 300), multiple boolean not null default false,
  anonymous boolean not null default false, closes_at timestamptz, created_at timestamptz not null default now(),
  check ((conversation_id is not null) <> (broadcast_id is not null)));
create table poll_options (id uuid primary key default gen_random_uuid(), poll_id uuid not null references polls(id) on delete cascade,
  label text not null check (length(label) between 1 and 120), position smallint not null default 0);
create table poll_votes (poll_id uuid not null references polls(id) on delete cascade, option_id uuid not null references poll_options(id) on delete cascade,
  user_id uuid not null references profiles(id) on delete cascade, voted_at timestamptz not null default now(), primary key (poll_id, option_id, user_id));
create or replace function can_see_poll(p uuid) returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from polls where id = p and ((conversation_id is not null and is_member(conversation_id))
    or (broadcast_id is not null and can_see_broadcast(broadcast_id)))) $$;
alter table polls enable row level security; alter table poll_options enable row level security; alter table poll_votes enable row level security;
create policy poll_read on polls for select to authenticated using (can_see_poll(id));
create policy poll_insert on polls for insert to authenticated with check (created_by = auth.uid() and has_permission('polls.create')
  and ((conversation_id is not null and is_member(conversation_id)) or (broadcast_id is not null and exists (select 1 from broadcasts b where b.id = broadcast_id and b.author_id = auth.uid()))));
create policy po_read on poll_options for select to authenticated using (can_see_poll(poll_id));
create policy po_insert on poll_options for insert to authenticated with check (exists (select 1 from polls p where p.id = poll_id and p.created_by = auth.uid()));
create policy pv_own on poll_votes for select to authenticated using (user_id = auth.uid());   -- individual votes stay private
create or replace function cast_vote(p uuid, opts uuid[]) returns void language plpgsql security definer set search_path = public as $$
declare pl polls;
begin
  select * into pl from polls where id = p;
  if pl.id is null or not can_see_poll(p) then raise exception 'Poll not available.'; end if;
  if pl.closes_at is not null and pl.closes_at < now() then raise exception 'This poll is closed.'; end if;
  if not pl.multiple and array_length(opts, 1) <> 1 then raise exception 'Choose one option.'; end if;
  if exists (select 1 from unnest(opts) o where not exists (select 1 from poll_options where id = o and poll_id = p)) then raise exception 'Invalid option.'; end if;
  delete from poll_votes where poll_id = p and user_id = auth.uid();
  insert into poll_votes(poll_id, option_id, user_id) select p, unnest(opts), auth.uid();
end $$;
create or replace function poll_results(p uuid) returns table (option_id uuid, label text, votes bigint)
language sql stable security definer set search_path = public as $$
  select o.id, o.label, count(v.user_id) from poll_options o left join poll_votes v on v.option_id = o.id
  where o.poll_id = p and can_see_poll(p) group by o.id, o.label, o.position order by o.position $$;

-- ───────── Reports, notifications, devices ─────────
create table reports (
  id uuid primary key default gen_random_uuid(), reporter_id uuid not null default auth.uid() references profiles(id),
  target_type text not null check (target_type in ('message','user','group','broadcast','file','video')), target_id text not null,
  reason text not null check (reason in ('spam','harassment','impersonation','unauthorized_content','fraud','security','other')),
  detail text check (length(detail) <= 1000), status text not null default 'open' check (status in ('open','dismissed','warned','content_removed','suspended')),
  reviewed_by uuid references profiles(id), reviewed_at timestamptz, created_at timestamptz not null default now());
create index reports_open on reports (status, created_at);
alter table reports enable row level security;
create policy rep_insert on reports for insert to authenticated with check (reporter_id = auth.uid() and status = 'open');
create policy rep_read on reports for select to authenticated using (reporter_id = auth.uid() or has_permission('moderation.review'));
create or replace function reports_rate() returns trigger language plpgsql as $$
begin perform check_rate('report', 20, interval '1 day'); return new; end $$;
create trigger trg_rep_rate before insert on reports for each row execute function reports_rate();
create or replace function resolve_report(r uuid, act text, note text default null) returns void
language plpgsql security definer set search_path = public as $$
declare rp reports;
begin
  if not has_permission('moderation.review') then raise exception 'Not allowed.'; end if;
  if act not in ('dismissed','warned','content_removed','suspended') then raise exception 'Invalid action.'; end if;
  select * into rp from reports where id = r;
  if act = 'content_removed' then
    if rp.target_type = 'message' then update messages set deleted_at = now() where id = rp.target_id::uuid;
    elsif rp.target_type = 'video' then update videos set removed_at = now() where id = rp.target_id::uuid;
    elsif rp.target_type = 'broadcast' then update broadcasts set status = 'cancelled' where id = rp.target_id::uuid and status in ('draft','scheduled'); end if;
  end if;
  if act = 'suspended' and rp.target_type = 'user' then perform suspend_user(rp.target_id::uuid, coalesce(note, 'report ' || r::text)); end if;
  update reports set status = act, reviewed_by = auth.uid(), reviewed_at = now() where id = r;
  perform write_audit('report.' || act, 'report', r::text, jsonb_build_object('note', note));
end $$;

create table notifications (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references profiles(id) on delete cascade,
  kind text not null check (kind in ('message','broadcast','video','group','mention','event','poll','security')),
  title text not null, body text, data jsonb not null default '{}', created_at timestamptz not null default now(), read_at timestamptz);
create index notif_user on notifications (user_id, created_at desc);
alter table notifications enable row level security;
create policy n_own on notifications for select to authenticated using (user_id = auth.uid());
create policy n_read on notifications for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
revoke update on notifications from authenticated; grant update (read_at) on notifications to authenticated;
create policy dev_insert on devices for insert to authenticated with check (user_id = auth.uid());
create policy dev_delete on devices for delete to authenticated using (user_id = auth.uid());

-- ───────── Storage: private buckets, folder = owner id ─────────
insert into storage.buckets (id, name, public, file_size_limit)
select b, b, false, 104857600 from unnest(array['profiles','messages','videos','audio','documents','events','groups','broadcasts']) b
on conflict (id) do update set public = false;

create or replace function can_read_file(b text, n text) returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and status = 'active') and (
    b in ('profiles','groups')
    or exists (select 1 from files f where f.bucket = b and (f.path = n or f.thumb_path = n) and f.scan_status <> 'blocked' and (
         f.owner_id = auth.uid()
      or exists (select 1 from message_attachments a where a.file_id = f.id and msg_member(a.message_id))
      or exists (select 1 from broadcast_files bf where bf.file_id = f.id and can_see_broadcast(bf.broadcast_id))
      or exists (select 1 from videos v where (v.file_id = f.id or v.thumb_file_id = f.id) and v.removed_at is null and in_scope(v.org_unit_id))
      or exists (select 1 from events e where e.image_file_id = f.id and in_scope(e.org_unit_id))))) $$;

-- files rows: the owner, or anyone who can read the file through a message, broadcast, video or event
create policy files_read on files for select to authenticated using (owner_id = auth.uid() or can_read_file(bucket, path));

create policy obj_insert on storage.objects for insert to authenticated
  with check (bucket_id in ('profiles','messages','videos','audio','documents','events','groups','broadcasts') and (storage.foldername(name))[1] = auth.uid()::text);
create policy obj_select on storage.objects for select to authenticated
  using ((storage.foldername(name))[1] = auth.uid()::text or can_read_file(bucket_id, name));
create policy obj_delete on storage.objects for delete to authenticated using ((storage.foldername(name))[1] = auth.uid()::text);

-- ───────── Global search (people, groups, messages, broadcasts, videos, documents, events) ─────────
create or replace function search_all(q text, kinds text[] default null) returns table (kind text, id text, title text, snippet text)
language plpgsql stable security definer set search_path = public as $$
declare pat text := '%' || replace(replace(q, '%', ''), '_', '') || '%';
begin
  if length(trim(q)) < 2 or not exists (select 1 from profiles where id = auth.uid() and status = 'active') then return; end if;
  return query
    (select 'people', d.id::text, d.full_name, null::text from directory d where d.full_name ilike pat and (kinds is null or 'people' = any (kinds)) limit 10)
    union all (select 'groups', g.id::text, g.name, g.description from groups g where g.name ilike pat and (is_member(g.conversation_id) or (not g.confidential and g.privacy <> 'private')) and (kinds is null or 'groups' = any (kinds)) limit 10)
    union all (select 'messages', m.id::text, left(m.body, 80), m.conversation_id::text from messages m where m.body ilike pat and is_member(m.conversation_id) and m.deleted_at is null and (kinds is null or 'messages' = any (kinds)) order by m.created_at desc limit 10)
    union all (select 'broadcasts', b.id::text, b.title, left(b.body, 100) from broadcasts b where (b.title ilike pat or b.body ilike pat) and can_see_broadcast(b.id) and b.status in ('sending','sent') and (kinds is null or 'broadcasts' = any (kinds)) limit 10)
    union all (select 'videos', v.id::text, v.title, v.description from videos v where v.title ilike pat and v.removed_at is null and in_scope(v.org_unit_id) and (kinds is null or 'videos' = any (kinds)) limit 10)
    union all (select 'documents', f.id::text, f.name, f.mime from files f where f.name ilike pat and f.kind = 'document' and can_read_file(f.bucket, f.path) and (kinds is null or 'documents' = any (kinds)) limit 10)
    union all (select 'events', e.id::text, e.title, e.location from events e where e.title ilike pat and e.cancelled_at is null and in_scope(e.org_unit_id) and (kinds is null or 'events' = any (kinds)) limit 10);
end $$;
