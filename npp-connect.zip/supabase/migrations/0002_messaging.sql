-- NPP CONNECT, migration 0002: chat, groups, files, rate limits, storage (Phases 2 and 5 parts)
-- Note: group_members and group_admins from the spec are folded into conversation_members (role column).

create table blocks (
  blocker uuid not null references profiles(id) on delete cascade,
  blocked uuid not null references profiles(id) on delete cascade,
  created_at timestamptz not null default now(), primary key (blocker, blocked));
alter table blocks enable row level security;
create policy blocks_own on blocks for all to authenticated
  using (blocker = auth.uid()) with check (blocker = auth.uid());

-- ───────── Rate limiting (MVP: Postgres table; move to Redis if volume demands) ─────────
create table rate_events (
  id bigint generated always as identity primary key,
  user_id uuid not null, key text not null, at timestamptz not null default now());
create index rate_events_idx on rate_events (user_id, key, at desc);
alter table rate_events enable row level security;   -- no policies: internal only
create or replace function check_rate(k text, max_n int, win interval) returns void
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return; end if;
  if (select count(*) from rate_events where user_id = auth.uid() and key = k and at > now() - win) >= max_n then
    raise exception 'rate_limited: slow down and try again later' using errcode = 'P0001';
  end if;
  insert into rate_events(user_id, key) values (auth.uid(), k);
end $$;

-- ───────── Files ─────────
create type media_kind as enum ('image','video','audio','voice','document','other');
create table files (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null default auth.uid() references profiles(id) on delete cascade,
  bucket text not null check (bucket in ('profiles','messages','videos','audio','documents','events','groups','broadcasts')),
  path text not null, name text not null check (length(name) <= 200),
  mime text not null check (mime ~ '^(image/(jpeg|png|webp|heic)|video/(mp4|quicktime)|audio/(mpeg|mp4|aac|m4a|x-m4a|ogg|webm)|application/(pdf|zip|msword|vnd\.ms-excel|vnd\.ms-powerpoint|vnd\.openxmlformats-officedocument\.(wordprocessingml\.document|spreadsheetml\.sheet|presentationml\.presentation)))$'),
  size_bytes bigint not null check (size_bytes between 1 and 104857600),   -- 100 MB cap
  kind media_kind not null, duration_s int, thumb_path text,
  scan_status text not null default 'pending' check (scan_status in ('pending','clean','blocked')),
  created_at timestamptz not null default now(), unique (bucket, path));
create index files_owner on files (owner_id, created_at desc);
alter table files enable row level security;
create policy files_insert on files for insert to authenticated
  with check (owner_id = auth.uid() and path like auth.uid()::text || '/%');
create or replace function files_rate() returns trigger language plpgsql as $$
begin perform check_rate('file_upload', 40, interval '10 minutes'); return new; end $$;
create trigger trg_files_rate before insert on files for each row execute function files_rate();

-- ───────── Conversations ─────────
create type conv_kind as enum ('direct','group','confidential');
create table conversations (
  id uuid primary key default gen_random_uuid(),
  kind conv_kind not null, title text,
  disappear_after interval,                 -- optional disappearing messages
  restrict_forwarding boolean not null default false,
  created_by uuid references profiles(id), created_at timestamptz not null default now(),
  last_message_at timestamptz);
create index conversations_last on conversations (last_message_at desc nulls last);

create table conversation_members (
  conversation_id uuid not null references conversations(id) on delete cascade,
  user_id uuid not null references profiles(id) on delete cascade,
  role text not null default 'member' check (role in ('member','admin')),
  status text not null default 'active' check (status in ('invited','pending','active','removed')),
  last_read_at timestamptz, muted boolean not null default false,
  primary key (conversation_id, user_id));
create index cm_user on conversation_members (user_id, status);

create table groups (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid unique not null references conversations(id) on delete cascade,
  name text not null check (length(name) between 2 and 100), description text check (length(description) <= 500),
  photo_path text, org_unit_id uuid references org_units(id),
  privacy text not null default 'approval' check (privacy in ('open','approval','private')),
  confidential boolean not null default false,
  created_by uuid not null references profiles(id), created_at timestamptz not null default now());
create index groups_name_trgm on groups using gin (name gin_trgm_ops);

create or replace function is_member(c uuid) returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from conversation_members where conversation_id = c and user_id = auth.uid() and status = 'active')
     and exists (select 1 from profiles where id = auth.uid() and status = 'active') $$;
create or replace function is_conv_admin(c uuid) returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from conversation_members where conversation_id = c and user_id = auth.uid() and status = 'active' and role = 'admin') $$;

alter table conversations enable row level security;
alter table conversation_members enable row level security;
alter table groups enable row level security;
create policy conv_read on conversations for select to authenticated using (is_member(id));
create policy cm_read on conversation_members for select to authenticated using (user_id = auth.uid() or is_member(conversation_id));
create policy groups_read on groups for select to authenticated
  using (is_member(conversation_id) or (not confidential and privacy <> 'private'));
create policy groups_admin_update on groups for update to authenticated
  using (is_conv_admin(conversation_id)) with check (is_conv_admin(conversation_id));
-- No direct inserts or deletes: use the functions below.

-- ───────── Messages ─────────
create type msg_kind as enum ('text','image','video','audio','voice','document','link');
create table messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references conversations(id) on delete cascade,
  sender_id uuid not null default auth.uid() references profiles(id),
  kind msg_kind not null default 'text', body text check (length(body) <= 4000),
  reply_to uuid references messages(id) on delete set null,
  forwarded_from uuid references messages(id) on delete set null,
  pinned boolean not null default false, deleted_at timestamptz, expires_at timestamptz,
  client_id uuid,                          -- idempotency key for offline retries
  created_at timestamptz not null default now(),
  unique (sender_id, client_id));
create index messages_page on messages (conversation_id, created_at desc, id desc);   -- cursor pagination
create index messages_body_trgm on messages using gin (body gin_trgm_ops);
create table message_attachments (
  message_id uuid not null references messages(id) on delete cascade,
  file_id uuid not null references files(id) on delete restrict, primary key (message_id, file_id));
create table message_reactions (
  message_id uuid not null references messages(id) on delete cascade,
  user_id uuid not null default auth.uid() references profiles(id) on delete cascade,
  emoji text not null check (length(emoji) <= 8), primary key (message_id, user_id, emoji));

create or replace function msg_member(m uuid) returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from messages where id = m and is_member(conversation_id)) $$;

alter table messages enable row level security;
alter table message_attachments enable row level security;
alter table message_reactions enable row level security;
create policy msg_read on messages for select to authenticated
  using (is_member(conversation_id) and deleted_at is null and (expires_at is null or expires_at > now()));
create policy msg_insert on messages for insert to authenticated
  with check (sender_id = auth.uid() and is_member(conversation_id));
create policy att_read on message_attachments for select to authenticated using (msg_member(message_id));
create policy att_insert on message_attachments for insert to authenticated
  with check (exists (select 1 from messages m where m.id = message_id and m.sender_id = auth.uid()));
create policy react_read on message_reactions for select to authenticated using (msg_member(message_id));
create policy react_write on message_reactions for insert to authenticated with check (user_id = auth.uid() and msg_member(message_id));
create policy react_del on message_reactions for delete to authenticated using (user_id = auth.uid());

create or replace function messages_before_insert() returns trigger language plpgsql security definer set search_path = public as $$
declare c conversations; other uuid;
begin
  perform check_rate('message', 60, interval '1 minute');
  select * into c from conversations where id = new.conversation_id;
  if c.kind = 'direct' then
    select user_id into other from conversation_members where conversation_id = c.id and user_id <> new.sender_id limit 1;
    if exists (select 1 from blocks where (blocker = other and blocked = new.sender_id) or (blocker = new.sender_id and blocked = other)) then
      raise exception 'You cannot message this person.'; end if;
  end if;
  if c.disappear_after is not null then new.expires_at := now() + c.disappear_after; end if;
  return new;
end $$;
create trigger trg_msg_before before insert on messages for each row execute function messages_before_insert();
create or replace function messages_after_insert() returns trigger language plpgsql security definer set search_path = public as $$
begin update conversations set last_message_at = new.created_at where id = new.conversation_id; return new; end $$;
create trigger trg_msg_after after insert on messages for each row execute function messages_after_insert();

-- ───────── Conversation and group functions ─────────
create or replace function start_direct(other uuid) returns uuid language plpgsql security definer set search_path = public as $$
declare cid uuid;
begin
  perform check_rate('start_direct', 30, interval '1 hour');
  if other = auth.uid() then raise exception 'Invalid recipient'; end if;
  if not exists (select 1 from profiles where id = other and status = 'active') then raise exception 'Person not available'; end if;
  if exists (select 1 from blocks where (blocker = other and blocked = auth.uid()) or (blocker = auth.uid() and blocked = other)) then
    raise exception 'You cannot message this person.'; end if;
  select c.id into cid from conversations c where c.kind = 'direct'
    and exists (select 1 from conversation_members where conversation_id = c.id and user_id = auth.uid())
    and exists (select 1 from conversation_members where conversation_id = c.id and user_id = other) limit 1;
  if cid is not null then return cid; end if;
  insert into conversations(kind, created_by) values ('direct', auth.uid()) returning id into cid;
  insert into conversation_members(conversation_id, user_id) values (cid, auth.uid()), (cid, other);
  return cid;
end $$;

create or replace function create_group(p_name text, p_desc text, p_unit uuid, p_privacy text, p_confidential boolean, p_photo text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare cid uuid; gid uuid;
begin
  if not has_permission('groups.create') then raise exception 'You do not have permission to create groups.'; end if;
  perform check_rate('create_group', 10, interval '1 day');
  if p_unit is not null and not (exists (select 1 from user_org_units where user_id = auth.uid() and org_unit_id = p_unit) or can_broadcast_to(p_unit)) then
    raise exception 'You can only create groups for your own area.'; end if;
  insert into conversations(kind, title, created_by, restrict_forwarding)
    values (case when p_confidential then 'confidential' else 'group' end::conv_kind, p_name, auth.uid(), p_confidential) returning id into cid;
  insert into groups(conversation_id, name, description, org_unit_id, privacy, confidential, created_by, photo_path)
    values (cid, p_name, p_desc, p_unit, case when p_confidential then 'private' else p_privacy end, p_confidential, auth.uid(), p_photo) returning id into gid;
  insert into conversation_members(conversation_id, user_id, role) values (cid, auth.uid(), 'admin');
  perform write_audit('group.created', 'group', gid::text, jsonb_build_object('confidential', p_confidential));
  return gid;
end $$;

create or replace function join_group(g uuid) returns text language plpgsql security definer set search_path = public as $$
declare gr groups; st text;
begin
  select * into gr from groups where id = g;
  if gr.id is null or gr.confidential or gr.privacy = 'private' then raise exception 'This group is by invitation only.'; end if;
  st := case gr.privacy when 'open' then 'active' else 'pending' end;
  insert into conversation_members(conversation_id, user_id, status) values (gr.conversation_id, auth.uid(), st)
    on conflict (conversation_id, user_id) do update set status = excluded.status where conversation_members.status = 'removed' is false and conversation_members.status <> 'active';
  return st;
end $$;

create or replace function add_member(c uuid, u uuid) returns void language plpgsql security definer set search_path = public as $$
declare conf boolean;
begin
  if not is_conv_admin(c) then raise exception 'Only group admins can add members.'; end if;
  if exists (select 1 from privacy_settings where user_id = u and group_invites = 'nobody') then raise exception 'This person does not accept group invitations.'; end if;
  select confidential into conf from groups where conversation_id = c;
  insert into conversation_members(conversation_id, user_id, status) values (c, u, case when coalesce(conf, false) then 'invited' else 'active' end)
    on conflict (conversation_id, user_id) do update set status = excluded.status;
  insert into audit_logs(actor_id, action, target_type, target_id) values (auth.uid(), 'group.member_added', 'conversation', c::text);
end $$;
create or replace function accept_invite(c uuid) returns void language sql security definer set search_path = public as $$
  update conversation_members set status = 'active' where conversation_id = c and user_id = auth.uid() and status = 'invited' $$;
create or replace function approve_member(c uuid, u uuid) returns void language sql security definer set search_path = public as $$
  update conversation_members set status = 'active' where conversation_id = c and user_id = u and status = 'pending' and is_conv_admin(c) $$;
create or replace function remove_member(c uuid, u uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  if u <> auth.uid() and not is_conv_admin(c) then raise exception 'Not allowed.'; end if;
  update conversation_members set status = 'removed' where conversation_id = c and user_id = u;
  insert into audit_logs(actor_id, action, target_type, target_id, detail) values (auth.uid(), 'group.member_removed', 'conversation', c::text, jsonb_build_object('user', u));
end $$;
create or replace function mark_read(c uuid) returns void language sql security definer set search_path = public as $$
  update conversation_members set last_read_at = now() where conversation_id = c and user_id = auth.uid() $$;
create or replace function delete_message(m uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  update messages set deleted_at = now() where id = m and (sender_id = auth.uid() or is_conv_admin(conversation_id));
end $$;
create or replace function pin_message(m uuid, v boolean) returns void language plpgsql security definer set search_path = public as $$
begin update messages set pinned = v where id = m and is_conv_admin(conversation_id); end $$;
create or replace function set_disappearing(c uuid, secs int) returns void language plpgsql security definer set search_path = public as $$
begin
  if not is_conv_admin(c) then raise exception 'Only admins can change this.'; end if;
  update conversations set disappear_after = case when secs > 0 then make_interval(secs => secs) end where id = c;
  insert into audit_logs(actor_id, action, target_type, target_id, detail) values (auth.uid(), 'conversation.disappearing_changed', 'conversation', c::text, jsonb_build_object('secs', secs));
end $$;
create or replace function forward_message(m uuid, to_conv uuid) returns uuid language plpgsql security definer set search_path = public as $$
declare src messages; nid uuid;
begin
  select * into src from messages where id = m and deleted_at is null;
  if src.id is null or not is_member(src.conversation_id) or not is_member(to_conv) then raise exception 'Not allowed.'; end if;
  if (select restrict_forwarding from conversations where id = src.conversation_id) then raise exception 'Forwarding is turned off for this chat.'; end if;
  insert into messages(conversation_id, sender_id, kind, body, forwarded_from) values (to_conv, auth.uid(), src.kind, src.body, src.id) returning id into nid;
  insert into message_attachments select nid, file_id from message_attachments where message_id = src.id;
  return nid;
end $$;

alter publication supabase_realtime add table messages, message_reactions;   -- Realtime honors the RLS policies above
