-- NPP CONNECT, migration 0004: admin security, 2FA enforcement, suspension, stats, retention jobs

-- Admin-level permissions need an AAL2 session (password/OTP plus TOTP). Replaces the 0001 function.
create or replace function has_permission(p text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from user_roles ur join role_permissions rp on rp.role = ur.role
    where ur.user_id = auth.uid() and rp.permission = p)
  and exists (select 1 from profiles where id = auth.uid() and status = 'active')
  and (p not in ('users.manage','org.manage','audit.read','moderation.review')
       or coalesce(auth.jwt() ->> 'aal', '') = 'aal2'
       or coalesce(current_setting('app.require_admin_mfa', true), 'on') = 'off') $$;
-- DEV ONLY: `alter database postgres set app.require_admin_mfa = 'off';` Never on staging or production.

create or replace function suspend_user(u uuid, reason text default null) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not has_permission('users.manage') then raise exception 'Not allowed.'; end if;
  if u = auth.uid() then raise exception 'You cannot suspend yourself.'; end if;
  update profiles set status = 'suspended' where id = u;
  update devices set revoked_at = now() where user_id = u and revoked_at is null;
  insert into notifications(user_id, kind, title, body) values (u, 'security', 'Account suspended', 'Contact your administrator.');
  perform write_audit('user.suspended', 'profile', u::text, jsonb_build_object('reason', reason));
end $$;
create or replace function reactivate_user(u uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  if not has_permission('users.manage') then raise exception 'Not allowed.'; end if;
  update profiles set status = 'active' where id = u;
  perform write_audit('user.reactivated', 'profile', u::text, '{}');
end $$;
create or replace function remove_user(u uuid, reason text default null) returns void language plpgsql security definer set search_path = public as $$
begin   -- soft removal; hard deletion for data-protection requests is a separate, audited procedure
  if not has_permission('users.manage') then raise exception 'Not allowed.'; end if;
  if u = auth.uid() then raise exception 'You cannot remove yourself.'; end if;
  update profiles set status = 'removed', full_name = '', bio = null, avatar_path = null where id = u;
  update devices set revoked_at = now(), push_token = null where user_id = u;
  update conversation_members set status = 'removed' where user_id = u;
  perform write_audit('user.removed', 'profile', u::text, jsonb_build_object('reason', reason));
end $$;
create or replace function verify_user(u uuid, v boolean) returns void language plpgsql security definer set search_path = public as $$
begin
  if not has_permission('users.manage') then raise exception 'Not allowed.'; end if;
  update profiles set verified_at = case when v then now() end, verified_by = case when v then auth.uid() end,
    status = case when v and status = 'pending' then 'active' else status end where id = u;
end $$;
create or replace function revoke_device(d uuid) returns void language sql security definer set search_path = public as $$
  update devices set revoked_at = now(), push_token = null where id = d and (user_id = auth.uid() or has_permission('users.manage')) $$;
create or replace function revoke_all_sessions(u uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  if u <> auth.uid() and not has_permission('users.manage') then raise exception 'Not allowed.'; end if;
  update devices set revoked_at = now(), push_token = null where user_id = u and revoked_at is null;
  delete from auth.sessions where user_id = u;
  perform write_audit('user.sessions_revoked', 'profile', u::text, '{}');
end $$;

-- Audit the sensitive tables automatically.
create or replace function audit_row() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into audit_logs(actor_id, action, target_type, target_id, detail)
  values (auth.uid(), tg_table_name || '.' || lower(tg_op), tg_table_name, coalesce((to_jsonb(new) ->> 'user_id'), (to_jsonb(old) ->> 'user_id')),
          jsonb_build_object('row', case when tg_op = 'DELETE' then to_jsonb(old) else to_jsonb(new) end));
  if tg_op = 'DELETE' then return old; end if;
  return new;
end $$;
create trigger trg_audit_roles after insert or update or delete on user_roles for each row execute function audit_row();
create trigger trg_audit_grants after insert or update or delete on broadcast_grants for each row execute function audit_row();
create trigger trg_audit_uou after insert or update or delete on user_org_units for each row execute function audit_row();
create trigger trg_audit_rp after insert or update or delete on role_permissions for each row execute function audit_row();

create or replace function admin_stats() returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if not has_permission('users.manage') then raise exception 'Not allowed.'; end if;
  return jsonb_build_object(
    'users', (select count(*) from profiles where status <> 'removed'),
    'active_7d', (select count(*) from profiles where last_seen_at > now() - interval '7 days'),
    'verified', (select count(*) from profiles where verified_at is not null),
    'suspended', (select count(*) from profiles where status = 'suspended'),
    'pending', (select count(*) from profiles where status = 'pending'),
    'by_role', (select coalesce(jsonb_object_agg(role::text, n), '{}') from (select role, count(*) n from user_roles group by role) r),
    'groups', (select count(*) from groups), 'broadcasts', (select count(*) from broadcasts where status in ('sending','sent')),
    'messages', (select count(*) from messages), 'videos', (select count(*) from videos where removed_at is null),
    'storage_bytes', (select coalesce(sum(size_bytes), 0) from files), 'open_reports', (select count(*) from reports where status = 'open'));
end $$;

-- Security notification when a new device registers.
create or replace function notify_new_device() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into notifications(user_id, kind, title, body) values (new.user_id, 'security', 'New device signed in', coalesce(new.label, 'A new device') || ' was added to your account.');
  return new;
end $$;
create trigger trg_new_device after insert on devices for each row execute function notify_new_device();

-- Retention jobs (needs pg_cron, enable under Database > Extensions).
create or replace function purge_expired() returns void language plpgsql security definer set search_path = public as $$
begin
  delete from messages where expires_at is not null and expires_at < now();
  delete from rate_events where at < now() - interval '2 days';
  delete from notifications where created_at < now() - interval '180 days';
end $$;
revoke all on function purge_expired() from public, anon, authenticated;
do $$ begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    perform cron.schedule('npp-purge', '*/10 * * * *', 'select purge_expired()');
  end if;
end $$;

-- Let migrations, seeds and the service role (no auth.uid()) edit protected profile fields.
create or replace function guard_profile_update() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return new; end if;
  if not has_permission('users.manage') then
    if new.status is distinct from old.status or new.verified_at is distinct from old.verified_at
       or new.verified_by is distinct from old.verified_by or new.phone is distinct from old.phone then
      raise exception 'Not allowed to change protected profile fields';
    end if;
  else
    if new.status is distinct from old.status then
      perform write_audit('profile.status_changed','profile',new.id::text, jsonb_build_object('from',old.status,'to',new.status)); end if;
    if new.verified_at is distinct from old.verified_at then
      perform write_audit('profile.verification_changed','profile',new.id::text,'{}'); end if;
  end if;
  return new;
end $$;
