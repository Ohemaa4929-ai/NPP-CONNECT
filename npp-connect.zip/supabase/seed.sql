-- DEV SEED: fictional DEMO data only. Do not run in production.
insert into org_units (id, parent_id, level_rank, name, code) values
  ('00000000-0000-0000-0000-000000000001', null, 1, 'Demo Nation', 'DEMO-N'),
  ('00000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000001', 2, 'Demo Region', 'DEMO-R'),
  ('00000000-0000-0000-0000-000000000003', '00000000-0000-0000-0000-000000000002', 3, 'Demo North Constituency', 'DEMO-C'),
  ('00000000-0000-0000-0000-000000000004', '00000000-0000-0000-0000-000000000003', 4, 'Demo Electoral Area', 'DEMO-E'),
  ('00000000-0000-0000-0000-000000000005', '00000000-0000-0000-0000-000000000004', 5, 'Demo Polling Station DS-001', 'DS-001')
on conflict do nothing;
-- Demo users (fake test numbers 233200000001..06; list them as test OTP numbers, code 123456)
insert into auth.users (id, instance_id, aud, role, phone, phone_confirmed_at, created_at, updated_at, raw_app_meta_data, raw_user_meta_data)
select ('10000000-0000-0000-0000-00000000000' || n)::uuid, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
       '23320000000' || n, now(), now(), now(), '{"provider":"phone","providers":["phone"]}', '{}'
from generate_series(1, 6) n on conflict do nothing;
update profiles set status = 'active', verified_at = now() where id::text like '10000000-%';
update profiles p set full_name = v.name from (values
  ('10000000-0000-0000-0000-000000000001','National Leader Demo'),('10000000-0000-0000-0000-000000000002','Regional Leader Demo'),
  ('10000000-0000-0000-0000-000000000003','Constituency Executive Demo'),('10000000-0000-0000-0000-000000000004','Electoral Area Coordinator Demo'),
  ('10000000-0000-0000-0000-000000000005','Polling Station Executive Demo'),('10000000-0000-0000-0000-000000000006','Grassroots Member Demo')) v(id, name)
where p.id = v.id::uuid;
update profiles set verified_at = null where id = '10000000-0000-0000-0000-000000000006';
delete from user_roles where user_id::text like '10000000-%';
insert into user_roles values
  ('10000000-0000-0000-0000-000000000001','national_leader'),('10000000-0000-0000-0000-000000000002','regional_leader'),
  ('10000000-0000-0000-0000-000000000003','constituency_executive'),('10000000-0000-0000-0000-000000000004','electoral_area_coordinator'),
  ('10000000-0000-0000-0000-000000000005','polling_station_executive'),('10000000-0000-0000-0000-000000000006','member');
insert into user_org_units values
  ('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000001',true),
  ('10000000-0000-0000-0000-000000000002','00000000-0000-0000-0000-000000000002',true),
  ('10000000-0000-0000-0000-000000000003','00000000-0000-0000-0000-000000000003',true),
  ('10000000-0000-0000-0000-000000000004','00000000-0000-0000-0000-000000000004',true),
  ('10000000-0000-0000-0000-000000000005','00000000-0000-0000-0000-000000000005',true),
  ('10000000-0000-0000-0000-000000000006','00000000-0000-0000-0000-000000000005',true);
insert into broadcast_grants (user_id, org_unit_id, granted_by) values
  ('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000001'),
  ('10000000-0000-0000-0000-000000000002','00000000-0000-0000-0000-000000000002','10000000-0000-0000-0000-000000000001'),
  ('10000000-0000-0000-0000-000000000003','00000000-0000-0000-0000-000000000003','10000000-0000-0000-0000-000000000001');
insert into broadcasts (id, author_id, org_unit_id, title, body, priority, status, published_at) values
  ('20000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000001',
   'Important Leadership Update','Welcome to NPP CONNECT. This is a demonstration of the leadership broadcast system.','urgent','sent', now());
insert into broadcast_recipients (broadcast_id, user_id) select '20000000-0000-0000-0000-000000000001', id from profiles where id::text like '10000000-%';
