-- pgTAP tests. Run with: supabase test db   (after seed.sql). Dev only; set app.require_admin_mfa = 'off' for admin cases.
begin;
select plan(8);
create or replace function pg_temp.as_user(u text) returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claims', json_build_object('sub', u, 'role', 'authenticated', 'aal', 'aal1')::text, true);
  set local role authenticated;
end $$;

select pg_temp.as_user('10000000-0000-0000-0000-000000000006');   -- grassroots member
select is((select count(*)::int from profiles), 1, 'member sees only their own profile row');
select throws_ok($$update profiles set status = 'active', verified_at = now() where id = auth.uid()$$, null, 'member cannot self-verify');
select throws_ok($$insert into broadcasts(title, body, org_unit_id) values ('x1','spoof','00000000-0000-0000-0000-000000000001')$$, null, 'member cannot broadcast');
select is((select count(*)::int from broadcasts), 1, 'member sees broadcast they received');
select is((select count(*)::int from audit_logs), 0, 'member cannot read audit logs');
select is((select count(*)::int from rate_events), 0, 'member cannot read rate table');

select pg_temp.as_user('10000000-0000-0000-0000-000000000003');   -- constituency exec
select throws_ok($$insert into broadcasts(title, body, org_unit_id) values ('too wide','x','00000000-0000-0000-0000-000000000001')$$, null, 'constituency exec cannot broadcast nationally');
select lives_ok($$insert into broadcasts(title, body, org_unit_id) values ('ok title','x','00000000-0000-0000-0000-000000000003')$$, 'constituency exec can broadcast to own constituency');
select * from finish();
rollback;
