import { Text } from 'react-native';
import { AuthFrame, Button } from '@/ui/form';
import { useTheme } from '@/ui/theme';
import { useAuth } from '@/lib/auth';

export default function Blocked() {
  const t = useTheme(); const { signOut } = useAuth();
  return <AuthFrame title="Account unavailable">
    <Text style={{ color: t.text, textAlign: 'center' }}>You do not have permission to use this account. Contact your administrator.</Text>
    <Button label="Log out" tone="blue" onPress={signOut} />
  </AuthFrame>;
}
