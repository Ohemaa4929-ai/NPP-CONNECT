import { useEffect, useState } from 'react';
import { FlatList, ScrollView, TextInput } from 'react-native';
import { useRouter } from 'expo-router';
import { Chip, Page, Row, State } from '@/ui/parts';
import { useTheme } from '@/ui/theme';
import { repo } from '@/data/repo';
import type { Hit } from '@/data/types';

const TABS: [string, string][] = [['', 'All'], ['people', 'People'], ['groups', 'Groups'], ['messages', 'Messages'], ['broadcasts', 'Broadcasts'], ['videos', 'Videos'], ['documents', 'Documents'], ['events', 'Events']];
export default function Search() {
  const t = useTheme(); const r = useRouter(); const [q, setQ] = useState(''); const [tab, setTab] = useState(''); const [hits, setHits] = useState<Hit[]>([]); const [busy, setBusy] = useState(false); const [err, setErr] = useState<string | null>(null);
  useEffect(() => { if (q.trim().length < 2) { setHits([]); return; } setBusy(true);
    const h = setTimeout(() => repo.search(q.trim(), tab ? [tab] : undefined).then((x) => { setHits(x); setErr(null); }).catch((e) => setErr(e.message)).finally(() => setBusy(false)), 300); return () => clearTimeout(h); }, [q, tab]);
  const open = (h: Hit) => { if (h.kind === 'broadcasts') r.push({ pathname: '/broadcast/[id]', params: { id: h.id } }); else if (h.kind === 'videos') r.push('/videos'); else if (h.kind === 'events') r.push('/events'); else if (h.kind === 'documents') r.push('/documents'); else if (h.kind === 'messages' && h.snippet) r.push({ pathname: '/chat/[id]', params: { id: h.snippet } }); else if (h.kind === 'people') repo.startDirect(h.id).then((id) => r.push({ pathname: '/chat/[id]', params: { id, title: h.title } })); };
  return <Page title="Search">
    <TextInput autoFocus value={q} onChangeText={setQ} placeholder="Search people, groups, messages, videos…" placeholderTextColor={t.muted} accessibilityLabel="Search" style={{ margin: 12, padding: 12, borderRadius: 10, backgroundColor: t.bg2, color: t.text }} />
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flexGrow: 0 }} contentContainerStyle={{ paddingHorizontal: 12, gap: 6 }}>{TABS.map(([k, l]) => <Chip key={k} label={l} on={tab === k} onPress={() => setTab(k)} />)}</ScrollView>
    <State loading={busy} error={err} empty={q.trim().length >= 2 && !hits.length} emptyText="No results.">
      <FlatList data={hits} keyExtractor={(h) => h.kind + h.id} renderItem={({ item }) => <Row title={item.title} sub={`${item.kind}${item.snippet && item.kind !== 'messages' ? ' · ' + item.snippet : ''}`} onPress={() => open(item)} />} /></State></Page>;
}
