import { useCallback, useState } from 'react';
import { FlatList, Modal, Pressable, Text, TextInput, View } from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { Screen, Row, State } from '@/ui/parts';
import { useTheme } from '@/ui/theme';
import { repo } from '@/data/repo';
import { useAsync, when } from '@/lib/useAsync';
import type { Person } from '@/data/types';

export default function Chats() {
  const t = useTheme(); const r = useRouter(); const { data, loading, error, reload } = useAsync(() => repo.chats(), []);
  const [open, setOpen] = useState(false); const [q, setQ] = useState(''); const [ppl, setPpl] = useState<Person[]>([]);
  useFocusEffect(useCallback(() => { reload(); }, [])); // eslint-disable-line
  const go = async (p: Person) => { setOpen(false); try { const id = await repo.startDirect(p.id); r.push({ pathname: '/chat/[id]', params: { id, title: p.name } }); } catch (e) { alert(e instanceof Error ? e.message : 'Unable to start chat.'); } };
  return <Screen>
    <State loading={loading} error={error} reload={reload} empty={!data?.length} emptyText="No conversations yet.">
      <FlatList data={data} keyExtractor={(c) => c.id} onRefresh={reload} refreshing={false} renderItem={({ item }) =>
        <Row title={(item.kind === 'confidential' ? '🔒 ' : '') + item.title} sub={item.last ?? 'Voice, photo or file'} onPress={() => r.push({ pathname: '/chat/[id]', params: { id: item.id, title: item.title } })}
          right={<View style={{ alignItems: 'flex-end' }}>{item.lastAt && <Text style={{ color: t.muted, fontSize: 11 }}>{when(item.lastAt)}</Text>}{item.unread > 0 && <View style={{ backgroundColor: t.red, borderRadius: 99, paddingHorizontal: 7, marginTop: 4 }}><Text style={{ color: '#fff', fontWeight: '700' }}>{item.unread}</Text></View>}</View>} />} /></State>
    <Pressable accessibilityRole="button" accessibilityLabel="New chat" onPress={() => setOpen(true)} style={{ position: 'absolute', right: 18, bottom: 18, width: 56, height: 56, borderRadius: 28, backgroundColor: t.red, alignItems: 'center', justifyContent: 'center' }}><Text style={{ color: '#fff', fontSize: 26 }}>＋</Text></Pressable>
    <Modal visible={open} animationType="slide" onRequestClose={() => setOpen(false)}><View style={{ flex: 1, backgroundColor: t.bg, padding: 16, paddingTop: 60 }}>
      <Text style={{ color: t.text, fontSize: 18, fontWeight: '800', marginBottom: 8 }}>New chat</Text>
      <TextInput autoFocus value={q} onChangeText={async (v) => { setQ(v); setPpl(v.length > 1 ? await repo.people(v) : []); }} placeholder="Search by name" placeholderTextColor={t.muted} style={{ backgroundColor: t.bg2, color: t.text, padding: 12, borderRadius: 10 }} />
      {ppl.map((p) => <Row key={p.id} title={p.name + (p.verified ? ' ✓' : '')} sub="Tap to message" onPress={() => go(p)} />)}
      <Pressable onPress={() => setOpen(false)} style={{ padding: 16 }}><Text style={{ color: t.red }}>Close</Text></Pressable></View></Modal></Screen>;
}
