import { Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Screen, Row, State, Verified } from '@/ui/parts';
import { Button } from '@/ui/form';
import { useTheme } from '@/ui/theme';
import { useAuth } from '@/lib/auth';
import { repo } from '@/data/repo';
import { useAsync } from '@/lib/useAsync';

export default function Profile() {
  const t = useTheme(); const r = useRouter(); const { signOut } = useAuth(); const p = useAsync(() => repo.profile(), []);
  const ini = (p.data?.full_name ?? '?').split(' ').map((x) => x[0]).slice(0, 2).join('');
  return <Screen><State loading={p.loading} error={p.error} reload={p.reload}>
    <View style={{ alignItems: 'center', padding: 20 }}>
      <View style={{ width: 76, height: 76, borderRadius: 38, backgroundColor: t.blue, alignItems: 'center', justifyContent: 'center' }}><Text style={{ color: '#fff', fontSize: 26, fontWeight: '800' }}>{ini}</Text></View>
      <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center', marginTop: 8 }}><Text style={{ color: t.text, fontSize: 18, fontWeight: '800' }}>{p.data?.full_name}</Text>{p.data?.verified_at && <Verified />}</View>
      <Text style={{ color: t.muted }}>{p.data?.verified_at ? 'Verified leader' : 'Member'}</Text></View>
    <Row title="Account" sub="Name, bio" onPress={() => r.push('/settings/account')} /><Row title="Privacy" sub="Who sees what" onPress={() => r.push('/settings/privacy')} />
    <Row title="Security" sub="Devices and sessions" onPress={() => r.push('/settings/security')} /><Row title="Notifications" sub="Preferences" onPress={() => r.push('/settings/notifications')} />
    <View style={{ padding: 14 }}><Button label="Log out" tone="blue" onPress={signOut} /></View></State></Screen>;
}
