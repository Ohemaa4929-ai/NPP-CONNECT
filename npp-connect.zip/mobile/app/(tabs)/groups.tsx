import { useState } from 'react';
import { FlatList, Modal, Pressable, Switch, Text, TextInput, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Chip, Screen, Row, State } from '@/ui/parts';
import { Button } from '@/ui/form';
import { useTheme } from '@/ui/theme';
import { repo } from '@/data/repo';
import { useAsync } from '@/lib/useAsync';

export default function Groups() {
  const t = useTheme(); const r = useRouter(); const { data, loading, error, reload } = useAsync(() => repo.groups(), []);
  const units = useAsync(() => repo.units(), []);
  const [open, setOpen] = useState(false); const [name, setName] = useState(''); const [desc, setDesc] = useState(''); const [priv, setPriv] = useState('approval'); const [conf, setConf] = useState(false); const [unit, setUnit] = useState<string | null>(null); const [err, setErr] = useState('');
  const create = async () => { try { await repo.createGroup({ name, desc, unit, privacy: priv, confidential: conf }); setOpen(false); setName(''); reload(); } catch (e) { setErr(e instanceof Error ? e.message : 'Could not create group.'); } };
  const inp = { backgroundColor: t.bg2, color: t.text, padding: 12, borderRadius: 10, marginBottom: 8 } as const;
  return <Screen>
    <State loading={loading} error={error} reload={reload} empty={!data?.length} emptyText="No groups yet.">
      <FlatList data={data} keyExtractor={(g) => g.id} onRefresh={reload} refreshing={false} renderItem={({ item: g }) =>
        <Row title={(g.confidential ? '🔒 ' : '') + g.name} sub={(g.confidential ? 'Confidential · ' : '') + (g.description ?? '')}
          onPress={() => g.member ? r.push({ pathname: '/group/[id]', params: { id: g.id, conv: g.conversationId, name: g.name } }) : repo.joinGroup(g.id).then((s) => { alert(s === 'active' ? 'You joined the group.' : 'Request sent. An admin will review it.'); reload(); }).catch((e) => alert(e.message))}
          right={g.member ? undefined : <Text style={{ color: t.blue, fontWeight: '700' }}>Join</Text>} />} /></State>
    <Pressable accessibilityRole="button" accessibilityLabel="Create group" onPress={() => setOpen(true)} style={{ position: 'absolute', right: 18, bottom: 18, width: 56, height: 56, borderRadius: 28, backgroundColor: t.red, alignItems: 'center', justifyContent: 'center' }}><Text style={{ color: '#fff', fontSize: 26 }}>＋</Text></Pressable>
    <Modal visible={open} animationType="slide" onRequestClose={() => setOpen(false)}><View style={{ flex: 1, backgroundColor: t.bg, padding: 16, paddingTop: 60, gap: 4 }}>
      <Text style={{ color: t.text, fontSize: 18, fontWeight: '800', marginBottom: 8 }}>Create group</Text>
      <TextInput value={name} onChangeText={setName} placeholder="Group name" placeholderTextColor={t.muted} style={inp} />
      <TextInput value={desc} onChangeText={setDesc} placeholder="Description" placeholderTextColor={t.muted} style={inp} />
      <Text style={{ color: t.text, fontWeight: '600' }}>Area (optional)</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 8 }}><Chip label="None" on={unit === null} onPress={() => setUnit(null)} />{units.data?.map((u) => <Chip key={u.id} label={u.name} on={unit === u.id} onPress={() => setUnit(u.id)} />)}</View>
      <Text style={{ color: t.text, fontWeight: '600' }}>Who can join</Text>
      <View style={{ flexDirection: 'row', gap: 6, marginBottom: 8 }}>{[['open', 'Anyone'], ['approval', 'Admin approval'], ['private', 'Invitation']].map(([k, l]) => <Chip key={k} label={l} on={priv === k} onPress={() => setPriv(k)} />)}</View>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}><Text style={{ color: t.text, flex: 1 }}>🔒 Confidential: invitation only, no forwarding, optional disappearing messages</Text><Switch value={conf} onValueChange={setConf} /></View>
      {!!err && <Text accessibilityRole="alert" style={{ color: t.red }}>{err}</Text>}
      <Button label="Create" onPress={create} disabled={name.trim().length < 2} /><Pressable onPress={() => setOpen(false)} style={{ padding: 16 }}><Text style={{ color: t.red }}>Cancel</Text></Pressable></View></Modal></Screen>;
}
