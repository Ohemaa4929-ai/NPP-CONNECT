import { ScrollView, Text, View, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { Screen, Verified, State } from '@/ui/parts';
import { useTheme } from '@/ui/theme';
import { repo } from '@/data/repo';
import { useAsync, when } from '@/lib/useAsync';

export default function Home() {
  const t = useTheme(); const r = useRouter();
  const bc = useAsync(() => repo.broadcasts(), []); const ev = useAsync(() => repo.events(), []); const vd = useAsync(() => repo.videos(), []);
  const H = ({ l, to }: { l: string; to: string }) => <Pressable onPress={() => r.push(to as never)} style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 18, marginBottom: 8 }}><Text style={{ color: t.text, fontWeight: '800', fontSize: 16 }}>{l}</Text><Text style={{ color: t.blue }}>See all</Text></Pressable>;
  const card = { borderWidth: 1, borderColor: t.line, borderRadius: 14, padding: 12, marginBottom: 8 } as const;
  return <Screen><ScrollView contentContainerStyle={{ padding: 14 }}>
    <H l="Official announcements" to="/(tabs)/broadcasts" />
    <State loading={bc.loading} error={bc.error} reload={bc.reload} empty={!bc.data?.length} emptyText="No announcements.">
      {bc.data?.slice(0, 2).map((b) => <Pressable key={b.id} style={{ ...card, borderLeftWidth: 5, borderLeftColor: b.priority === 'urgent' ? t.red : t.blue }} onPress={() => r.push({ pathname: '/broadcast/[id]', params: { id: b.id } })}>
        <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center' }}><Verified /><Text style={{ color: t.text, fontWeight: '600' }}>{b.author}</Text></View>
        <Text style={{ color: t.text, fontWeight: '800' }}>{b.title}</Text><Text numberOfLines={2} style={{ color: t.text }}>{b.body}</Text><Text style={{ color: t.muted }}>{when(b.publishedAt)}</Text></Pressable>)}</State>
    <H l="Leadership videos" to="/videos" />
    <State loading={vd.loading} error={vd.error} reload={vd.reload} empty={!vd.data?.length} emptyText="No leadership videos.">
      {vd.data?.slice(0, 1).map((v) => <Pressable key={v.id} style={card} onPress={() => r.push('/videos')}><Text style={{ color: t.text, fontWeight: '800' }}>▶ {v.title}</Text><Text style={{ color: t.muted }}>{v.author} · {v.views} views</Text></Pressable>)}</State>
    <H l="Upcoming events" to="/events" />
    <State loading={ev.loading} error={ev.error} reload={ev.reload} empty={!ev.data?.length} emptyText="No upcoming events.">
      {ev.data?.slice(0, 2).map((e) => <View key={e.id} style={card}><Text style={{ color: t.text, fontWeight: '800' }}>{e.title}</Text><Text style={{ color: t.muted }}>{when(e.startsAt)} · {e.location}</Text></View>)}</State>
    <H l="Documents" to="/documents" />
  </ScrollView></Screen>;
}
