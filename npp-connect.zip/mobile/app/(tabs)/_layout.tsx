import { Tabs, useRouter } from 'expo-router';
import { Image, Pressable, Text, View } from 'react-native';
import { useTheme } from '@/ui/theme';

const icon = (e: string) => ({ color }: { color: string }) => <Text style={{ fontSize: 20, color }}>{e}</Text>;
export default function TabsLayout() {
  const t = useTheme(); const r = useRouter();
  const Btn = ({ e, to, label }: { e: string; to: string; label: string }) => <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={() => r.push(to as never)} style={{ padding: 10 }}><Text style={{ fontSize: 18 }}>{e}</Text></Pressable>;
  return <Tabs screenOptions={{ headerStyle: { backgroundColor: t.blue }, headerTintColor: '#fff',
    headerTitle: () => <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}><Image source={require('../../assets/logo.png')} style={{ width: 36, height: 30 }} resizeMode="contain" /><Text style={{ color: '#fff', fontWeight: '800', fontSize: 17 }}>NPP CONNECT</Text></View>,
    headerRight: () => <View style={{ flexDirection: 'row' }}><Btn e="🔍" to="/search" label="Search" /><Btn e="🔔" to="/notifications" label="Notifications" /><Btn e="⚙️" to="/settings" label="Settings" /></View>,
    tabBarActiveTintColor: t.red, tabBarInactiveTintColor: t.muted, tabBarStyle: { backgroundColor: t.bg, borderTopColor: t.line, height: 62 }, tabBarLabelStyle: { fontSize: 11 } }}>
    <Tabs.Screen name="index" options={{ title: 'Home', tabBarIcon: icon('⌂') }} />
    <Tabs.Screen name="chats" options={{ title: 'Chats', tabBarIcon: icon('💬') }} />
    <Tabs.Screen name="groups" options={{ title: 'Groups', tabBarIcon: icon('👥') }} />
    <Tabs.Screen name="broadcasts" options={{ title: 'Broadcasts', tabBarIcon: icon('📢') }} />
    <Tabs.Screen name="profile" options={{ title: 'Profile', tabBarIcon: icon('👤') }} />
  </Tabs>;
}
