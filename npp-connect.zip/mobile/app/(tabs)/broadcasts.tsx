import { useCallback } from 'react';
import { FlatList, Pressable, Text, View } from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { Screen, State, Verified } from '@/ui/parts';
import { useTheme } from '@/ui/theme';
import { repo } from '@/data/repo';
import { useAsync, when } from '@/lib/useAsync';

export default function Broadcasts() {
  const t = useTheme(); const r = useRouter(); const { data, loading, error, reload } = useAsync(() => repo.broadcasts(), []);
  useFocusEffect(useCallback(() => { reload(); }, [])); // eslint-disable-line
  return <Screen>
    <State loading={loading} error={error} reload={reload} empty={!data?.length} emptyText="No announcements.">
      <FlatList data={data} keyExtractor={(b) => b.id} onRefresh={reload} refreshing={false} contentContainerStyle={{ padding: 14, gap: 10 }} renderItem={({ item: b }) =>
        <Pressable onPress={() => r.push({ pathname: '/broadcast/[id]', params: { id: b.id } })} style={{ borderWidth: 1, borderColor: t.line, borderLeftWidth: 5, borderLeftColor: b.priority === 'urgent' ? t.red : t.blue, borderRadius: 14, padding: 12, opacity: b.read ? 0.85 : 1 }}>
          <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center' }}><Verified /><Text style={{ color: t.text, fontWeight: '600' }}>{b.author}</Text>{b.confidential && <Text>🔒</Text>}{!b.read && <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: t.red }} />}</View>
          <Text style={{ color: t.text, fontWeight: '800', marginTop: 4 }}>{b.title}</Text><Text numberOfLines={3} style={{ color: t.text }}>{b.body}</Text>
          <Text style={{ color: t.muted, marginTop: 6 }}>{when(b.publishedAt)} · {b.priority} · {b.views} views</Text></Pressable>} /></State>
    <Pressable accessibilityRole="button" onPress={() => r.push('/broadcast/new')} style={{ position: 'absolute', right: 18, bottom: 18, backgroundColor: t.red, paddingHorizontal: 18, height: 52, borderRadius: 26, justifyContent: 'center' }}><Text style={{ color: '#fff', fontWeight: '700' }}>＋ Create broadcast</Text></Pressable></Screen>;
}
