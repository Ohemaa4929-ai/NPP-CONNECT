import { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Text, View } from 'react-native';
import { Chip, Page } from '@/ui/parts';
import { useTheme } from '@/ui/theme';

// Device-only preferences. Stored locally, not on the server.
export default function Prefs() {
  const t = useTheme(); const [auto, setAuto] = useState('wifi'); const [text, setText] = useState('normal');
  useEffect(() => { AsyncStorage.multiGet(['pref.auto', 'pref.text']).then((r) => { if (r[0][1]) setAuto(r[0][1]); if (r[1][1]) setText(r[1][1]); }); }, []);
  const save = (k: string, v: string, set: (x: string) => void) => { set(v); AsyncStorage.setItem(k, v); };
  const Group = ({ title, k, val, set, opts }: { title: string; k: string; val: string; set: (x: string) => void; opts: [string, string][] }) => <View style={{ gap: 6 }}><Text style={{ color: t.text, fontWeight: '700' }}>{title}</Text><View style={{ flexDirection: 'row', gap: 6, flexWrap: 'wrap' }}>{opts.map(([v, l]) => <Chip key={v} label={l} on={val === v} onPress={() => save(k, v, set)} />)}</View></View>;
  return <Page title="Data, chats and accessibility"><View style={{ padding: 14, gap: 16 }}>
    <Group title="Download photos and videos automatically" k="pref.auto" val={auto} set={setAuto} opts={[['wifi', 'On Wi-Fi only'], ['never', 'Never'], ['always', 'Always']]} />
    <Group title="Text size" k="pref.text" val={text} set={setText} opts={[['normal', 'Normal'], ['large', 'Large']]} />
    <Text style={{ color: t.muted }}>Photos are shrunk and videos compressed before upload to save data.</Text></View></Page>;
}
