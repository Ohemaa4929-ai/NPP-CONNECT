import { ScrollView, Text, Linking } from 'react-native';
import { useRouter } from 'expo-router';
import { Page, Row } from '@/ui/parts';
import { Button } from '@/ui/form';
import { useAuth } from '@/lib/auth';
import { View } from 'react-native';

const ITEMS: [string, string, string][] = [['Account', 'Name, bio, phone', '/settings/account'], ['Privacy', 'Who sees what', '/settings/privacy'], ['Security', 'Devices and sessions', '/settings/security'],
  ['Notifications', 'All, important only, silent', '/settings/notifications'], ['Data and storage', 'Media auto-download', '/settings/prefs'], ['Chats', 'Chat preferences', '/settings/prefs'],
  ['Groups', 'Group invitations', '/settings/privacy'], ['Accessibility', 'Text size', '/settings/prefs'], ['Help and support', 'FAQ, contact, report a problem', '/help'],
  ['Terms', 'Placeholder until legal review', '/help'], ['Privacy policy', 'Placeholder until legal review', '/help']];
export default function Settings() {
  const r = useRouter(); const { signOut } = useAuth();
  return <Page title="Settings"><ScrollView>{ITEMS.map(([t, s, to]) => <Row key={t} title={t} sub={s} onPress={() => r.push(to as never)} />)}
    <Row title="Documents" sub="Shared files" onPress={() => r.push('/documents')} /><Row title="Leadership videos" sub="Watch and save" onPress={() => r.push('/videos')} /><Row title="Events" sub="Meetings and activities" onPress={() => r.push('/events')} />
    <View style={{ padding: 14 }}><Button label="Log out" tone="blue" onPress={signOut} /></View></ScrollView></Page>;
}
