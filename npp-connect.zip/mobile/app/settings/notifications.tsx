import { Text, View } from 'react-native';
import { Chip, Page, State } from '@/ui/parts';
import { useTheme } from '@/ui/theme';
import { repo } from '@/data/repo';
import { useAsync } from '@/lib/useAsync';

const MODES: [string, string][] = [['all', 'All notifications'], ['important', 'Important only'], ['groups', 'Groups only'], ['direct', 'Direct messages only'], ['silent', 'Silent mode']];
export default function NotifSettings() {
  const t = useTheme(); const m = useAsync(() => repo.notifMode(), []);
  return <Page title="Notifications"><State loading={m.loading} error={m.error} reload={m.reload}><View style={{ padding: 14, gap: 8 }}>
    {MODES.map(([k, l]) => <Chip key={k} label={l} on={m.data === k} onPress={() => repo.setNotifMode(k).then(m.reload)} />)}
    <Text style={{ color: t.muted }}>Security alerts are always delivered. "Important only" delivers urgent and important broadcasts.</Text></View></State></Page>;
}
