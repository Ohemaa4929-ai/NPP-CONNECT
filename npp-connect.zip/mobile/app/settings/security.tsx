import { FlatList, Text } from 'react-native';
import { Page, Row, State } from '@/ui/parts';
import { useTheme } from '@/ui/theme';
import { repo } from '@/data/repo';
import { useAsync, when } from '@/lib/useAsync';

export default function Security() {
  const t = useTheme(); const d = useAsync(() => repo.devices(), []);
  return <Page title="Security"><State loading={d.loading} error={d.error} reload={d.reload} empty={!d.data?.length} emptyText="No devices registered.">
    <FlatList data={d.data} keyExtractor={(x) => x.id} ListHeaderComponent={<Text style={{ color: t.muted, padding: 14 }}>Devices signed in to your account. Remove any you do not recognize. You are alerted when a new device is added.</Text>}
      renderItem={({ item }) => <Row title={item.label ?? 'Device'} sub={`${item.revoked ? 'Removed' : 'Active'} · ${when(item.lastActive)}`} right={item.revoked ? undefined : <Text style={{ color: t.red }} onPress={() => repo.revokeDevice(item.id).then(d.reload)}>Remove</Text>} />} /></State></Page>;
}
