import { useState } from 'react';
import { Text, TextInput, View } from 'react-native';
import { Page, State, useInput, Verified } from '@/ui/parts';
import { Button } from '@/ui/form';
import { useTheme } from '@/ui/theme';
import { repo } from '@/data/repo';
import { useAsync } from '@/lib/useAsync';

export default function Account() {
  const t = useTheme(); const inp = useInput(); const p = useAsync(() => repo.profile(), []); const [bio, setBio] = useState<string | null>(null);
  return <Page title="Account"><State loading={p.loading} error={p.error} reload={p.reload}>
    <View style={{ padding: 14, gap: 10 }}>
      <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center' }}><Text style={{ color: t.text, fontSize: 20, fontWeight: '800' }}>{p.data?.full_name}</Text>{p.data?.verified_at && <Verified />}</View>
      <Text style={{ color: t.muted }}>{p.data?.phone}</Text><Text style={{ color: t.muted }}>Role, region, constituency, electoral area and polling station are set by an administrator.</Text>
      <TextInput value={bio ?? p.data?.bio ?? ''} onChangeText={setBio} placeholder="About you" placeholderTextColor={t.muted} maxLength={280} multiline style={[inp, { minHeight: 80 }]} />
      <Button label="Save" disabled={bio === null} onPress={() => repo.saveBio(bio!).then(() => alert('Saved.')).catch((e) => alert(e.message))} /></View></State></Page>;
}
