import { ScrollView, Switch, Text, View } from 'react-native';
import { Chip, Page, State } from '@/ui/parts';
import { useTheme } from '@/ui/theme';
import { repo } from '@/data/repo';
import { useAsync } from '@/lib/useAsync';
import type { Privacy } from '@/data/types';

const OPTS: { k: keyof Privacy; label: string; values: [string, string][] }[] = [
  { k: 'profile_visibility', label: 'Who can see my profile', values: [['everyone', 'Everyone'], ['org', 'My area'], ['leaders', 'Leaders'], ['nobody', 'Nobody']] },
  { k: 'phone_visibility', label: 'Who can see my phone number', values: [['everyone', 'Everyone'], ['leaders', 'Leaders'], ['nobody', 'Nobody']] },
  { k: 'last_seen', label: 'Last seen', values: [['everyone', 'Everyone'], ['org', 'My area'], ['nobody', 'Nobody']] },
  { k: 'group_invites', label: 'Who can add me to groups', values: [['everyone', 'Everyone'], ['org', 'My area'], ['nobody', 'Nobody']] }];
export default function PrivacyScreen() {
  const t = useTheme(); const p = useAsync(() => repo.privacy(), []);
  const set = async (patch: Partial<Privacy>) => { await repo.setPrivacy(patch); p.reload(); };
  return <Page title="Privacy"><State loading={p.loading} error={p.error} reload={p.reload}><ScrollView contentContainerStyle={{ padding: 14, gap: 12 }}>
    {OPTS.map((o) => <View key={o.k} style={{ gap: 6 }}><Text style={{ color: t.text, fontWeight: '700' }}>{o.label}</Text><View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>{o.values.map(([v, l]) => <Chip key={v} label={l} on={p.data?.[o.k] === v} onPress={() => set({ [o.k]: v })} />)}</View></View>)}
    {([['online_status', 'Show when I am online'], ['read_receipts', 'Read receipts']] as [keyof Privacy, string][]).map(([k, l]) => <View key={k} style={{ flexDirection: 'row', justifyContent: 'space-between' }}><Text style={{ color: t.text }}>{l}</Text><Switch value={!!p.data?.[k]} onValueChange={(v) => set({ [k]: v })} /></View>)}
    <Text style={{ color: t.muted }}>Blocked people: open a person's report screen and choose Block.</Text></ScrollView></State></Page>;
}
