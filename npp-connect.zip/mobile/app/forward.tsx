import { FlatList } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Page, Row, State } from '@/ui/parts';
import { repo } from '@/data/repo';
import { useAsync } from '@/lib/useAsync';

export default function Forward() {
  const { m } = useLocalSearchParams<{ m: string }>(); const r = useRouter(); const { data, loading, error, reload } = useAsync(() => repo.chats(), []);
  return <Page title="Forward to"><State loading={loading} error={error} reload={reload} empty={!data?.length} emptyText="No conversations yet.">
    <FlatList data={data} keyExtractor={(c) => c.id} renderItem={({ item }) => <Row title={item.title} sub={item.kind} onPress={() => repo.forward(m, item.id).then(() => { alert('Forwarded.'); r.back(); }).catch((e) => alert(e.message))} />} /></State></Page>;
}
