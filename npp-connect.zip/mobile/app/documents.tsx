import { FlatList } from 'react-native';
import { Page, State } from '@/ui/parts';
import { FileRow } from '@/ui/media';
import { repo } from '@/data/repo';
import { useAsync } from '@/lib/useAsync';

export default function Documents() {
  const { data, loading, error, reload } = useAsync(() => repo.documents(), []);
  return <Page title="Documents"><State loading={loading} error={error} reload={reload} empty={!data?.length} emptyText="No documents yet.">
    <FlatList data={data} keyExtractor={(d) => d.id} contentContainerStyle={{ padding: 14, gap: 8 }} renderItem={({ item: d }) => <FileRow f={{ id: d.id, name: d.name, mime: d.mime, size: d.size, bucket: d.bucket, path: d.path, kind: 'document' }} />} /></State></Page>;
}
