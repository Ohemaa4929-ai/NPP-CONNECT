import { useState } from 'react';
import { Alert, Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Page, Row, State } from '@/ui/parts';
import { Button } from '@/ui/form';
import { useTheme } from '@/ui/theme';
import { repo } from '@/data/repo';
import { useAsync } from '@/lib/useAsync';
import type { Person } from '@/data/types';

export default function GroupInfo() {
  const { conv, name } = useLocalSearchParams<{ id: string; conv: string; name: string }>(); const t = useTheme(); const r = useRouter();
  const mem = useAsync(() => repo.members(conv), [conv]); const pins = useAsync(() => repo.pinned(conv), [conv]); const [q, setQ] = useState(''); const [ppl, setPpl] = useState<Person[]>([]);
  const act = (f: () => Promise<unknown>) => async () => { try { await f(); mem.reload(); } catch (e) { alert(e instanceof Error ? e.message : 'Not allowed.'); } };
  return <Page title={name ?? 'Group'}><ScrollView contentContainerStyle={{ padding: 14, gap: 10 }}>
    <Button label="Open chat" onPress={() => r.push({ pathname: '/chat/[id]', params: { id: conv, title: name } })} />
    <Text style={{ color: t.text, fontWeight: '800' }}>Pinned messages</Text>
    {pins.data?.length ? pins.data.map((p) => <Text key={p.id} style={{ color: t.text }}>📌 {p.body}</Text>) : <Text style={{ color: t.muted }}>None</Text>}
    <Text style={{ color: t.text, fontWeight: '800' }}>Admin controls</Text>
    <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
      {[['Off', 0], ['24 hours', 86400], ['7 days', 604800]].map(([l, s]) => <Pressable key={l as string} onPress={() => repo.disappearing(conv, s as number).then(() => alert('Disappearing messages: ' + l)).catch((e) => alert(e.message))} style={{ padding: 8, borderRadius: 8, backgroundColor: t.bg2 }}><Text style={{ color: t.text }}>⏱ {l as string}</Text></Pressable>)}</View>
    <TextInput value={q} onChangeText={async (v) => { setQ(v); setPpl(v.length > 1 ? await repo.people(v) : []); }} placeholder="Invite someone by name" placeholderTextColor={t.muted} style={{ backgroundColor: t.bg2, color: t.text, padding: 12, borderRadius: 10 }} />
    {ppl.map((p) => <Row key={p.id} title={p.name} sub="Tap to invite" onPress={act(() => repo.addMember(conv, p.id))} />)}
    <Text style={{ color: t.text, fontWeight: '800' }}>Members</Text>
    <State loading={mem.loading} error={mem.error} reload={mem.reload} empty={!mem.data?.length}>
      {mem.data?.map((m) => <Row key={m.userId} title={m.name + (m.verified ? ' ✓' : '')} sub={m.status === 'active' ? m.role : m.status}
        right={<View style={{ flexDirection: 'row', gap: 12 }}>{m.status === 'pending' && <Pressable onPress={act(() => repo.approveMember(conv, m.userId))}><Text style={{ color: t.blue }}>Approve</Text></Pressable>}
          <Pressable onPress={act(() => repo.removeMember(conv, m.userId))}><Text style={{ color: t.red }}>Remove</Text></Pressable></View>} />)}</State>
    <Button label="Leave group" tone="blue" onPress={() => Alert.alert('Leave this group?', undefined, [{ text: 'Cancel', style: 'cancel' }, { text: 'Leave', style: 'destructive', onPress: () => repo.removeMember(conv, 'me').then(() => r.replace('/(tabs)/groups')) }])} /></ScrollView></Page>;
}
