import { Text } from 'react-native';
import { AuthFrame, Button } from '@/ui/form';
import { useTheme } from '@/ui/theme';
import { useAuth } from '@/lib/auth';

export default function Pending() {
  const t = useTheme(); const { refresh, signOut } = useAuth();
  return <AuthFrame title="Waiting for approval">
    <Text style={{ color: t.text, textAlign: 'center' }}>An administrator must verify your account and assign your area before you can use the app.</Text>
    <Button label="Check again" onPress={refresh} />
    <Button label="Log out" tone="blue" onPress={signOut} />
  </AuthFrame>;
}
