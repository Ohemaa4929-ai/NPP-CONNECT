import { useState } from 'react';
import { ScrollView, Text, TextInput, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Chip, Page, useInput } from '@/ui/parts';
import { Button } from '@/ui/form';
import { useTheme } from '@/ui/theme';
import { repo } from '@/data/repo';

const REASONS: [string, string][] = [['spam', 'Spam'], ['harassment', 'Harassment'], ['impersonation', 'Impersonation'], ['unauthorized_content', 'Unauthorized content'], ['fraud', 'Fraud or scam'], ['security', 'Security concern'], ['other', 'Other']];
export default function Report() {
  const { type, id } = useLocalSearchParams<{ type: string; id: string }>(); const t = useTheme(); const r = useRouter(); const inp = useInput();
  const [why, setWhy] = useState('spam'); const [d, setD] = useState(''); const [err, setErr] = useState('');
  return <Page title={`Report ${type}`}><ScrollView contentContainerStyle={{ padding: 14, gap: 10 }}>
    <Text style={{ color: t.text }}>Why are you reporting this?</Text>
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>{REASONS.map(([k, l]) => <Chip key={k} label={l} on={why === k} onPress={() => setWhy(k)} />)}</View>
    <TextInput value={d} onChangeText={setD} placeholder="Details (optional)" placeholderTextColor={t.muted} multiline style={[inp, { minHeight: 80 }]} />
    {!!err && <Text accessibilityRole="alert" style={{ color: t.red }}>{err}</Text>}
    <Button label="Send report" onPress={() => repo.report(type, id, why, d).then(() => { alert('Report sent. An administrator will review it.'); r.back(); }).catch((e) => setErr(e.message))} />
    {type === 'user' && <Button label="Block this person" tone="blue" onPress={() => repo.block(id).then(() => alert('Blocked.')).catch((e) => setErr(e.message))} />}</ScrollView></Page>;
}
