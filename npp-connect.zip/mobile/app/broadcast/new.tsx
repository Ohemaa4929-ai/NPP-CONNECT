import { useState } from 'react';
import { ScrollView, Switch, Text, TextInput, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Chip, Page, useInput } from '@/ui/parts';
import { Button } from '@/ui/form';
import { useTheme } from '@/ui/theme';
import { repo } from '@/data/repo';
import { useAsync } from '@/lib/useAsync';
import { pickDocument, pickMedia, upload } from '@/lib/upload';
import type { Broadcast } from '@/data/types';

export default function NewBroadcast() {
  const t = useTheme(); const r = useRouter(); const inp = useInput(); const units = useAsync(() => repo.units(), []);
  const [title, setTitle] = useState(''); const [body, setBody] = useState(''); const [unit, setUnit] = useState<string | null>(null); const [pri, setPri] = useState<Broadcast['priority']>('normal');
  const [when, setWhen] = useState(''); const [comments, setComments] = useState(false); const [fwd, setFwd] = useState(true); const [conf, setConf] = useState(false);
  const [files, setFiles] = useState<{ id: string; name: string }[]>([]); const [pq, setPq] = useState(''); const [po, setPo] = useState(''); const [busy, setBusy] = useState(false); const [err, setErr] = useState('');
  const add = async (k: 'image' | 'video' | 'document') => { try { const f = k === 'document' ? await pickDocument() : await pickMedia(k); if (!f) return; const id = await upload(f, 'broadcasts'); setFiles((x) => [...x, { id, name: f.name }]); } catch (e) { setErr(e instanceof Error ? e.message : 'Upload failed. Tap to retry.'); } };
  const go = async (asDraft: boolean) => {
    const when2 = when.trim() ? new Date(when.replace(' ', 'T')) : null;
    if (when2 && isNaN(+when2)) return setErr('Use the format 2026-10-12 18:00 for the schedule.');
    setBusy(true); setErr('');
    try { const opts = po.split('\n').map((x) => x.trim()).filter(Boolean);
      const res = await repo.publishBroadcast({ title: title.trim(), body: body.trim(), unitId: unit, priority: pri, scheduledAt: when2 ? when2.toISOString() : null, allowComments: comments, allowForwarding: fwd, confidential: conf, fileIds: files.map((f) => f.id), asDraft,
        poll: pq.trim() && opts.length >= 2 ? { question: pq.trim(), options: opts, multiple: false } : undefined });
      alert(res === 'draft' ? 'Draft saved.' : res === 'scheduled' ? 'Broadcast scheduled.' : 'Broadcast is being delivered.'); r.back();
    } catch (e) { setErr(e instanceof Error ? e.message : 'Unable to publish.'); } finally { setBusy(false); } };
  const row = { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' } as const;
  return <Page title="Create broadcast"><ScrollView contentContainerStyle={{ padding: 14, gap: 10 }}>
    <TextInput value={title} onChangeText={setTitle} placeholder="Title" placeholderTextColor={t.muted} style={inp} accessibilityLabel="Title" />
    <TextInput value={body} onChangeText={setBody} placeholder="Message" placeholderTextColor={t.muted} multiline style={[inp, { minHeight: 100 }]} accessibilityLabel="Message" />
    <Text style={{ color: t.text, fontWeight: '700' }}>Audience (everyone in the chosen area and below)</Text>
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>{units.data?.map((u) => <Chip key={u.id} label={u.name} on={unit === u.id} onPress={() => setUnit(u.id)} />)}</View>
    <Text style={{ color: t.text, fontWeight: '700' }}>Priority</Text>
    <View style={{ flexDirection: 'row', gap: 6 }}>{(['normal', 'important', 'urgent'] as const).map((p) => <Chip key={p} label={p} on={pri === p} onPress={() => setPri(p)} />)}</View>
    <Text style={{ color: t.text, fontWeight: '700' }}>Media</Text>
    <View style={{ flexDirection: 'row', gap: 6, flexWrap: 'wrap' }}><Chip label="🖼 Image" on={false} onPress={() => add('image')} /><Chip label="🎬 Video" on={false} onPress={() => add('video')} /><Chip label="📄 PDF or document" on={false} onPress={() => add('document')} /></View>
    {files.map((f) => <Text key={f.id} style={{ color: t.muted }}>📎 {f.name}</Text>)}
    <TextInput value={when} onChangeText={setWhen} placeholder="Schedule (optional): 2026-10-12 18:00" placeholderTextColor={t.muted} style={inp} accessibilityLabel="Schedule" />
    <TextInput value={pq} onChangeText={setPq} placeholder="Poll question (optional)" placeholderTextColor={t.muted} style={inp} />
    {!!pq && <TextInput value={po} onChangeText={setPo} placeholder={'One option per line (at least two)'} placeholderTextColor={t.muted} multiline style={[inp, { minHeight: 70 }]} />}
    <View style={row}><Text style={{ color: t.text }}>Allow comments</Text><Switch value={comments} onValueChange={setComments} /></View>
    <View style={row}><Text style={{ color: t.text }}>Allow forwarding</Text><Switch value={fwd && !conf} disabled={conf} onValueChange={setFwd} /></View>
    <View style={row}><Text style={{ color: t.text, flex: 1 }}>🔒 Confidential (no forwarding)</Text><Switch value={conf} onValueChange={setConf} /></View>
    {!!err && <Text accessibilityRole="alert" style={{ color: t.red }}>{err}</Text>}
    <Button label={busy ? 'Working…' : when ? 'Schedule' : 'Publish'} onPress={() => go(false)} disabled={busy || title.trim().length < 2 || !body.trim() || (!unit)} />
    <Button label="Save draft" tone="blue" onPress={() => go(true)} disabled={busy || title.trim().length < 2 || !body.trim()} /></ScrollView></Page>;
}
