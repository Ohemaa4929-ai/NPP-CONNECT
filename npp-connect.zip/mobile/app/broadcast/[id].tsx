import { useEffect, useState } from 'react';
import { ScrollView, Text, TextInput, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Page, State, Verified, Chip } from '@/ui/parts';
import { FileRow, VideoCard } from '@/ui/media';
import { Poll } from '@/ui/poll';
import { Button } from '@/ui/form';
import { useTheme } from '@/ui/theme';
import { repo } from '@/data/repo';
import { useAsync, when } from '@/lib/useAsync';

export default function BroadcastDetail() {
  const { id } = useLocalSearchParams<{ id: string }>(); const t = useTheme(); const r = useRouter();
  const feed = useAsync(() => repo.broadcasts(), []); const b = feed.data?.find((x) => x.id === id);
  const polls = useAsync(() => repo.polls({ broadcastId: id }), [id]); const cm = useAsync(() => repo.comments(id), [id]); const [text, setText] = useState('');
  useEffect(() => { if (b && !b.read) repo.markBroadcastRead(id); }, [b?.id]); // eslint-disable-line
  return <Page title="Announcement"><State loading={feed.loading} error={feed.error} reload={feed.reload} empty={!b} emptyText="This announcement is no longer available.">
    {b && <ScrollView contentContainerStyle={{ padding: 14, gap: 10 }}>
      <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center' }}><Verified /><Text style={{ color: t.text, fontWeight: '700' }}>{b.author}</Text><Text style={{ color: t.muted }}>Verified source</Text></View>
      <Text style={{ color: t.text, fontSize: 20, fontWeight: '800' }}>{b.title}</Text><Text style={{ color: t.muted }}>{when(b.publishedAt)} · {b.priority} · {b.views} views{b.confidential ? ' · 🔒 Confidential' : ''}</Text>
      <Text style={{ color: t.text, fontSize: 16 }}>{b.body}</Text>
      {b.files.map((f) => f.kind === 'video' ? <VideoCard key={f.id} bucket={f.bucket} path={f.path} /> : <FileRow key={f.id} f={f} />)}
      {polls.data?.map((p) => <Poll key={p.id} poll={p} onChange={polls.reload} />)}
      <View style={{ flexDirection: 'row', gap: 8 }}>{['👍', '🙏', '❤️'].map((e) => <Chip key={e} label={e} on={false} onPress={() => repo.reactBroadcast(id, e)} />)}</View>
      {b.allowComments && <><Text style={{ color: t.text, fontWeight: '800' }}>Comments</Text>
        {cm.data?.map((c) => <Text key={c.id} style={{ color: t.text }}><Text style={{ fontWeight: '700' }}>{c.user}: </Text>{c.body}</Text>)}
        <TextInput value={text} onChangeText={setText} placeholder="Add a comment" placeholderTextColor={t.muted} style={{ backgroundColor: t.bg2, color: t.text, padding: 12, borderRadius: 10 }} />
        <Button label="Post" disabled={!text.trim()} onPress={async () => { await repo.comment(id, text.trim()); setText(''); cm.reload(); }} /></>}
      <Button label="Report" tone="blue" onPress={() => r.push({ pathname: '/report', params: { type: 'broadcast', id } })} /></ScrollView>}</State></Page>;
}
