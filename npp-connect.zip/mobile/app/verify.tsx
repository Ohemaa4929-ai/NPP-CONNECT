import { useState } from 'react';
import { Text, TextInput } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { AuthFrame, Button, inputStyle } from '@/ui/form';
import { useTheme } from '@/ui/theme';
import { useAuth } from '@/lib/auth';

export default function Verify() {
  const t = useTheme(); const router = useRouter(); const { verifyOtp, sendOtp } = useAuth();
  const { phone } = useLocalSearchParams<{ phone: string }>();
  const [code, setCode] = useState(''); const [err, setErr] = useState<string | null>(null); const [busy, setBusy] = useState(false);
  const go = async () => { setBusy(true); setErr(null); const e = await verifyOtp(phone, code); setBusy(false); if (e) setErr(e); };
  return <AuthFrame title="Enter your code">
    <Text style={{ color: t.muted, textAlign: 'center' }}>Sent to {phone}</Text>
    <TextInput value={code} onChangeText={(v) => setCode(v.replace(/\D/g, '').slice(0, 6))} keyboardType="number-pad"
      textContentType="oneTimeCode" autoComplete="sms-otp" accessibilityLabel="6-digit code"
      style={[inputStyle(t), { textAlign: 'center', letterSpacing: 8 }]} />
    {err && <Text accessibilityRole="alert" style={{ color: t.red }}>{err}</Text>}
    <Button label={busy ? 'Checking…' : 'Verify'} onPress={go} disabled={code.length !== 6 || busy} />
    <Button label="Send a new code" tone="blue" onPress={async () => setErr(await sendOtp(phone))} />
    <Button label="Use a different number" tone="blue" onPress={() => router.back()} />
  </AuthFrame>;
}
