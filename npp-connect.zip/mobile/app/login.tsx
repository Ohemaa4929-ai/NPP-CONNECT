import { useState } from 'react';
import { Pressable, Text, TextInput } from 'react-native';
import { useRouter } from 'expo-router';
import { AuthFrame, Button, inputStyle } from '@/ui/form';
import { useTheme } from '@/ui/theme';
import { useAuth } from '@/lib/auth';
import { normalizeGhanaPhone } from '@/lib/phone';
import { config } from '@/lib/config';

export default function Login() {
  const t = useTheme(); const router = useRouter(); const { sendOtp } = useAuth();
  const [raw, setRaw] = useState(''); const [agree, setAgree] = useState(false);
  const [err, setErr] = useState<string | null>(null); const [busy, setBusy] = useState(false);
  const phone = normalizeGhanaPhone(raw);
  const go = async () => {
    if (!phone) return setErr('Enter a valid Ghana number, for example 024 412 3456.');
    setBusy(true); setErr(null);
    const e = await sendOtp(phone); setBusy(false);
    if (e) setErr(e); else router.push({ pathname: '/verify', params: { phone } });
  };
  return <AuthFrame title="Welcome to NPP CONNECT">
    <Text style={{ color: t.muted, textAlign: 'center' }}>Enter your phone number. We send a 6-digit code.</Text>
    <TextInput value={raw} onChangeText={setRaw} keyboardType="phone-pad" placeholder="+233 24 412 3456" placeholderTextColor={t.muted}
      autoComplete="tel" accessibilityLabel="Phone number" style={inputStyle(t)} />
    <Pressable onPress={() => setAgree(!agree)} accessibilityRole="checkbox" accessibilityState={{ checked: agree }}>
      <Text style={{ color: t.text }}>{agree ? '☑' : '☐'} I accept the Terms and Privacy Policy (placeholders until legal review).</Text></Pressable>
    {err && <Text accessibilityRole="alert" style={{ color: t.red }}>{err}</Text>}
    <Button label={busy ? 'Sending…' : 'Send code'} onPress={go} disabled={!agree || busy} />
    {config.demo && <Text style={{ color: t.muted, textAlign: 'center' }}>Demo mode: use any valid number, then code 123456.</Text>}
  </AuthFrame>;
}
