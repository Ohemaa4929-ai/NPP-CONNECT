import { useCallback, useEffect, useRef, useState } from 'react';
import { FlatList, KeyboardAvoidingView, Platform, Pressable, Text, TextInput, View } from 'react-native';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import * as Clipboard from 'expo-clipboard';
import { Screen, Sheet, State, Verified } from '@/ui/parts';
import { FileRow, Recorder, VoiceBubble } from '@/ui/media';
import { Poll } from '@/ui/poll';
import { useTheme } from '@/ui/theme';
import { repo } from '@/data/repo';
import { config } from '@/lib/config';
import { supabase } from '@/lib/supabase';
import { enqueueAndSend, pending, flush } from '@/lib/outbox';
import { pickDocument, pickMedia, upload } from '@/lib/upload';
import { useAsync, when } from '@/lib/useAsync';
import type { Msg, PollT } from '@/data/types';

const uuid = () => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => { const r = (Math.random() * 16) | 0; return (c === 'x' ? r : (r & 3) | 8).toString(16); });

export default function Chat() {
  const { id, title } = useLocalSearchParams<{ id: string; title?: string }>(); const t = useTheme(); const router = useRouter();
  const [msgs, setMsgs] = useState<Msg[]>([]); const [loading, setLoading] = useState(true); const [err, setErr] = useState<string | null>(null);
  const [text, setText] = useState(''); const [reply, setReply] = useState<Msg | null>(null); const [sel, setSel] = useState<Msg | null>(null);
  const [more, setMore] = useState(true); const [queued, setQueued] = useState<Msg[]>([]); const [read, setRead] = useState<string[]>([]);
  const [find, setFind] = useState<string | null>(null); const [hits, setHits] = useState<{ id: string; title: string }[]>([]); const [plus, setPlus] = useState(false);
  const chats = useAsync(() => repo.chats(), []); const polls = useAsync(() => repo.polls({ conversationId: id }), [id]);
  const restrict = chats.data?.find((c) => c.id === id)?.restrictForwarding ?? false;
  const myId = useRef('me');

  const load = useCallback(async () => {
    try { setErr(null); const m = await repo.messages(id); setMsgs(m); setMore(m.length >= 30); repo.markRead(id);
      repo.receipts(id).then((r) => setRead(r.filter((x) => x.last_read_at).map((x) => x.last_read_at as string))); }
    catch (e) { setErr(e instanceof Error ? e.message : 'Unable to load messages. Please check your connection.'); } finally { setLoading(false); }
    setQueued((await pending(id)).map((p) => ({ id: p.clientId, senderId: myId.current, senderName: 'You', senderVerified: false, kind: p.kind ?? 'text', body: p.body ?? null, replyTo: null, forwarded: false, pinned: false, createdAt: new Date().toISOString(), attachments: [], reactions: [], status: 'sending' as const })));
  }, [id]);
  useEffect(() => { supabase.auth.getUser().then(({ data }) => { if (data.user) myId.current = data.user.id; }); load(); }, [load]);
  useEffect(() => {   // realtime: only this conversation, only while the screen is open
    if (config.demo) return;
    const ch = supabase.channel('conv:' + id).on('postgres_changes', { event: '*', schema: 'public', table: 'messages', filter: `conversation_id=eq.${id}` }, () => load()).subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [id, load]);
  const older = async () => { if (!more || !msgs.length) return; const last = msgs[msgs.length - 1]; const m = await repo.messages(id, { at: last.createdAt, id: last.id }); setMsgs((x) => [...x, ...m]); setMore(m.length >= 30); };

  const send = async (p: { body?: string; kind?: string; fileIds?: string[] }) => {
    await enqueueAndSend({ clientId: uuid(), conversationId: id, replyTo: reply?.id ?? null, ...p }); setReply(null); await load(); };
  const attach = async (kind: 'image' | 'video' | 'document') => { setPlus(false);
    try { const f = kind === 'document' ? await pickDocument() : await pickMedia(kind); if (!f) return; const fid = await upload(f); await send({ kind: f.kind, body: f.name, fileIds: [fid] }); }
    catch (e) { setErr(e instanceof Error ? e.message : 'Upload failed. Tap to retry.'); } };
  const voice = async (uri: string, secs: number) => { try { const fid = await upload({ uri, name: 'voice.m4a', mime: 'audio/mp4', size: 1, kind: 'voice', duration: secs }, 'audio'); await send({ kind: 'voice', fileIds: [fid] }); } catch { setErr('Voice message failed. Tap to retry.'); } };
  const newPoll = () => { setPlus(false); router.push({ pathname: '/chat/poll', params: { id } }); };
  const mine = (m: Msg) => m.senderId === myId.current || m.senderId === 'me';
  const tick = (m: Msg) => (m.status === 'sending' ? '🕓' : read.length && read.every((r) => r >= m.createdAt) ? '✓✓ Read' : '✓ Sent');
  const doSearch = async (q: string) => { setFind(q); if (q.length > 1) setHits((await repo.search(q, ['messages'])).filter((h) => h.snippet === id).map((h) => ({ id: h.id, title: h.title }))); else setHits([]); };

  return <Screen><Stack.Screen options={{ headerShown: true, title: title ?? 'Chat', headerRight: () => <Pressable onPress={() => setFind(find === null ? '' : null)} accessibilityLabel="Search in conversation"><Text style={{ fontSize: 20 }}>🔍</Text></Pressable> }} />
    {find !== null && <View style={{ padding: 8 }}><TextInput autoFocus value={find} onChangeText={doSearch} placeholder="Search in this conversation" placeholderTextColor={t.muted} style={{ backgroundColor: t.bg2, color: t.text, borderRadius: 10, padding: 10 }} />
      {hits.map((h) => <Text key={h.id} style={{ color: t.text, padding: 6 }}>• {h.title}</Text>)}</View>}
    <State loading={loading} error={err} reload={load} empty={!msgs.length && !queued.length} emptyText="No messages yet. Say hello.">
      {(polls.data ?? []).map((p: PollT) => <View key={p.id} style={{ padding: 10 }}><Poll poll={p} onChange={polls.reload} /></View>)}
      <FlatList inverted data={[...queued, ...msgs]} keyExtractor={(m) => m.id} onEndReached={older} contentContainerStyle={{ padding: 12, gap: 6 }}
        renderItem={({ item: m }) => <Pressable onLongPress={() => setSel(m)} style={{ alignSelf: mine(m) ? 'flex-end' : 'flex-start', maxWidth: '82%' }}>
          <View style={{ backgroundColor: mine(m) ? t.blue : t.bg2, padding: 10, borderRadius: 14, gap: 4 }}>
            {!mine(m) && <View style={{ flexDirection: 'row', gap: 4 }}><Text style={{ color: t.blue, fontWeight: '700', fontSize: 12 }}>{m.senderName}</Text>{m.senderVerified && <Verified />}</View>}
            {m.forwarded && <Text style={{ color: t.muted, fontSize: 11 }}>↪ Forwarded</Text>}
            {m.pinned && <Text style={{ fontSize: 11, color: t.red }}>📌 Pinned</Text>}
            {m.attachments.map((a) => a.kind === 'voice' ? <VoiceBubble key={a.id} f={a} /> : <FileRow key={a.id} f={a} />)}
            {m.kind === 'voice' && !m.attachments.length && <Text style={{ color: mine(m) ? '#fff' : t.text }}>🎤 Voice message</Text>}
            {!!m.body && m.kind !== 'voice' && <Text style={{ color: mine(m) ? '#fff' : t.text }}>{m.body}</Text>}
            {m.reactions.length > 0 && <Text>{m.reactions.map((r) => r.emoji).join(' ')}</Text>}
            <Text style={{ color: mine(m) ? '#ffffffaa' : t.muted, fontSize: 10, textAlign: 'right' }}>{when(m.createdAt)}{mine(m) ? '  ' + tick(m) : ''}</Text></View></Pressable>} />
    </State>
    {reply && <View style={{ flexDirection: 'row', padding: 8, backgroundColor: t.bg2 }}><Text style={{ flex: 1, color: t.muted }} numberOfLines={1}>Replying to: {reply.body}</Text><Pressable onPress={() => setReply(null)}><Text style={{ color: t.red }}>✕</Text></Pressable></View>}
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={{ flexDirection: 'row', gap: 8, padding: 8, alignItems: 'center', borderTopWidth: 1, borderColor: t.line }}>
        <Pressable onPress={() => setPlus(true)} accessibilityLabel="Attach" accessibilityRole="button"><Text style={{ fontSize: 26, color: t.blue }}>＋</Text></Pressable>
        <TextInput value={text} onChangeText={setText} placeholder="Message" placeholderTextColor={t.muted} multiline style={{ flex: 1, backgroundColor: t.bg2, color: t.text, borderRadius: 20, paddingHorizontal: 14, paddingVertical: 8, maxHeight: 110 }} />
        {text.trim() ? <Pressable accessibilityRole="button" accessibilityLabel="Send" onPress={() => { const b = text.trim(); setText(''); send({ body: b }); }} style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: t.red, alignItems: 'center', justifyContent: 'center' }}><Text style={{ color: '#fff', fontSize: 18 }}>➤</Text></Pressable> : <Recorder onDone={voice} />}</View></KeyboardAvoidingView>
    <Sheet visible={plus} onClose={() => setPlus(false)} actions={[{ label: '🖼 Photo', run: () => attach('image') }, { label: '🎬 Video', run: () => attach('video') }, { label: '📄 Document or PDF', run: () => attach('document') }, { label: '📊 Poll', run: newPoll }]} />
    <Sheet visible={!!sel} onClose={() => setSel(null)} actions={sel ? [
      { label: 'Reply', run: () => setReply(sel) }, { label: '😀 React 👍', run: () => repo.react(sel.id, '👍').then(load) },
      ...(sel.body ? [{ label: 'Copy', run: () => Clipboard.setStringAsync(sel.body!) }] : []),
      ...(!restrict ? [{ label: 'Forward', run: () => router.push({ pathname: '/forward', params: { m: sel.id } }) }] : []),
      { label: sel.pinned ? 'Unpin' : 'Pin', run: () => repo.pin(sel.id, !sel.pinned).then(load).catch((e) => setErr(e.message)) },
      ...(mine(sel) ? [{ label: 'Delete', danger: true, run: () => repo.deleteMessage(sel.id).then(load) }] : []),
      { label: 'Report', danger: true, run: () => router.push({ pathname: '/report', params: { type: 'message', id: sel.id } }) }] : []} />
  </Screen>;
}
