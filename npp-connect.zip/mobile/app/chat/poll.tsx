import { useState } from 'react';
import { ScrollView, Switch, Text, TextInput, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Page, useInput } from '@/ui/parts';
import { Button } from '@/ui/form';
import { useTheme } from '@/ui/theme';
import { repo } from '@/data/repo';

export default function NewPoll() {
  const { id } = useLocalSearchParams<{ id: string }>(); const t = useTheme(); const r = useRouter(); const inp = useInput();
  const [q, setQ] = useState(''); const [o, setO] = useState('Option A\nOption B'); const [multi, setMulti] = useState(false); const [anon, setAnon] = useState(false); const [close, setClose] = useState(''); const [err, setErr] = useState('');
  const go = async () => { try { const d = close.trim() ? new Date(close.replace(' ', 'T')) : null; if (d && isNaN(+d)) return setErr('Use 2026-10-12 18:00 for the closing date.');
    await repo.createPoll(id, q.trim(), o.split('\n').map((x) => x.trim()).filter(Boolean), multi, anon, d ? d.toISOString() : null); r.back(); } catch (e) { setErr(e instanceof Error ? e.message : 'Could not create poll.'); } };
  return <Page title="New poll"><ScrollView contentContainerStyle={{ padding: 14, gap: 10 }}>
    <TextInput value={q} onChangeText={setQ} placeholder="Question" placeholderTextColor={t.muted} style={inp} />
    <TextInput value={o} onChangeText={setO} multiline placeholder="One option per line" placeholderTextColor={t.muted} style={[inp, { minHeight: 90 }]} />
    <TextInput value={close} onChangeText={setClose} placeholder="Closing date (optional) 2026-10-12 18:00" placeholderTextColor={t.muted} style={inp} />
    <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}><Text style={{ color: t.text }}>Allow multiple choices</Text><Switch value={multi} onValueChange={setMulti} /></View>
    <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}><Text style={{ color: t.text }}>Anonymous</Text><Switch value={anon} onValueChange={setAnon} /></View>
    {!!err && <Text accessibilityRole="alert" style={{ color: t.red }}>{err}</Text>}
    <Button label="Create poll" onPress={go} disabled={q.trim().length < 2 || o.split('\n').filter((x) => x.trim()).length < 2} /></ScrollView></Page>;
}
