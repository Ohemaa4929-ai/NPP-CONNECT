import { FlatList, Share, Text, View } from 'react-native';
import { Page, State } from '@/ui/parts';
import { Button } from '@/ui/form';
import { useTheme } from '@/ui/theme';
import { repo } from '@/data/repo';
import { useAsync, when } from '@/lib/useAsync';

export default function Events() {
  const t = useTheme(); const { data, loading, error, reload } = useAsync(() => repo.events(), []);
  return <Page title="Events"><State loading={loading} error={error} reload={reload} empty={!data?.length} emptyText="No upcoming events.">
    <FlatList data={data} keyExtractor={(e) => e.id} contentContainerStyle={{ padding: 14, gap: 10 }} renderItem={({ item: e }) =>
      <View style={{ borderWidth: 1, borderColor: t.line, borderRadius: 14, padding: 12, gap: 4 }}>
        <Text style={{ color: t.text, fontWeight: '800', fontSize: 16 }}>{e.title}</Text><Text style={{ color: t.muted }}>{when(e.startsAt)} · {e.location ?? 'Location to be announced'}</Text>
        <Text style={{ color: t.muted }}>Organizer: {e.organizer} · {e.going} going</Text>{!!e.description && <Text style={{ color: t.text }}>{e.description}</Text>}
        <View style={{ flexDirection: 'row', gap: 8, marginTop: 6 }}>
          <View style={{ flex: 1 }}><Button label={e.myStatus === 'going' ? '✓ Registered' : e.registration ? 'Register' : 'I am going'} disabled={e.myStatus === 'going'}
            onPress={async () => { try { await repo.register(e.id, 'going', new Date(new Date(e.startsAt).getTime() - 3600_000).toISOString()); alert('Registered. A reminder is set for 1 hour before.'); reload(); } catch (x) { alert(x instanceof Error ? x.message : 'Could not register.'); } }} /></View>
          <View style={{ flex: 1 }}><Button label="Share" tone="blue" onPress={() => Share.share({ message: `${e.title}\n${when(e.startsAt)}\n${e.location ?? ''}` })} /></View></View></View>} /></State></Page>;
}
