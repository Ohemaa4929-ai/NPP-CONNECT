import { FlatList } from 'react-native';
import { Page, Row, State } from '@/ui/parts';
import { repo } from '@/data/repo';
import { useAsync, when } from '@/lib/useAsync';

export default function Notifications() {
  const { data, loading, error, reload } = useAsync(() => repo.notifications(), []);
  return <Page title="Notifications"><State loading={loading} error={error} reload={reload} empty={!data?.length} emptyText="You are all caught up.">
    <FlatList data={data} keyExtractor={(n) => n.id} renderItem={({ item: n }) => <Row title={(n.read ? '' : '● ') + n.title} sub={`${n.kind} · ${when(n.createdAt)}${n.body ? ' · ' + n.body : ''}`} onPress={() => repo.readNotification(n.id).then(reload)} />} /></State></Page>;
}
