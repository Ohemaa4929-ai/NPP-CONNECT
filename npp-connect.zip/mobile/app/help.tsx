import { useState } from 'react';
import { Linking, Pressable, ScrollView, Text } from 'react-native';
import { Page } from '@/ui/parts';
import { useTheme } from '@/ui/theme';

const FAQ: [string, string][] = [
  ['Why am I waiting for approval?', 'An administrator must verify your account and assign your area before you can use the app.'],
  ['Who can send announcements?', 'Only leaders an administrator has given broadcast rights for their own area and the areas below it.'],
  ['What is a confidential group?', 'An invitation-only group with forwarding turned off and optional disappearing messages. It is not end-to-end encrypted.'],
  ['How do I recover my account?', 'Log in with your phone number and the code we send. If you changed numbers, contact support.'],
  ['Community guidelines', 'Be respectful. No harassment, impersonation, scams or spam. Reports are reviewed by administrators.'],
  ['Terms of Service and Privacy Policy', 'Placeholders. Final text needs legal review before public launch.']];
// Replace SUPPORT_EMAIL with a real address before launch.
const SUPPORT_EMAIL = 'support@example.com';
export default function Help() {
  const t = useTheme(); const [open, setOpen] = useState<number | null>(null);
  const link = (l: string, subj: string) => <Pressable key={l} accessibilityRole="link" onPress={() => Linking.openURL(`mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(subj)}`)} style={{ padding: 14 }}><Text style={{ color: t.blue, fontWeight: '700' }}>{l}</Text></Pressable>;
  return <Page title="Help and support"><ScrollView>{FAQ.map(([q, a], i) => <Pressable key={q} onPress={() => setOpen(open === i ? null : i)} style={{ padding: 14, borderBottomWidth: 1, borderColor: t.line }}><Text style={{ color: t.text, fontWeight: '700' }}>{q}</Text>{open === i && <Text style={{ color: t.text, marginTop: 6 }}>{a}</Text>}</Pressable>)}
    {link('Contact support', 'NPP CONNECT support')}{link('Report a problem', 'NPP CONNECT problem report')}{link('Report a security issue', 'NPP CONNECT SECURITY issue')}{link('Account recovery help', 'NPP CONNECT account recovery')}</ScrollView></Page>;
}
