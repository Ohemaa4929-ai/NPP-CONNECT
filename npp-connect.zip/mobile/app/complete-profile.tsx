import { useState } from 'react';
import { Text, TextInput } from 'react-native';
import { AuthFrame, Button, inputStyle } from '@/ui/form';
import { useTheme } from '@/ui/theme';
import { useAuth } from '@/lib/auth';

// Collects only a name. Region, constituency and polling station are assigned by an admin.
export default function CompleteProfile() {
  const t = useTheme(); const { saveName } = useAuth();
  const [name, setName] = useState(''); const [err, setErr] = useState<string | null>(null);
  return <AuthFrame title="What is your name?">
    <TextInput value={name} onChangeText={setName} placeholder="Full name" placeholderTextColor={t.muted}
      accessibilityLabel="Full name" style={inputStyle(t)} />
    {err && <Text accessibilityRole="alert" style={{ color: t.red }}>{err}</Text>}
    <Button label="Continue" disabled={name.trim().length < 2} onPress={async () => setErr(await saveName(name))} />
  </AuthFrame>;
}
