import { useState } from 'react';
import { FlatList, Pressable, ScrollView, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Chip, Page, State, Verified } from '@/ui/parts';
import { VideoCard } from '@/ui/media';
import { useTheme } from '@/ui/theme';
import { repo } from '@/data/repo';
import { useAsync, when } from '@/lib/useAsync';

const CATS: [string, string][] = [['', 'All'], ['national_address', 'National Address'], ['regional_address', 'Regional Address'], ['constituency_address', 'Constituency Address'], ['announcement', 'Announcement'], ['training', 'Training'], ['event', 'Event'], ['other', 'Other']];
const mm = (s: number | null) => (s ? `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}` : '');
export default function Videos() {
  const t = useTheme(); const r = useRouter(); const [cat, setCat] = useState(''); const { data, loading, error, reload, setData } = useAsync(() => repo.videos(cat || undefined), [cat]);
  return <Page title="Leadership videos">
    <View><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ padding: 10, gap: 6 }}>{CATS.map(([k, l]) => <Chip key={k} label={l} on={cat === k} onPress={() => setCat(k)} />)}</ScrollView></View>
    <State loading={loading} error={error} reload={reload} empty={!data?.length} emptyText="No leadership videos.">
      <FlatList data={data} keyExtractor={(v) => v.id} contentContainerStyle={{ padding: 14, gap: 14 }} renderItem={({ item: v }) => <View style={{ gap: 6 }}>
        <VideoCard bucket={v.bucket} path={v.path} onPlay={() => repo.viewVideo(v.id)} />
        <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center' }}><Verified /><Text style={{ color: t.text, fontWeight: '700' }}>{v.author}</Text></View>
        <Text style={{ color: t.text, fontWeight: '800' }}>{v.title}</Text>{!!v.description && <Text style={{ color: t.text }}>{v.description}</Text>}
        <Text style={{ color: t.muted }}>{CATS.find((c) => c[0] === v.category)?.[1]} · {mm(v.duration)} · {v.views} views · {when(v.publishedAt)}</Text>
        <View style={{ flexDirection: 'row', gap: 16 }}>
          <Pressable onPress={async () => { await repo.saveVideo(v.id, !v.saved); setData((data ?? []).map((x) => x.id === v.id ? { ...x, saved: !x.saved } : x)); }}><Text style={{ color: t.blue }}>{v.saved ? '★ Saved' : '☆ Save'}</Text></Pressable>
          <Pressable onPress={() => r.push({ pathname: '/report', params: { type: 'video', id: v.id } })}><Text style={{ color: t.red }}>Report</Text></Pressable></View></View>} /></State></Page>;
}
