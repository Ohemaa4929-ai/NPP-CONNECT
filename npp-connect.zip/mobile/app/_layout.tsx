import { useEffect } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { Stack, useRouter, useSegments } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { AuthProvider, useAuth } from '@/lib/auth';
import { registerForPush } from '@/lib/push';
import { startOutbox } from '@/lib/outbox';

// Sends people to the right screen for their account state.
function Gate() {
  const { loading, signedIn, status, hasName } = useAuth();
  const seg = useSegments()[0] as string | undefined;
  const router = useRouter();
  useEffect(() => {
    useEffect(() => { if (signedIn && status === 'active') { registerForPush(); const off = startOutbox(); return () => off(); } }, [signedIn, status]);
  if (loading) return;
    const target = !signedIn ? (seg === 'verify' || seg === 'login' ? null : '/login')
      : status === 'suspended' || status === 'removed' ? '/blocked'
      : !hasName ? '/complete-profile'
      : status === 'pending' ? '/pending'
      : (seg === 'login' || seg === 'verify' || seg === 'pending' || seg === 'complete-profile' || seg === 'blocked') ? '/(tabs)' : null;
    if (target) router.replace(target as never);
  }, [loading, signedIn, status, hasName, seg, router]);
  useEffect(() => { if (signedIn && status === 'active') { registerForPush(); const off = startOutbox(); return () => off(); } }, [signedIn, status]);
  if (loading) return <View style={{ flex: 1, justifyContent: 'center' }}><ActivityIndicator size="large" /></View>;
  return <Stack screenOptions={{ headerShown: false }} />;
}
export default function Root() {
  return <AuthProvider><StatusBar style="auto" /><Gate /></AuthProvider>;
}
