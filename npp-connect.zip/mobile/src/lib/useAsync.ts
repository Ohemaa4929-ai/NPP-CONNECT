import { useCallback, useEffect, useState } from 'react';
export function useAsync<T>(fn: () => Promise<T>, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null); const [loading, setLoading] = useState(true); const [error, setError] = useState<string | null>(null);
  const run = useCallback(async () => { setLoading(true); setError(null); try { setData(await fn()); } catch (e) { setError(e instanceof Error ? e.message : 'Something went wrong.'); } finally { setLoading(false); } }, deps); // eslint-disable-line
  useEffect(() => { run(); }, [run]);
  return { data, loading, error, reload: run, setData };
}
export const when = (iso: string) => { const d = new Date(iso), n = new Date(); const t = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  return d.toDateString() === n.toDateString() ? t : d.toLocaleDateString([], { day: 'numeric', month: 'short' }) + ' ' + t; };
export const size = (b: number) => (b > 1e6 ? (b / 1e6).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1e3)) + ' KB');
