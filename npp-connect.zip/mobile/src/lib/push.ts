import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import Constants from 'expo-constants';
import { supabase } from './supabase';
import { config } from './config';

Notifications.setNotificationHandler({ handleNotification: async () => ({ shouldShowBanner: true, shouldShowList: true, shouldPlaySound: true, shouldSetBadge: false }) });

// Registers this phone for push. Needs an EAS projectId and FCM/APNs credentials (see docs/DEPLOY.md).
export async function registerForPush() {
  if (config.demo || !Device.isDevice) return;
  const perm = await Notifications.requestPermissionsAsync(); if (!perm.granted) return;
  const projectId = Constants.expoConfig?.extra?.eas?.projectId; if (!projectId) return;
  const token = (await Notifications.getExpoPushTokenAsync({ projectId })).data;
  const uid = (await supabase.auth.getUser()).data.user?.id; if (!uid) return;
  const { data: ex } = await supabase.from('devices').select('id').eq('user_id', uid).eq('push_token', token).maybeSingle();
  if (ex) await supabase.from('devices').update({ last_active_at: new Date().toISOString(), revoked_at: null }).eq('id', ex.id);
  else await supabase.from('devices').insert({ user_id: uid, label: Device.modelName ?? 'Phone', push_token: token });
  await supabase.rpc('touch_presence');
}
