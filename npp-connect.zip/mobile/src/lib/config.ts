export const config = {
  env: process.env.EXPO_PUBLIC_APP_ENV ?? 'development',
  demo: process.env.EXPO_PUBLIC_DEMO_MODE !== 'false',
  supabaseUrl: process.env.EXPO_PUBLIC_SUPABASE_URL ?? '',
  supabaseAnonKey: process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ?? '',
};
