import AsyncStorage from '@react-native-async-storage/async-storage';
import NetInfo from '@react-native-community/netinfo';
import { repo } from '@/data/repo';

// Offline queue: messages wait on the device and resend when the connection returns. client_id prevents duplicates.
export type Pending = { clientId: string; conversationId: string; body?: string; kind?: string; replyTo?: string | null; fileIds?: string[] };
const KEY = 'npp.outbox.v1';
const read = async (): Promise<Pending[]> => JSON.parse((await AsyncStorage.getItem(KEY)) ?? '[]');
export const pending = async (conv: string) => (await read()).filter((p) => p.conversationId === conv);
export async function enqueueAndSend(p: Pending) {
  await AsyncStorage.setItem(KEY, JSON.stringify([...(await read()), p]));
  return flush();
}
let flushing = false;
export async function flush() {
  if (flushing) return; flushing = true;
  try {
    for (const p of await read()) {
      try { await repo.send(p.conversationId, p); await AsyncStorage.setItem(KEY, JSON.stringify((await read()).filter((x) => x.clientId !== p.clientId))); }
      catch { break; }   // stay queued; try again on reconnect
    }
  } finally { flushing = false; }
}
export const startOutbox = () => NetInfo.addEventListener((s) => { if (s.isConnected) flush(); });
