import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import * as ImageManipulator from 'expo-image-manipulator';
import { supabase } from './supabase';
import { config } from './config';

export type Picked = { uri: string; name: string; mime: string; size: number; kind: 'image' | 'video' | 'audio' | 'voice' | 'document'; duration?: number };
const LIMIT = 100 * 1024 * 1024;
const ALLOWED = /^(image\/(jpeg|png|webp|heic)|video\/(mp4|quicktime)|audio\/(mpeg|mp4|aac|m4a|x-m4a|ogg|webm)|application\/(pdf|zip|msword|vnd\.ms-excel|vnd\.ms-powerpoint|vnd\.openxmlformats-officedocument\..+))$/;

export async function pickMedia(kind: 'image' | 'video'): Promise<Picked | null> {
  const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: kind === 'image' ? ['images'] : ['videos'], quality: 0.7,
    videoExportPreset: ImagePicker.VideoExportPreset.MediumQuality });   // device-side video compression
  if (r.canceled) return null; const a = r.assets[0];
  if (kind === 'image') {                                                // shrink large photos for slow networks
    const m = await ImageManipulator.manipulateAsync(a.uri, [{ resize: { width: Math.min(a.width, 1600) } }], { compress: 0.7, format: ImageManipulator.SaveFormat.JPEG });
    return { uri: m.uri, name: (a.fileName ?? 'photo') + '.jpg', mime: 'image/jpeg', size: a.fileSize ?? 0, kind };
  }
  return { uri: a.uri, name: a.fileName ?? 'video.mp4', mime: a.mimeType ?? 'video/mp4', size: a.fileSize ?? 0, kind, duration: a.duration ? Math.round(a.duration / 1000) : undefined };
}
export async function pickDocument(): Promise<Picked | null> {
  const r = await DocumentPicker.getDocumentAsync({ copyToCacheDirectory: true }); if (r.canceled) return null; const a = r.assets[0];
  return { uri: a.uri, name: a.name, mime: a.mimeType ?? 'application/octet-stream', size: a.size ?? 0, kind: 'document' };
}
const bucketFor = (k: Picked['kind']) => ({ image: 'messages', video: 'videos', audio: 'audio', voice: 'audio', document: 'documents' }[k]);

// Validates type and size, uploads with up to 3 retries, records a files row. Returns the file id.
export async function upload(p: Picked, bucket?: string, onTry?: (n: number) => void): Promise<string> {
  if (!ALLOWED.test(p.mime)) throw new Error('This file type is not allowed.');
  if (p.size > LIMIT) throw new Error('File is too large. The limit is 100 MB.');
  if (config.demo) return 'demo-file';
  const uid = (await supabase.auth.getUser()).data.user!.id; const b = bucket ?? bucketFor(p.kind);
  const path = `${uid}/${Date.now()}-${p.name.replace(/[^\w.\-]/g, '_')}`;
  const buf = await (await fetch(p.uri)).arrayBuffer();
  let last: unknown;
  for (let i = 1; i <= 3; i++) {
    onTry?.(i);
    const { error } = await supabase.storage.from(b).upload(path, buf, { contentType: p.mime, upsert: false });
    if (!error) {
      const { data, error: e2 } = await supabase.from('files').insert({ bucket: b, path, name: p.name, mime: p.mime, size_bytes: buf.byteLength, kind: p.kind, duration_s: p.duration ?? null }).select('id').single();
      if (e2) throw new Error(e2.message); return data.id as string;
    }
    last = error; await new Promise((r) => setTimeout(r, 800 * i));
  }
  throw new Error('Upload failed. Tap to retry.' + (last ? '' : ''));
}
// Private files: short-lived signed URLs only, never public links.
export async function signedUrl(bucket: string, path: string, secs = 300) {
  if (config.demo) return null;
  const { data } = await supabase.storage.from(bucket).createSignedUrl(path, secs); return data?.signedUrl ?? null;
}
