// Normalizes Ghana numbers to E.164 (+233XXXXXXXXX). Returns null if invalid.
export function normalizeGhanaPhone(input: string): string | null {
  const d = input.replace(/[\s\-().]/g, '');
  let n: string;
  if (d.startsWith('+233')) n = d.slice(4);
  else if (d.startsWith('233')) n = d.slice(3);
  else if (d.startsWith('0')) n = d.slice(1);
  else n = d;
  return /^[235]\d{8}$/.test(n) ? `+233${n}` : null;
}
