import { createContext, ReactNode, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { Session } from '@supabase/supabase-js';
import { config } from './config';
import { supabase } from './supabase';

export type AccountStatus = 'pending' | 'active' | 'suspended' | 'removed';
type Ctx = {
  loading: boolean; signedIn: boolean; status: AccountStatus | null; hasName: boolean;
  sendOtp: (phoneE164: string) => Promise<string | null>;          // returns error text or null
  verifyOtp: (phoneE164: string, code: string) => Promise<string | null>;
  saveName: (name: string) => Promise<string | null>;
  signOut: () => Promise<void>; refresh: () => Promise<void>;
};
const AuthCtx = createContext<Ctx>(null as unknown as Ctx);
export const useAuth = () => useContext(AuthCtx);

// Plain-language errors. Raw backend messages are never shown to people.
const friendly = (e: { message?: string; status?: number } | null) =>
  !e ? null
  : e.status === 429 ? 'Too many attempts. Wait a minute and try again.'
  : /invalid|expired/i.test(e.message ?? '') ? 'That code is wrong or has expired. Request a new one.'
  : 'Something went wrong. Check your connection and try again.';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [status, setStatus] = useState<AccountStatus | null>(null);
  const [hasName, setHasName] = useState(false);
  const [loading, setLoading] = useState(true);
  const [demoIn, setDemoIn] = useState(false);

  const loadProfile = useCallback(async (s: Session | null) => {
    if (!s) { setStatus(null); setHasName(false); return; }
    const { data } = await supabase.from('profiles').select('status, full_name').eq('id', s.user.id).single();
    setStatus((data?.status as AccountStatus) ?? null);
    setHasName(!!data?.full_name);
  }, []);

  useEffect(() => {
    if (config.demo) { setLoading(false); return; }
    supabase.auth.getSession().then(async ({ data }) => { setSession(data.session); await loadProfile(data.session); setLoading(false); });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => { setSession(s); loadProfile(s); });
    return () => sub.subscription.unsubscribe();
  }, [loadProfile]);

  const value = useMemo<Ctx>(() => ({
    loading,
    signedIn: config.demo ? demoIn : !!session,
    status: config.demo ? (demoIn ? 'active' : null) : status,
    hasName: config.demo ? true : hasName,
    sendOtp: async (phone) => {
      if (config.demo) return null;
      const { error } = await supabase.auth.signInWithOtp({ phone });
      return friendly(error);
    },
    verifyOtp: async (phone, token) => {
      if (config.demo) { setDemoIn(token === '123456' ? true : false); return token === '123456' ? null : 'Demo code is 123456.'; }
      const { error } = await supabase.auth.verifyOtp({ phone, token, type: 'sms' });
      return friendly(error);
    },
    saveName: async (name) => {
      if (config.demo || !session) return null;
      const { error } = await supabase.from('profiles').update({ full_name: name.trim() }).eq('id', session.user.id);
      if (!error) setHasName(true);
      return error ? 'Could not save your name. Try again.' : null;
    },
    signOut: async () => { if (config.demo) setDemoIn(false); else await supabase.auth.signOut(); },
    refresh: async () => { await loadProfile(session); },
  }), [loading, session, status, hasName, demoIn, loadProfile]);

  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>;
}
