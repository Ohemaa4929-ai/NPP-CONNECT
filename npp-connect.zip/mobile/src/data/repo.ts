import { config } from '@/lib/config';
import { live } from './live';
import { demo } from './demo';
// One interface, two backends. Demo mode never touches the network.
export const repo = (config.demo ? demo : live) as typeof live;
export type { } from './types';
