import type * as T from './types';
import { demoBroadcasts, demoChats, demoGroups } from '@/demo/data';

// In-memory fictional data. Everything here is labeled DEMO.
const now = Date.now(); const iso = (h: number) => new Date(now + h * 3600_000).toISOString();
const msgs: Record<string, T.Msg[]> = {};
const seed = (c: string): T.Msg[] => msgs[c] ??= [
  { id: c + 'a', senderId: 'x', senderName: 'Constituency Exec (Demo)', senderVerified: true, kind: 'text', body: 'Good morning. Please share the turnout sheet.', replyTo: null, forwarded: false, pinned: true, createdAt: iso(-3), attachments: [], reactions: [] },
  { id: c + 'b', senderId: 'x', senderName: 'Constituency Exec (Demo)', senderVerified: true, kind: 'voice', body: null, replyTo: null, forwarded: false, pinned: false, createdAt: iso(-2), attachments: [{ id: 'v1', name: 'voice.m4a', mime: 'audio/mp4', size: 90000, bucket: 'audio', path: 'demo', duration: 24, kind: 'voice' }], reactions: [] },
];
let polls: T.PollT[] = [{ id: 'p1', question: 'Which date for the meeting? (demo)', multiple: false, anonymous: false, closesAt: null, mine: [], options: [{ id: 'o1', label: 'Saturday', votes: 14 }, { id: 'o2', label: 'Sunday', votes: 9 }, { id: 'o3', label: 'Next week', votes: 4 }] }];
const bcs: T.Broadcast[] = demoBroadcasts.map((b) => ({ id: b.id, title: b.title, body: b.body, priority: b.priority === 'urgent' ? 'urgent' : 'normal', author: b.from, verified: true, publishedAt: iso(-5), views: 1240, allowComments: true, allowForwarding: true, confidential: false, read: false, files: [] }));
const ok = async () => { await new Promise((r) => setTimeout(r, 250)); };

export const demo = {
  chats: async (): Promise<T.Chat[]> => (await ok(), demoChats.map((c) => ({ id: c.id, kind: 'direct' as const, title: c.name, groupId: null, last: c.last, lastAt: iso(-1), unread: c.unread, restrictForwarding: false, disappearSecs: null }))),
  messages: async (c: string, before?: { at: string; id: string }) => (await ok(), before ? [] : [...seed(c)].reverse()),
  send: async (c: string, p: { clientId: string; body?: string; kind?: string }) => { seed(c).push({ id: p.clientId, senderId: 'me', senderName: 'Demo Member', senderVerified: false, kind: p.kind ?? 'text', body: p.body ?? null, replyTo: null, forwarded: false, pinned: false, createdAt: new Date().toISOString(), attachments: [], reactions: [] }); },
  receipts: async () => [], markRead: async () => {}, react: async () => {}, deleteMessage: async (m: string) => { Object.values(msgs).forEach((l) => { const i = l.findIndex((x) => x.id === m); if (i >= 0) l.splice(i, 1); }); },
  pin: async () => {}, forward: async () => {}, startDirect: async (u: string) => demoChats[0].id, people: async (q: string): Promise<T.Person[]> => [{ id: 'p1', name: 'Regional Leader (Demo)', verified: true }, { id: 'p2', name: 'Grassroots Member (Demo)', verified: false }].filter((p) => p.name.toLowerCase().includes(q.toLowerCase())),
  groups: async (): Promise<T.Group[]> => demoGroups.map((g) => ({ id: g.id, conversationId: g.id, name: g.name, description: g.members + ' members', confidential: g.confidential, privacy: g.confidential ? 'private' : 'open', member: g.id !== 'g2' })),
  createGroup: async () => 'g-new', joinGroup: async () => 'pending',
  members: async (): Promise<T.Member[]> => [{ userId: 'a', name: 'Demo Admin', verified: true, role: 'admin', status: 'active' }, { userId: 'b', name: 'Demo Member', verified: false, role: 'member', status: 'active' }],
  addMember: async () => {}, approveMember: async () => {}, removeMember: async () => {}, acceptInvite: async () => {}, disappearing: async () => {}, pinned: async () => [{ id: 'x', body: 'Good morning. Please share the turnout sheet.' }],
  broadcasts: async (): Promise<T.Broadcast[]> => (await ok(), [...bcs]), markBroadcastRead: async () => {},
  units: async (): Promise<T.Unit[]> => ['Demo Nation', 'Demo Region', 'Demo North Constituency', 'Demo Electoral Area', 'Demo Polling Station DS-001'].map((n, i) => ({ id: 'u' + i, name: n, level: i + 1 })),
  publishBroadcast: async (n: T.NewBroadcast) => { if (!n.asDraft) bcs.unshift({ id: 'n' + Date.now(), title: n.title, body: n.body, priority: n.priority, author: 'You (Demo)', verified: true, publishedAt: new Date().toISOString(), views: 0, allowComments: n.allowComments, allowForwarding: n.allowForwarding, confidential: n.confidential, read: true, files: [] }); return n.asDraft ? 'draft' : n.scheduledAt ? 'scheduled' : 'sending'; },
  comments: async () => [{ id: 'c1', user: 'Demo Member', body: 'Received, thank you.', at: iso(-1) }], comment: async () => {}, reactBroadcast: async () => {},
  polls: async () => polls, createPoll: async () => {}, vote: async (p: string, opts: string[]) => { polls = polls.map((x) => x.id !== p ? x : { ...x, mine: opts, options: x.options.map((o) => ({ ...o, votes: o.votes + (opts.includes(o.id) ? 1 : 0) })) }); },
  videos: async (): Promise<T.VideoT[]> => [{ id: 'vid1', title: 'Message to all members (demo)', description: 'Placeholder video', category: 'national_address', author: 'National Leader (Demo)', verified: true, publishedAt: iso(-8), duration: 252, views: 2904, bucket: 'videos', path: 'demo', saved: false }],
  saveVideo: async () => {}, viewVideo: async () => {},
  events: async (): Promise<T.EventT[]> => [{ id: 'ev1', title: 'Constituency town hall (demo)', description: 'Open meeting for members.', startsAt: iso(48), location: 'Demo Community Centre', organizer: 'Constituency Exec (Demo)', registration: true, going: 38, myStatus: null }],
  register: async () => {}, documents: async (): Promise<T.DocT[]> => [{ id: 'd1', name: 'Member handbook (demo).pdf', mime: 'application/pdf', size: 1_200_000, bucket: 'documents', path: 'demo', owner: 'National Leader (Demo)', createdAt: iso(-30) }],
  notifications: async (): Promise<T.Notif[]> => [{ id: 'n1', kind: 'broadcast', title: 'Important Leadership Update', body: 'Demo broadcast', createdAt: iso(-5), read: false }, { id: 'n2', kind: 'security', title: 'New device signed in', body: 'Demo phone', createdAt: iso(-20), read: true }],
  readNotification: async () => {}, search: async (q: string): Promise<T.Hit[]> => q.length < 2 ? [] : [{ kind: 'people', id: 'p1', title: 'Regional Leader (Demo)', snippet: null }, { kind: 'broadcasts', id: 'b1', title: 'Important Leadership Update', snippet: 'Welcome to NPP CONNECT…' }, { kind: 'documents', id: 'd1', title: 'Member handbook (demo).pdf', snippet: 'application/pdf' }],
  report: async () => {}, block: async () => {},
  privacy: async (): Promise<T.Privacy> => ({ profile_visibility: 'org', phone_visibility: 'leaders', last_seen: 'org', online_status: true, read_receipts: true, group_invites: 'org' }), setPrivacy: async () => {},
  notifMode: async () => 'all', setNotifMode: async () => {}, devices: async (): Promise<T.DeviceT[]> => [{ id: 'dv1', label: 'This phone (demo)', lastActive: iso(0), revoked: false }], revokeDevice: async () => {},
  profile: async () => ({ full_name: 'Demo Member', phone: '+233200000006', bio: null as string | null, verified_at: null as string | null }), saveBio: async () => {},
};
