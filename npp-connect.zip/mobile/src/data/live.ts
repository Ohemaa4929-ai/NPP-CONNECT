import { supabase } from '@/lib/supabase';
import type * as T from './types';

const fail = (e: { message: string } | null) => { if (e) throw new Error(e.message.replace(/^rate_limited: /, '')); };
const rpc = async <R,>(fn: string, args?: object) => { const { data, error } = await supabase.rpc(fn, args); fail(error); return data as R; };
const me = async () => (await supabase.auth.getUser()).data.user!.id;
const file = (f: Record<string, unknown>): T.FileRef => ({ id: f.id as string, name: f.name as string, mime: f.mime as string, size: f.size as number, bucket: f.bucket as string, path: f.path as string, duration: f.duration as number | null, thumb: f.thumb as string | null, kind: f.kind as string });

export const live = {
  async chats(): Promise<T.Chat[]> {
    return (await rpc<any[]>('my_chats')).map((c) => ({ id: c.id, kind: c.kind, title: c.title ?? 'Chat', groupId: c.group_id, last: c.last_body, lastAt: c.last_at, unread: Number(c.unread), restrictForwarding: c.restrict_forwarding, disappearSecs: c.disappear_secs }));
  },
  async messages(conv: string, before?: { at: string; id: string }): Promise<T.Msg[]> {
    return (await rpc<any[]>('get_messages', { conv, before_at: before?.at ?? null, before_id: before?.id ?? null, lim: 30 })).map((m) => ({
      id: m.id, senderId: m.sender_id, senderName: m.sender_name, senderVerified: m.sender_verified, kind: m.kind, body: m.body, replyTo: m.reply_to, forwarded: m.forwarded,
      pinned: m.pinned, createdAt: m.created_at, attachments: (m.attachments ?? []).map(file), reactions: m.reactions ?? [] }));
  },
  // client_id makes retries idempotent: a resend after a dropped connection never duplicates the message.
  async send(conv: string, p: { clientId: string; body?: string; kind?: string; replyTo?: string | null; fileIds?: string[] }) {
    const { data, error } = await supabase.from('messages').insert({ conversation_id: conv, body: p.body ?? null, kind: p.kind ?? 'text', reply_to: p.replyTo ?? null, client_id: p.clientId }).select('id').single();
    if (error?.code === '23505') return;      // already delivered on an earlier attempt
    fail(error);
    if (p.fileIds?.length) fail((await supabase.from('message_attachments').insert(p.fileIds.map((f) => ({ message_id: data!.id, file_id: f })))).error);
  },
  async receipts(conv: string) { return (await rpc<{ user_id: string; last_read_at: string | null }[]>('chat_receipts', { conv })); },
  markRead: (c: string) => rpc('mark_read', { c }),
  react: async (m: string, emoji: string) => fail((await supabase.from('message_reactions').insert({ message_id: m, emoji })).error),
  deleteMessage: (m: string) => rpc('delete_message', { m }),
  pin: (m: string, v: boolean) => rpc('pin_message', { m, v }),
  forward: (m: string, to_conv: string) => rpc('forward_message', { m, to_conv }),
  startDirect: (other: string) => rpc<string>('start_direct', { other }),
  people: async (q: string): Promise<T.Person[]> => (await rpc<any[]>('find_people', { q })).map((p) => ({ id: p.id, name: p.full_name, verified: p.is_verified })),
  async groups(): Promise<T.Group[]> {
    const { data, error } = await supabase.from('groups').select('id,conversation_id,name,description,confidential,privacy').limit(100); fail(error);
    const mine = new Set((await live.chats()).map((c) => c.id));
    return (data ?? []).map((g) => ({ id: g.id, conversationId: g.conversation_id, name: g.name, description: g.description, confidential: g.confidential, privacy: g.privacy, member: mine.has(g.conversation_id) }));
  },
  createGroup: (a: { name: string; desc: string; unit: string | null; privacy: string; confidential: boolean }) =>
    rpc<string>('create_group', { p_name: a.name, p_desc: a.desc, p_unit: a.unit, p_privacy: a.privacy, p_confidential: a.confidential }),
  joinGroup: (g: string) => rpc<string>('join_group', { g }),
  async members(conv: string): Promise<T.Member[]> { return (await rpc<any[]>('group_members', { conv })).map((m) => ({ userId: m.user_id, name: m.full_name, verified: m.verified, role: m.role, status: m.status })); },
  addMember: (c: string, u: string) => rpc('add_member', { c, u }), approveMember: (c: string, u: string) => rpc('approve_member', { c, u }),
  removeMember: async (c: string, u: string) => rpc('remove_member', { c, u: u === 'me' ? await me() : u }), acceptInvite: (c: string) => rpc('accept_invite', { c }),
  disappearing: (c: string, secs: number) => rpc('set_disappearing', { c, secs }),
  async pinned(conv: string) { const { data } = await supabase.from('messages').select('id,body').eq('conversation_id', conv).eq('pinned', true).is('deleted_at', null); return (data ?? []) as { id: string; body: string | null }[]; },

  async broadcasts(before?: string): Promise<T.Broadcast[]> {
    return (await rpc<any[]>('broadcast_feed', { lim: 30, before_at: before ?? null })).map((b) => ({ id: b.id, title: b.title, body: b.body, priority: b.priority, author: b.author_name, verified: b.author_verified,
      publishedAt: b.published_at ?? b.delivered_at, views: Number(b.view_count), allowComments: b.allow_comments, allowForwarding: b.allow_forwarding, confidential: b.confidential, read: !!b.read_at, files: (b.files ?? []).map(file) }));
  },
  markBroadcastRead: (b: string) => rpc('mark_broadcast_read', { b }),
  async units(): Promise<T.Unit[]> { const { data } = await supabase.from('org_units').select('id,name,level_rank').order('path'); return (data ?? []).map((u) => ({ id: u.id, name: u.name, level: u.level_rank })); },
  async publishBroadcast(n: T.NewBroadcast): Promise<string> {
    const { data, error } = await supabase.from('broadcasts').insert({ title: n.title, body: n.body, org_unit_id: n.unitId, priority: n.priority, scheduled_at: n.scheduledAt,
      allow_comments: n.allowComments, allow_forwarding: n.confidential ? false : n.allowForwarding, confidential: n.confidential }).select('id').single(); fail(error);
    const id = data!.id as string;
    if (n.fileIds.length) fail((await supabase.from('broadcast_files').insert(n.fileIds.map((f) => ({ broadcast_id: id, file_id: f })))).error);
    if (n.poll) { const p = await supabase.from('polls').insert({ broadcast_id: id, question: n.poll.question, multiple: n.poll.multiple }).select('id').single(); fail(p.error);
      fail((await supabase.from('poll_options').insert(n.poll.options.map((label, i) => ({ poll_id: p.data!.id, label, position: i })))).error); }
    return n.asDraft ? 'draft' : await rpc<string>('publish_broadcast', { b: id });
  },
  async comments(b: string) { return (await rpc<any[]>('broadcast_comment_list', { b })).map((c) => ({ id: c.id as string, user: c.user_name as string, body: c.body as string, at: c.created_at as string })); },
  comment: async (b: string, body: string) => fail((await supabase.from('broadcast_comments').insert({ broadcast_id: b, body })).error),
  reactBroadcast: async (b: string, emoji: string) => fail((await supabase.from('broadcast_reactions').upsert({ broadcast_id: b, user_id: await me(), emoji })).error),

  async polls(by: { conversationId?: string; broadcastId?: string }): Promise<T.PollT[]> {
    let q = supabase.from('polls').select('id,question,multiple,anonymous,closes_at'); q = by.conversationId ? q.eq('conversation_id', by.conversationId) : q.eq('broadcast_id', by.broadcastId!);
    const { data } = await q; const uid = await me(); const out: T.PollT[] = [];
    for (const p of data ?? []) {
      const res = await rpc<any[]>('poll_results', { p: p.id });
      const mine = ((await supabase.from('poll_votes').select('option_id').eq('poll_id', p.id).eq('user_id', uid)).data ?? []).map((v) => v.option_id as string);
      out.push({ id: p.id, question: p.question, multiple: p.multiple, anonymous: p.anonymous, closesAt: p.closes_at, options: res.map((r) => ({ id: r.option_id, label: r.label, votes: Number(r.votes) })), mine });
    } return out;
  },
  async createPoll(conversationId: string, question: string, options: string[], multiple: boolean, anonymous: boolean, closesAt: string | null) {
    const p = await supabase.from('polls').insert({ conversation_id: conversationId, question, multiple, anonymous, closes_at: closesAt }).select('id').single(); fail(p.error);
    fail((await supabase.from('poll_options').insert(options.map((label, i) => ({ poll_id: p.data!.id, label, position: i })))).error);
  },
  vote: (p: string, opts: string[]) => rpc('cast_vote', { p, opts }),

  async videos(cat?: string): Promise<T.VideoT[]> { return (await rpc<any[]>('list_videos', { cat: cat ?? null })).map((v) => ({ id: v.id, title: v.title, description: v.description, category: v.category, author: v.author_name, verified: v.author_verified, publishedAt: v.published_at, duration: v.duration_s, views: Number(v.view_count), bucket: v.bucket, path: v.path, saved: v.saved })); },
  async saveVideo(v: string, on: boolean) { const uid = await me(); fail(on ? (await supabase.from('video_saves').insert({ user_id: uid, video_id: v })).error : (await supabase.from('video_saves').delete().eq('video_id', v).eq('user_id', uid)).error); },
  viewVideo: (v: string) => rpc('record_video_view', { v }),
  async events(): Promise<T.EventT[]> { return (await rpc<any[]>('list_events')).map((e) => ({ id: e.id, title: e.title, description: e.description, startsAt: e.starts_at, location: e.location, organizer: e.organizer_name, registration: e.registration_required, going: Number(e.going), myStatus: e.my_status })); },
  async register(e: string, status: 'going' | 'declined', reminderAt?: string) { fail((await supabase.from('event_attendees').upsert({ event_id: e, user_id: await me(), status, reminder_at: reminderAt ?? null })).error); },
  async documents(): Promise<T.DocT[]> { return (await rpc<any[]>('list_documents')).map((d) => ({ id: d.id, name: d.name, mime: d.mime, size: Number(d.size_bytes), bucket: d.bucket, path: d.path, owner: d.owner_name, createdAt: d.created_at })); },
  async notifications(): Promise<T.Notif[]> { const { data } = await supabase.from('notifications').select('*').order('created_at', { ascending: false }).limit(50); return (data ?? []).map((n) => ({ id: n.id, kind: n.kind, title: n.title, body: n.body, createdAt: n.created_at, read: !!n.read_at })); },
  readNotification: async (id: string) => { await supabase.from('notifications').update({ read_at: new Date().toISOString() }).eq('id', id); },
  async search(q: string, kinds?: string[]): Promise<T.Hit[]> { return (await rpc<any[]>('search_all', { q, kinds: kinds ?? null })).map((h) => ({ kind: h.kind, id: h.id, title: h.title, snippet: h.snippet })); },
  report: async (type: string, id: string, reason: string, detail: string) => fail((await supabase.from('reports').insert({ target_type: type, target_id: id, reason, detail })).error),
  block: async (u: string) => fail((await supabase.from('blocks').insert({ blocker: await me(), blocked: u })).error),
  async privacy(): Promise<T.Privacy> { const { data, error } = await supabase.from('privacy_settings').select('*').single(); fail(error); return data as T.Privacy; },
  async setPrivacy(p: Partial<T.Privacy>) { fail((await supabase.from('privacy_settings').update(p).eq('user_id', await me())).error); },
  async notifMode(): Promise<string> { const { data } = await supabase.from('notification_settings').select('mode').single(); return data?.mode ?? 'all'; },
  async setNotifMode(mode: string) { fail((await supabase.from('notification_settings').update({ mode }).eq('user_id', await me())).error); },
  async devices(): Promise<T.DeviceT[]> { const { data } = await supabase.from('devices').select('id,label,last_active_at,revoked_at').order('last_active_at', { ascending: false }); return (data ?? []).map((d) => ({ id: d.id, label: d.label, lastActive: d.last_active_at, revoked: !!d.revoked_at })); },
  revokeDevice: (d: string) => rpc('revoke_device', { d }),
  async profile() { const { data } = await supabase.from('profiles').select('full_name,phone,bio,verified_at').single(); return data as { full_name: string; phone: string | null; bio: string | null; verified_at: string | null }; },
  async saveBio(bio: string) { fail((await supabase.from('profiles').update({ bio }).eq('id', await me())).error); },
};
