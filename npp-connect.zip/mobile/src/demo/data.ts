// Fictional demo data. Every account here is marked DEMO. No real people.
export const demoBroadcasts = [
  { id: 'b1', title: 'Important Leadership Update', from: 'National Leader (Demo)', audience: 'Demo Members',
    priority: 'urgent' as const, when: 'Today, 09:00', body: 'Welcome to NPP CONNECT. This is a demonstration of the leadership broadcast system.' },
  { id: 'b2', title: 'Regional coordination call', from: 'Regional Leader (Demo)', audience: 'Region',
    priority: 'normal' as const, when: 'Yesterday', body: 'Call on Thursday at 18:00. Constituency executives should confirm attendance.' },
];
export const demoChats = [
  { id: 'c1', name: 'Constituency Exec (Demo)', last: 'Please share the turnout sheet.', unread: 2 },
  { id: 'c2', name: 'Electoral Area Coord. (Demo)', last: 'Meeting moved to 4pm', unread: 0 },
  { id: 'c3', name: 'Polling Station Exec (Demo)', last: 'Thank you.', unread: 0 },
];
export const demoGroups = [
  { id: 'g1', name: 'Region Executives', members: 48, confidential: true },
  { id: 'g2', name: 'Youth Wing (Demo)', members: 2310, confidential: false },
  { id: 'g3', name: 'Constituency Planning', members: 12, confidential: true },
];
