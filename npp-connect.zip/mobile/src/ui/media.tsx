import { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Linking, Pressable, Text, View } from 'react-native';
import { AudioModule, RecordingPresets, useAudioPlayer, useAudioPlayerStatus, useAudioRecorder, setAudioModeAsync } from 'expo-audio';
import { VideoView, useVideoPlayer } from 'expo-video';
import { signedUrl } from '@/lib/upload';
import { useTheme } from './theme';
import { size } from '@/lib/useAsync';
import type { FileRef } from '@/data/types';

const mmss = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;

function Player({ uri, fallback }: { uri: string; fallback: number }) {
  const t = useTheme(); const player = useAudioPlayer(uri); const st = useAudioPlayerStatus(player);
  const dur = st.duration || fallback; const pct = dur ? Math.min(100, (st.currentTime / dur) * 100) : 0;
  return <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, minWidth: 200 }}>
    <Pressable accessibilityRole="button" accessibilityLabel={st.playing ? 'Pause' : 'Play'} onPress={() => (st.playing ? player.pause() : player.play())}><Text style={{ fontSize: 22, color: t.blue }}>{st.playing ? '⏸' : '▶'}</Text></Pressable>
    <View style={{ flex: 1, height: 4, borderRadius: 2, backgroundColor: t.line }}><View style={{ width: `${pct}%`, height: 4, borderRadius: 2, backgroundColor: t.red }} /></View>
    <Text style={{ color: t.muted, fontSize: 12 }}>{mmss(st.playing ? st.currentTime : dur)}</Text></View>;
}
export function VoiceBubble({ f }: { f: FileRef }) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => { signedUrl(f.bucket, f.path).then(setUrl); }, [f.bucket, f.path]);
  return url ? <Player uri={url} fallback={f.duration ?? 0} /> : <Text accessibilityLabel="Voice message">▶ ▬▬▬▬ {mmss(f.duration ?? 0)}</Text>;
}
export function VideoCard({ bucket, path, onPlay }: { bucket: string; path: string; onPlay?: () => void }) {
  const t = useTheme(); const [url, setUrl] = useState<string | null>(null); const [busy, setBusy] = useState(false);
  const load = async () => { setBusy(true); setUrl(await signedUrl(bucket, path, 900)); setBusy(false); onPlay?.(); };
  if (!url) return <Pressable onPress={load} accessibilityRole="button" accessibilityLabel="Play video" style={{ height: 160, borderRadius: 12, backgroundColor: t.blue, alignItems: 'center', justifyContent: 'center' }}>
    {busy ? <ActivityIndicator color="#fff" /> : <Text style={{ color: '#fff', fontSize: 40 }}>▶</Text>}</Pressable>;
  return <Inline url={url} />;
}
function Inline({ url }: { url: string }) { const p = useVideoPlayer(url, (x) => { x.play(); }); return <VideoView player={p} nativeControls style={{ height: 200, borderRadius: 12 }} />; }
export function FileRow({ f }: { f: FileRef }) {
  const t = useTheme();
  return <Pressable accessibilityRole="button" onPress={async () => { const u = await signedUrl(f.bucket, f.path); if (u) Linking.openURL(u); }}
    style={{ flexDirection: 'row', gap: 10, alignItems: 'center', padding: 10, borderRadius: 10, backgroundColor: t.bg2 }}>
    <Text style={{ fontSize: 24 }}>📄</Text><View style={{ flex: 1 }}><Text numberOfLines={1} style={{ color: t.text, fontWeight: '600' }}>{f.name}</Text>
      <Text style={{ color: t.muted, fontSize: 12 }}>{f.mime.split('/')[1]?.toUpperCase().slice(0, 12)} · {size(f.size)}</Text></View><Text style={{ color: t.blue }}>Open</Text></Pressable>;
}
// Hold to record, release to send. While recording a Cancel button discards the clip.
export function Recorder({ onDone }: { onDone: (uri: string, seconds: number) => void }) {
  const t = useTheme(); const rec = useAudioRecorder(RecordingPresets.HIGH_QUALITY); const [on, setOn] = useState(false); const start = useRef(0);
  const begin = async () => { const p = await AudioModule.requestRecordingPermissionsAsync(); if (!p.granted) return;
    await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true }); await rec.prepareToRecordAsync(); rec.record(); start.current = Date.now(); setOn(true); };
  const end = async (send: boolean) => { if (!on) return; setOn(false); await rec.stop(); const s = Math.round((Date.now() - start.current) / 1000); if (send && s >= 1 && rec.uri) onDone(rec.uri, s); };
  return <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
    {on && <Pressable onPress={() => end(false)} accessibilityRole="button"><Text style={{ color: t.red }}>Cancel</Text></Pressable>}
    <Pressable onPressIn={begin} onPressOut={() => end(true)} accessibilityRole="button" accessibilityLabel="Hold to record a voice message"
      style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: on ? t.red : t.blue, alignItems: 'center', justifyContent: 'center' }}><Text style={{ fontSize: 20 }}>🎤</Text></Pressable></View>;
}
