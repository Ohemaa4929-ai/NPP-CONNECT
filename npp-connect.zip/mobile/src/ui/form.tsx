import { ReactNode } from 'react';
import { Image, Pressable, Text, View } from 'react-native';
import { useTheme } from './theme';

export function AuthFrame({ title, children }: { title: string; children: ReactNode }) {
  const t = useTheme();
  return <View style={{ flex: 1, backgroundColor: t.bg, padding: 24, justifyContent: 'center', gap: 12 }}>
    <Image source={require('../../assets/logo.png')} style={{ width: 120, height: 100, alignSelf: 'center' }} resizeMode="contain" />
    <Text style={{ color: t.text, fontSize: 22, fontWeight: '800', textAlign: 'center' }}>{title}</Text>
    {children}
  </View>;
}
export function Button({ label, onPress, disabled, tone = 'red' }: { label: string; onPress: () => void; disabled?: boolean; tone?: 'red' | 'blue' }) {
  const t = useTheme();
  return <Pressable accessibilityRole="button" onPress={onPress} disabled={disabled}
    style={{ backgroundColor: tone === 'red' ? t.red : t.blue, opacity: disabled ? 0.4 : 1, padding: 16, borderRadius: 12, alignItems: 'center' }}>
    <Text style={{ color: '#fff', fontWeight: '700', fontSize: 16 }}>{label}</Text></Pressable>;
}
export const inputStyle = (t: ReturnType<typeof useTheme>) => ({
  borderWidth: 1, borderColor: t.line, borderRadius: 12, padding: 14, fontSize: 18, color: t.text, backgroundColor: t.bg2 });
