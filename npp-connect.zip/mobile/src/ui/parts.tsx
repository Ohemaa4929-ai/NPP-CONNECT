import { ReactNode } from 'react';
import { Text, View, StyleSheet, Pressable, Modal } from 'react-native';
import { Stack } from 'expo-router';
import { useTheme } from './theme';
import { config } from '@/lib/config';

export function Screen({ children }: { children: ReactNode }) {
  const t = useTheme();
  return <View style={{ flex: 1, backgroundColor: t.bg }}>
    {config.demo && <View style={[s.demo, { backgroundColor: t.red }]}>
      <Text style={s.demoText}>DEMO MODE: fictional accounts and sample data only</Text></View>}
    {children}
  </View>;
}
export function Empty({ text }: { text: string }) {
  const t = useTheme();
  return <View style={s.empty}><Text style={{ color: t.muted, fontSize: 16 }}>{text}</Text></View>;
}
export function Verified() {
  const t = useTheme();
  return <View style={[s.badge, { backgroundColor: t.blue }]} accessibilityLabel="Verified leader">
    <Text style={{ color: '#fff', fontSize: 10 }}>✓</Text></View>;
}
export function Row({ title, sub, right, onPress }: { title: string; sub: string; right?: ReactNode; onPress?: () => void }) {
  const t = useTheme();
  return <Pressable onPress={onPress} style={[s.row, { borderColor: t.line }]} accessibilityRole="button">
    <View style={[s.av, { backgroundColor: t.blue2 }]}><Text style={{ color: '#fff', fontWeight: '800' }}>{title[0]}</Text></View>
    <View style={{ flex: 1 }}>
      <Text style={{ color: t.text, fontWeight: '700' }}>{title}</Text>
      <Text numberOfLines={1} style={{ color: t.muted }}>{sub}</Text></View>
    {right}
  </Pressable>;
}
const s = StyleSheet.create({
  demo: { paddingVertical: 4, alignItems: 'center' }, demoText: { color: '#fff', fontSize: 12, fontWeight: '600' },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 32 },
  badge: { width: 16, height: 16, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  row: { flexDirection: 'row', gap: 12, alignItems: 'center', padding: 14, borderBottomWidth: StyleSheet.hairlineWidth },
  av: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
});

// ───── shared states: skeleton loader, friendly error, empty ─────
export function Skeleton({ rows = 5 }: { rows?: number }) {
  const t = useTheme();
  return <View accessibilityLabel="Loading">{Array.from({ length: rows }).map((_, i) => (
    <View key={i} style={{ flexDirection: 'row', gap: 12, padding: 14 }}>
      <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: t.bg2 }} />
      <View style={{ flex: 1, gap: 8, justifyContent: 'center' }}><View style={{ height: 12, width: '60%', backgroundColor: t.bg2, borderRadius: 6 }} /><View style={{ height: 10, width: '85%', backgroundColor: t.bg2, borderRadius: 6 }} /></View></View>))}</View>;
}
export function State({ loading, error, empty, emptyText, reload, children }: { loading: boolean; error: string | null; empty?: boolean; emptyText?: string; reload?: () => void; children: ReactNode }) {
  const t = useTheme();
  if (loading) return <Skeleton />;
  if (error) return <View style={s.empty}><Text style={{ color: t.text, textAlign: 'center', marginBottom: 12 }}>{error}</Text>
    {reload && <Pressable onPress={reload} accessibilityRole="button" style={{ backgroundColor: t.red, padding: 12, borderRadius: 10 }}><Text style={{ color: '#fff', fontWeight: '700' }}>Tap to retry</Text></Pressable>}</View>;
  if (empty) return <Empty text={emptyText ?? 'Nothing here yet.'} />;
  return <>{children}</>;
}
export function Sheet({ visible, onClose, actions }: { visible: boolean; onClose: () => void; actions: { label: string; run: () => void; danger?: boolean }[] }) {
  const t = useTheme();
  return <Modal transparent visible={visible} animationType="fade" onRequestClose={onClose}>
    <Pressable style={{ flex: 1, backgroundColor: '#0008', justifyContent: 'flex-end' }} onPress={onClose}>
      <View style={{ backgroundColor: t.bg, borderTopLeftRadius: 16, borderTopRightRadius: 16, padding: 8, paddingBottom: 28 }}>
        {actions.map((a) => <Pressable key={a.label} accessibilityRole="button" onPress={() => { onClose(); a.run(); }} style={{ padding: 16 }}>
          <Text style={{ color: a.danger ? t.red : t.text, fontSize: 16 }}>{a.label}</Text></Pressable>)}
        <Pressable onPress={onClose} style={{ padding: 16 }}><Text style={{ color: t.muted, fontSize: 16 }}>Cancel</Text></Pressable></View></Pressable></Modal>;
}
export const ago = (iso: string) => new Date(iso).toLocaleDateString([], { day: 'numeric', month: 'short' });

export function Page({ title, children }: { title: string; children: ReactNode }) {
  return <Screen><Stack.Screen options={{ headerShown: true, title, headerStyle: { backgroundColor: '#16307a' }, headerTintColor: '#fff' }} />{children}</Screen>;
}
export const useInput = () => { const t = useTheme(); return { borderWidth: 1, borderColor: t.line, borderRadius: 10, padding: 12, color: t.text, backgroundColor: t.bg2 } as const; };
export function Chip({ label, on, onPress }: { label: string; on: boolean; onPress: () => void }) {
  const t = useTheme();
  return <Pressable onPress={onPress} accessibilityRole="button" accessibilityState={{ selected: on }} style={{ paddingVertical: 8, paddingHorizontal: 14, borderRadius: 99, borderWidth: 1, borderColor: on ? t.blue : t.line, backgroundColor: on ? t.blue : t.bg }}>
    <Text style={{ color: on ? '#fff' : t.text }}>{label}</Text></Pressable>;
}
