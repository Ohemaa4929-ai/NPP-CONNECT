import { useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { repo } from '@/data/repo';
import { useTheme } from './theme';
import type { PollT } from '@/data/types';

export function Poll({ poll, onChange }: { poll: PollT; onChange: () => void }) {
  const t = useTheme(); const [sel, setSel] = useState<string[]>(poll.mine); const [err, setErr] = useState('');
  const total = poll.options.reduce((a, o) => a + o.votes, 0) || 1; const closed = !!poll.closesAt && new Date(poll.closesAt) < new Date();
  const toggle = (id: string) => setSel(poll.multiple ? (sel.includes(id) ? sel.filter((x) => x !== id) : [...sel, id]) : [id]);
  const vote = async () => { try { await repo.vote(poll.id, sel); setErr(''); onChange(); } catch (e) { setErr(e instanceof Error ? e.message : 'Could not vote.'); } };
  return <View style={{ borderWidth: 1, borderColor: t.line, borderRadius: 12, padding: 12, gap: 8 }}>
    <Text style={{ color: t.text, fontWeight: '800' }}>{poll.question}</Text>
    <Text style={{ color: t.muted, fontSize: 12 }}>{poll.multiple ? 'Choose one or more' : 'Choose one'}{poll.anonymous ? ' · Anonymous' : ''}{closed ? ' · Closed' : poll.closesAt ? ` · Closes ${new Date(poll.closesAt).toLocaleDateString()}` : ''}</Text>
    {poll.options.map((o) => <Pressable key={o.id} disabled={closed} onPress={() => toggle(o.id)} accessibilityRole={poll.multiple ? 'checkbox' : 'radio'} accessibilityState={{ selected: sel.includes(o.id) }}
      style={{ padding: 10, borderRadius: 8, backgroundColor: t.bg2, borderWidth: sel.includes(o.id) ? 2 : 0, borderColor: t.blue }}>
      <View style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: `${(o.votes / total) * 100}%`, backgroundColor: t.blue + '22', borderRadius: 8 }} />
      <Text style={{ color: t.text }}>{o.label} · {o.votes} ({Math.round((o.votes / total) * 100)}%)</Text></Pressable>)}
    {!closed && <Pressable disabled={!sel.length} onPress={vote} accessibilityRole="button" style={{ backgroundColor: t.red, opacity: sel.length ? 1 : 0.4, padding: 10, borderRadius: 10, alignItems: 'center' }}><Text style={{ color: '#fff', fontWeight: '700' }}>{poll.mine.length ? 'Change vote' : 'Vote'}</Text></Pressable>}
    {!!err && <Text accessibilityRole="alert" style={{ color: t.red }}>{err}</Text>}</View>;
}
