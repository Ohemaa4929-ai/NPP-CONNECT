import { useColorScheme } from 'react-native';
// Party colors: red, white, blue.
const light = { blue: '#16307a', blue2: '#2a49a8', red: '#e10e17', bg: '#ffffff', bg2: '#f2f4fa',
  text: '#101736', muted: '#5a6585', line: '#dde2f0' };
const dark = { ...light, bg: '#0b1022', bg2: '#141b33', text: '#eef1fb', muted: '#9aa6cc', line: '#27325a' };
export const useTheme = () => (useColorScheme() === 'dark' ? dark : light);
export type Theme = typeof light;
