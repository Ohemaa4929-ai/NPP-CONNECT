# NPP CONNECT mobile (Expo)

Status: Step 2 scaffold. Five tabs, red/white/blue theme, demo mode. Not yet connected to Supabase.

## Run
    cp .env.example .env
    npm install
    npx expo install --fix      # aligns package versions with your Expo SDK
    npx expo start

Demo mode is on by default (`EXPO_PUBLIC_DEMO_MODE=true`). It uses fictional data from `src/demo/data.ts`.

## Layout
- `app/` routes (expo-router). `(tabs)/` holds Home, Chats, Groups, Broadcasts, Profile.
- `src/ui/` theme and shared components. `src/lib/` config and Supabase client. `src/demo/` fake data.

## Before store release
Change the bundle identifier and package name in `app.json`, add real privacy policy and terms (legal review), and replace placeholder store assets.
