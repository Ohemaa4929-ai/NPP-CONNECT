// Outbox retry/idempotency contract, with the repo and storage mocked.
jest.mock('@react-native-async-storage/async-storage', () => { let s: Record<string, string> = {}; return { __esModule: true, default: { getItem: async (k: string) => s[k] ?? null, setItem: async (k: string, v: string) => { s[k] = v; } } }; });
jest.mock('@react-native-community/netinfo', () => ({ addEventListener: jest.fn() }));
const send = jest.fn();
jest.mock('../src/data/repo', () => ({ repo: { send: (...a: unknown[]) => send(...a) } }));
import { enqueueAndSend, pending } from '../src/lib/outbox';

beforeEach(() => send.mockReset());
test('keeps a message queued when sending fails, then delivers it on retry', async () => {
  send.mockRejectedValueOnce(new Error('offline'));
  await enqueueAndSend({ clientId: 'c1', conversationId: 'k', body: 'hi' });
  expect(await pending('k')).toHaveLength(1);
  send.mockResolvedValue(undefined);
  const { flush } = await import('../src/lib/outbox'); await flush();
  expect(await pending('k')).toHaveLength(0);
  expect(send).toHaveBeenLastCalledWith('k', expect.objectContaining({ clientId: 'c1' }));
});
