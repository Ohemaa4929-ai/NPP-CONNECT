import { normalizeGhanaPhone as f } from '../src/lib/phone';
test('accepts common Ghana formats', () => {
  expect(f('0244123456')).toBe('+233244123456');
  expect(f('+233 24 412 3456')).toBe('+233244123456');
  expect(f('233244123456')).toBe('+233244123456');
  expect(f('244123456')).toBe('+233244123456');
});
test('rejects bad input', () => {
  expect(f('')).toBeNull();
  expect(f('12345')).toBeNull();
  expect(f('+2341234567890')).toBeNull();
  expect(f('0144123456')).toBeNull();
});
