# NPP CONNECT: auth setup and deployment notes

Status: auth screens are written. Nothing here has been run against a live project. Test on DEV first.

## 1. Supabase projects
Create three projects: `npp-connect-dev`, `-staging`, `-prod`. Never reuse keys between them.
Apply `supabase/migrations/*.sql` in order with the Supabase CLI (`supabase db push`). Do dev first, then staging, then prod.

## 2. Phone OTP
Dashboard > Authentication > Providers > Phone: enable, choose an SMS provider that delivers to Ghana numbers
(Twilio, MessageBird, Vonage or Textlocal are the built-in options). Check Ghana delivery and price with the provider.
Set OTP expiry to 300 seconds or less, and keep the default rate limits. Provider credentials stay in the dashboard.
Test numbers can be listed in the dashboard for dev so no SMS is sent.

## 3. Admin 2FA
Enable TOTP MFA (Authentication > Multi-factor). Admin dashboard (step to come) must require an AAL2 session,
and RLS for admin writes should check `auth.jwt()->>'aal' = 'aal2'`. Add that check before launch.

## 4. First super admin
Sign up with your number in the app, then in the SQL editor, as a one-time manual step:
    update profiles set status='active', verified_at=now() where phone='+233XXXXXXXXX';
    insert into user_roles values ((select id from profiles where phone='+233XXXXXXXXX'),'super_admin');
Create the org units and broadcast grants from the admin dashboard afterward.

## 5. Mobile builds
Set EXPO_PUBLIC_* values per environment in EAS (`eas secret` / EAS environment variables). Set EXPO_PUBLIC_DEMO_MODE=false for staging and production.
Change bundle ID and package name. Run `eas build` for iOS and Android, then submit to App Store Connect and Google Play.
Store listings need a hosted privacy policy URL and an account deletion path.

## 6. Launch gates
- Legal review of Terms and Privacy Policy under Ghana data protection law, including political-opinion data handling.
- RLS test with two non-admin accounts (cannot read each other's profile, cannot change status or verified_at).
- Load test broadcasts after Phase 3. Backup restore test. Security review.
- No end-to-end encryption claim anywhere in the UI or store listing.
